/* contrib/adminpack/mysqlface--1.0.sql */

-- complain if script is sourced in psql, rather than via CREATE EXTENSION
-- \echo Use "CREATE EXTENSION mysqlface" to load this file. \quit
CREATE SCHEMA mysql;

/* ***********************************************
 * mysql functions for PostgreSQL
 * *********************************************** */
 
CREATE OR REPLACE FUNCTION mysql.replace(text, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','mysql_replace_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.replace(char, variadic "any")
RETURNS char
AS 'MODULE_PATHNAME','char_replace'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.replace(numeric, variadic "any")
RETURNS numeric
AS 'MODULE_PATHNAME','numeric_replace'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.replace(integer, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','integer_replace'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.replace(float4, variadic "any")
RETURNS float4
AS 'MODULE_PATHNAME','float4_replace'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.replace(float8, variadic "any")
RETURNS float8
AS 'MODULE_PATHNAME','float8_replace'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.replace(date, variadic "any")
RETURNS date
AS 'MODULE_PATHNAME','date_replace'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.replace(timestamp, variadic "any")
RETURNS timestamp
AS 'MODULE_PATHNAME','timestamp_replace'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.replace(timestamptz, variadic "any")
RETURNS timestamptz
AS 'MODULE_PATHNAME','timestamptz_replace'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.replace(interval, variadic "any")
RETURNS interval
AS 'MODULE_PATHNAME','interval_replace'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

/* generic file access functions */

CREATE OR REPLACE FUNCTION mysql.unix_timestamp(timestamptz)
RETURNS double precision
AS 'MODULE_PATHNAME','unix_timestamp'
LANGUAGE C
STRICT
STABLE;

CREATE OR REPLACE FUNCTION mysql.unix_timestamp()
RETURNS double precision
AS 'MODULE_PATHNAME','unix_timestampnoparmater'
LANGUAGE C
STRICT
STABLE;

CREATE OR REPLACE FUNCTION mysql.from_unixtime(double precision)
RETURNS timestamp
AS 'MODULE_PATHNAME','from_unixtime'
LANGUAGE C
STRICT
STABLE;

CREATE OR REPLACE FUNCTION mysql.from_unixtime(double precision, fmt text)
RETURNS text
AS 'MODULE_PATHNAME','from_fmtunixtime'
LANGUAGE C
STRICT
STABLE;


/* mysql if function */
--both number
CREATE OR REPLACE FUNCTION mysql.if(expr numeric, value1 numeric, value2 numeric)
RETURNS numeric
AS $$
BEGIN
IF expr<>0 THEN
	return value1;
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr boolean, value1 numeric, value2 numeric)
RETURNS numeric
AS $$
BEGIN
IF expr<>false THEN
	return value1;
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr text, value1 numeric, value2 numeric)
RETURNS numeric
AS $$
DECLARE
var text = trim($1);
BEGIN	
IF expr IS NOT NULL THEN
	IF substr(var, 1, 1)~'^([1-9])' THEN
		return  value1;
	ELSE
		return value2;
	END IF;		
	return value1;
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

--bother string
CREATE OR REPLACE FUNCTION mysql.if(expr text, value1 text, value2 text)
RETURNS text
AS $$
DECLARE
var text = trim($1);
BEGIN	
IF expr IS NOT NULL THEN
	IF substr(var, 1, 1)~'^([1-9])' THEN
		return  value1;
	ELSE
		return value2;
	END IF;		
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr boolean, value1 text, value2 text)
RETURNS text
AS $$
BEGIN	
IF expr <> false THEN
	return  value1;		
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr numeric, value1 text, value2 text)
RETURNS text
AS $$
BEGIN	
IF expr <> 0 THEN
	return  value1;		
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

--one numeric and one string
CREATE OR REPLACE FUNCTION mysql.if(expr numeric, value1 numeric, value2 text)
RETURNS text
AS $$
BEGIN	
IF expr <> 0 THEN
	return  value1::text;		
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr numeric, value1 text, value2 numeric)
RETURNS text
AS $$
BEGIN	
IF expr <> 0 THEN
	return  value1;		
ELSE
	return value2::text;
END IF;
END; $$
LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION mysql.if(expr boolean, value1 numeric, value2 text)
RETURNS text
AS $$
BEGIN	
IF expr <> false THEN
	return  value1::text;		
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr boolean, value1 text, value2 numeric)
RETURNS text
AS $$
BEGIN	
IF expr <> false THEN
	return  value1;		
ELSE
	return value2::text;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr text, value1 numeric, value2 text)
RETURNS text
AS $$
DECLARE
var text = trim($1);
BEGIN	
IF expr IS NOT NULL THEN
	IF substr(var, 1, 1)~'^([1-9])' THEN
		return  value1::text;
	ELSE
		return value2;
	END IF;		
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr text, value1 text, value2 numeric)
RETURNS text
AS $$
DECLARE
var text = trim($1);
BEGIN	
IF expr IS NOT NULL THEN
	IF substr(var, 1, 1)~'^([1-9])' THEN
		return  value1;
	ELSE
		return value2::text;
	END IF;		
ELSE
	return value2::text;
END IF;
END; $$
LANGUAGE plpgsql;

--varchar
CREATE OR REPLACE FUNCTION mysql.if(expr varchar, value1 varchar, value2 numeric)
RETURNS varchar
AS $$
DECLARE
var varchar = trim($1);
BEGIN	
IF expr IS NOT NULL THEN
	IF substr(var, 1, 1)~'^([1-9])' THEN
		return  value1;
	ELSE
		return value2::varchar;
	END IF;		
ELSE
	return value2::varchar;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr varchar, value1 numeric, value2 varchar)
RETURNS varchar
AS $$
DECLARE
var varchar = trim($1);
BEGIN
IF expr IS NOT NULL THEN
	IF substr(var, 1, 1)~'^([1-9])' THEN
		return  value1;
	ELSE
		return value2::varchar;
	END IF;
ELSE
	return value2::varchar;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr varchar, value1 varchar, value2 varchar)
RETURNS varchar
AS $$
DECLARE
var varchar = trim($1);
BEGIN
IF expr IS NOT NULL THEN
	IF substr(var, 1, 1)~'^([1-9])' THEN
		return  value1;
	ELSE
		return value2;
	END IF;
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION mysql.if(expr boolean, value1 numeric, value2 varchar)
RETURNS varchar
AS $$
BEGIN	
IF expr <> false THEN
	return  value1::varchar;		
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr boolean, value1 varchar, value2 numeric)
RETURNS varchar
AS $$
BEGIN	
IF expr <> false THEN
	return  value1;		
ELSE
	return value2::varchar;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr boolean, value1 varchar, value2 varchar)
RETURNS varchar
AS $$
BEGIN	
IF expr <> false THEN
	return  value1;		
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION mysql.if(expr numeric, value1 numeric, value2 varchar)
RETURNS varchar
AS $$
BEGIN	
IF expr <> 0 THEN
	return  value1::varchar;		
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr numeric, value1 varchar, value2 numeric)
RETURNS varchar
AS $$
BEGIN	
IF expr <> 0 THEN
	return  value1;		
ELSE
	return value2::varchar;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(expr numeric, value1 varchar, value2 varchar)
RETURNS varchar
AS $$
BEGIN	
IF expr <> 0 THEN
	return  value1;		
ELSE
	return value2;
END IF;
END; $$
LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mysql.if(date, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','mysql_if_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.if(timestamp, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','mysql_if_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.if(timestamptz, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','mysql_if_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION mysql.if(interval, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','mysql_if_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;


/*datediff function*/
CREATE FUNCTION mysql.datediff(TIMESTAMP, TIMESTAMP)
RETURNS integer
AS 'MODULE_PATHNAME','mysql_date_diff'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  mysql.datediff(TIMESTAMP, TIMESTAMP) IS 'The days difference between the two timestamp values';

CREATE FUNCTION mysql.datediff(TIMESTAMPTZ, TIMESTAMPTZ)
RETURNS integer
AS 'MODULE_PATHNAME','mysql_timestamptz_diff'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  mysql.datediff(TIMESTAMPTZ, TIMESTAMPTZ) IS 'The days difference between the two timestamp values';

/* add by yanxuebiao at 2021/1/5 for compat mysql function */
CREATE FUNCTION mysql.date_sub(indate timestamp with time zone, ininterval interval)
RETURNS TIMESTAMP WITHOUT TIME ZONE
LANGUAGE plpgsql
AS $function$
BEGIN
	return (indate - ininterval)::timestamp(0);
END;
$function$;

CREATE FUNCTION mysql.date_add(indate timestamp with time zone, ininterval interval)
RETURNS TIMESTAMP WITHOUT TIME ZONE
LANGUAGE plpgsql
AS $function$
BEGIN
	return (indate + ininterval)::timestamp(0);
END;
$function$;

/*add by xuji 2021.02.07 start*/
--group_concat--------------------------------------------------------------------------------end

---group_concat_cfunc--------------------------
CREATE OR REPLACE FUNCTION mysql.group_concat_func(text,variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','group_concat_cfunc'
LANGUAGE C;

CREATE OR REPLACE AGGREGATE mysql.group_concat(variadic "any")
    (sfunc = mysql.group_concat_func, stype = text);

CREATE OR REPLACE FUNCTION mysql.group_concat_func2(text,text,variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','group_concat_cfunc2'
LANGUAGE C;

CREATE OR REPLACE AGGREGATE mysql.group_concat(text,variadic "any")
    (sfunc = mysql.group_concat_func2, stype = text);

-----------------------------

--sum------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION mysql.sum_func(results numeric, var varchar)
RETURNS numeric
AS $function$
DECLARE
  vartext text;
BEGIN
  IF var IS NULL THEN
    RETURN COALESCE(results, 0);
  END IF;

  var = trim(leading ' ' from var);
  vartext = substring(var,'\s*[0-9]*\.?[0-9]*');
  
  
  IF length(vartext) = 0 THEN
    results = COALESCE(results, 0) + 0::numeric;
  ELSE
    results = COALESCE(results, 0) + vartext::numeric;
  END IF;
  
  RETURN results;
END;
$function$
LANGUAGE PLPGSQL;

CREATE OR REPLACE AGGREGATE mysql.sum(varchar)(sfunc = mysql.sum_func, stype = numeric);

CREATE OR REPLACE FUNCTION mysql.sum_func_date(results numeric, datevar timestamp)
RETURNS numeric
AS $function$
DECLARE
BEGIN
  IF datevar IS NULL THEN
    RETURN COALESCE(results, 0);
  END IF;

  results = COALESCE(results, 0) + to_number(to_char(datevar, 'YYYYMMDDHH24MISS'), '99999999999999999999') ;
  
  RETURN results;
END;
$function$
LANGUAGE PLPGSQL;

CREATE OR REPLACE AGGREGATE mysql.sum(timestamp)(sfunc = mysql.sum_func_date, stype = numeric);

--date_format------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION mysql.date_format(indate timestamp, intext text)
RETURNS text
AS $function$
DECLARE
  issupport int;

BEGIN
	issupport = pg_catalog.strpos(intext, '%D');
	issupport = pg_catalog.strpos(intext, '%V');
	issupport = pg_catalog.strpos(intext, '%v');
	issupport = pg_catalog.strpos(intext, '%w');
	issupport = pg_catalog.strpos(intext, '%X');
	issupport = pg_catalog.strpos(intext, '%x');

	IF issupport > 0 THEN
      raise exception 'No following format %%D %%V %%v %%w %%X %%x!';
	  RETURN '';
    END IF;
    intext = pg_catalog.replace(intext, '%a', 'Dy') ;
    intext = pg_catalog.replace(intext, '%b', 'Mon') ;
    intext = pg_catalog.replace(intext, '%c', 'MM') ;    --incompatibility:not display the 0 on the left
    intext = pg_catalog.replace(intext, '%D', '%D') ;    --incompatibility
    intext = pg_catalog.replace(intext, '%d', 'DD') ;
    intext = pg_catalog.replace(intext, '%e', 'DD') ;
    intext = pg_catalog.replace(intext, '%f', 'US') ;
    intext = pg_catalog.replace(intext, '%H', 'HH24') ;
    intext = pg_catalog.replace(intext, '%h', 'HH12') ;
    intext = pg_catalog.replace(intext, '%I', 'HH12') ;
    intext = pg_catalog.replace(intext, '%i', 'MI') ;
    intext = pg_catalog.replace(intext, '%j', 'DDD') ;
    intext = pg_catalog.replace(intext, '%k', 'HH24') ;
    intext = pg_catalog.replace(intext, '%l', 'HH12') ;
    intext = pg_catalog.replace(intext, '%M', 'Month') ;
    intext = pg_catalog.replace(intext, '%m', 'MM') ;
    intext = pg_catalog.replace(intext, '%p', 'AM') ;
    intext = pg_catalog.replace(intext, '%r', 'HH12:MI:SS AM') ;
    intext = pg_catalog.replace(intext, '%S', 'SS') ;
    intext = pg_catalog.replace(intext, '%s', 'SS') ;
    intext = pg_catalog.replace(intext, '%T', 'HH24:MI:SS') ;
    intext = pg_catalog.replace(intext, '%U', 'IW') ;
    intext = pg_catalog.replace(intext, '%u', 'WW') ; 
    intext = pg_catalog.replace(intext, '%W', 'Day') ;
    intext = pg_catalog.replace(intext, '%Y', 'YYYY') ;
    intext = pg_catalog.replace(intext, '%y', 'YY') ;
    intext = pg_catalog.replace(intext, '%%%','%') ;
	
    RETURN to_char(indate,intext);

  RETURN '';
END;
$function$
LANGUAGE PLPGSQL;




--limit------------------------------------------------------------------------------
    
--case - when------------------------------------------------------------------------------


--convert------------------------------------------------------------------------------

--field------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION mysql.field_func(text, text[])
  RETURNS bigint 
  AS $$
    SELECT n FROM (
      SELECT row_number() over() AS n, x FROM unnest($2) x
      ) numbered
      WHERE numbered.x = $1;
  $$
LANGUAGE SQL immutable strict;
  
CREATE OR REPLACE FUNCTION mysql.field(text, variadic text[]) 
  RETURNS bigint 
  AS $$
  DECLARE
    value bigint;
  BEGIN
    value = field_func($1,$2);
    IF value IS NOT NULL THEN
      RETURN value;
    ELSE
      RETURN 0;
    END IF;
END; $$ 
LANGUAGE plpgsql;
--table_msg------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION mysql.pgsql_type(a_type varchar) RETURNS varchar AS  
$BODY$  
DECLARE  
     v_type varchar;  
BEGIN  
     IF a_type='int8' THEN  
          v_type:='bigint';  
     ELSIF a_type='int4' THEN  
          v_type:='integer';  
     ELSIF a_type='int2' THEN  
          v_type:='smallint';  
     ELSIF a_type='bpchar' THEN  
          v_type:='char';  
     ELSE  
          v_type:=a_type;  
     END IF;  
     RETURN v_type;  
END;  
$BODY$  
LANGUAGE PLPGSQL;
 
CREATE TYPE mysql.tablestruct AS (  
  fields_key_name varchar(100),  
  fields_name VARCHAR(200),  
  fields_type VARCHAR(20),  
  fields_length BIGINT,  
  fields_not_null VARCHAR(10),  
  fields_default VARCHAR(500),  
  fields_comment VARCHAR(1000)  
);

CREATE OR REPLACE FUNCTION mysql.table_msg (a_schema_name varchar, a_table_name varchar) RETURNS SETOF mysql.tablestruct AS  
$body$  
DECLARE  
     v_ret mysql.tablestruct;  
     v_oid oid;  
     v_sql varchar;  
     v_rec RECORD;  
     v_key varchar;  
BEGIN  
     SELECT  
           pg_class.oid  INTO v_oid  
     FROM  
           pg_class  
           INNER JOIN pg_namespace ON (pg_class.relnamespace = pg_namespace.oid AND lower(pg_namespace.nspname) = a_schema_name)  
     WHERE  
           pg_class.relname=a_table_name;  
     IF NOT FOUND THEN  
         RETURN;  
     END IF;  
  
     v_sql='  
     SELECT  
           pg_attribute.attname AS fields_name,  
           pg_attribute.attnum AS fields_index,  
           mysql.pgsql_type(pg_type.typname::varchar) AS fields_type,  
           pg_attribute.atttypmod-4 as fields_length,  
           CASE WHEN pg_attribute.attnotnull  THEN ''not null''  
           ELSE ''''  
           END AS fields_not_null,  
           pg_get_expr(pg_attrdef.adbin, pg_attrdef.adrelid) AS fields_default,  
           pg_description.description AS fields_comment  
     FROM  
           pg_attribute  
           INNER JOIN pg_class  ON pg_attribute.attrelid = pg_class.oid  
           INNER JOIN pg_type   ON pg_attribute.atttypid = pg_type.oid  
           LEFT OUTER JOIN pg_attrdef ON pg_attrdef.adrelid = pg_class.oid AND pg_attrdef.adnum = pg_attribute.attnum  
           LEFT OUTER JOIN pg_description ON pg_description.objoid = pg_class.oid AND pg_description.objsubid = pg_attribute.attnum  
     WHERE  
           pg_attribute.attnum > 0  
           AND attisdropped <> ''t''  
           AND pg_class.oid = ' || v_oid || '  
     ORDER BY pg_attribute.attnum' ;  
  
     FOR v_rec IN EXECUTE v_sql LOOP  
         v_ret.fields_name=v_rec.fields_name;  
         v_ret.fields_type=v_rec.fields_type;  
         IF v_rec.fields_length > 0 THEN  
            v_ret.fields_length:=v_rec.fields_length;  
         ELSE  
            v_ret.fields_length:=NULL;  
         END IF;  
         v_ret.fields_not_null=v_rec.fields_not_null;  
         v_ret.fields_default=v_rec.fields_default;  
         v_ret.fields_comment=v_rec.fields_comment;  
         SELECT constraint_name INTO v_key FROM information_schema.key_column_usage WHERE table_schema=a_schema_name AND table_name=a_table_name AND column_name=v_rec.fields_name;  
         IF FOUND THEN  
            v_ret.fields_key_name=v_key;  
         ELSE  
            v_ret.fields_key_name='';  
         END IF;  
         RETURN NEXT v_ret;  
     END LOOP;  
     RETURN ;  
END;  
$body$  
LANGUAGE 'plpgsql' VOLATILE CALLED ON NULL INPUT SECURITY INVOKER;

CREATE OR REPLACE FUNCTION mysql.table_msg (a_table_name varchar) RETURNS SETOF mysql.tablestruct AS  
$body$  
DECLARE  
    v_ret mysql.tablestruct;  
BEGIN  
    FOR v_ret IN SELECT * FROM mysql.table_msg('public',a_table_name) LOOP  
        RETURN NEXT v_ret;  
    END LOOP;  
    RETURN;  
END;  
$body$  
LANGUAGE 'plpgsql' VOLATILE CALLED ON NULL INPUT SECURITY INVOKER;  

--left------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION mysql.left(timestamp with time zone, integer)
  RETURNS varchar
  AS $$
    SELECT pg_catalog.left(to_char($1, 'YYYY-MM-DD HH24:MI:SS'), $2);
  $$
LANGUAGE SQL;
  
CREATE OR REPLACE FUNCTION mysql.right(timestamp with time zone, integer)
RETURNS varchar
AS $$
  SELECT pg_catalog.right(to_char($1, 'YYYY-MM-DD HH24:MI:SS'), $2);
$$
LANGUAGE SQL;
/*add by xuji 2021.02.07 end */