/*CREATE OR REPLACE FUNCTION public.set_user_seclabel(oid,cstring) 
RETURNS boolean
AS 'MODULE_PATHNAME', 'set_user_seclabel'
LANGUAGE C STRICT;

CREATE OR REPLACE FUNCTION public.get_user_seclabel(oid) 
RETURNS cstring
AS 'MODULE_PATHNAME', 'get_user_seclabel'
LANGUAGE C STRICT;

CREATE OR REPLACE FUNCTION public.set_table_seclabel(oid,cstring) 
RETURNS boolean
AS 'MODULE_PATHNAME', 'set_table_seclabel'
LANGUAGE C STRICT;

CREATE OR REPLACE FUNCTION public.get_table_seclabel(oid) 
RETURNS cstring
AS 'MODULE_PATHNAME', 'get_table_seclabel'
LANGUAGE C STRICT;*/


/*these two functions now are internal funciton */
/*
CREATE OR REPLACE FUNCTION public.check_seclabel(cstring) 
RETURNS boolean
AS 'MODULE_PATHNAME', 'check_seclabel'
LANGUAGE C STRICT;

CREATE OR REPLACE FUNCTION public.compare_seclabel(cstring,cstring) 
RETURNS smallint
AS 'MODULE_PATHNAME', 'compare_seclabel'
LANGUAGE C STRICT;
*/

/*debug function delete latter *//*

CREATE OR REPLACE FUNCTION public.debugswitch(int,boolean) 
RETURNS boolean
AS 'MODULE_PATHNAME', 'debugswitch'
LANGUAGE C STRICT;
*/

