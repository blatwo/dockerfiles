/*-------------------------------------------------------------------------
 * passwordcheck--1.0.sql
 *
 * Copyright (c) 2009-2019, PostgreSQL Global Development Group
 *
 * Author: Laurenz Albe <laurenz.albe@wien.gv.at>
 *
 * Authored by shanchengkai@highgo.com, 20191016.
 *
 * Portions Copyright (c) 2009-2020, HighGo Software Co.,Ltd. All rights reserved.
 * IDENTIFICATION
 *	  contrib/passwordcheck/passwordcheck--1.0.sql
 *
 *-------------------------------------------------------------------------
 */
 
CREATE FUNCTION public.user_unlock(text)   
RETURNS text
AS 'MODULE_PATHNAME' , 'user_unlock'
LANGUAGE C;
alter function public.user_unlock owner to syssso;