--create table public.COMMON_PASSWORD(id int);
--create table public.HIGHGO_KEYWORDS(id1 int);

--insert into public.COMMON_PASSWORD values(1);
--insert into public.HIGHGO_KEYWORDS values(2);

--ALTER TABLE public.COMMON_PASSWORD  owner to syssso;
--ALTER TABLE public.HIGHGO_KEYWORDS  owner to syssso;

--GRANT SELECT ON PUBLIC.COMMON_PASSWORD TO public;
--GRANT SELECT ON PUBLIC.HIGHGO_KEYWORDS TO public;



CREATE OR REPLACE FUNCTION public.show_secure_param()
RETURNS cstring
AS 'MODULE_PATHNAME', 'show_secure_param'
LANGUAGE C STRICT;

CREATE OR REPLACE FUNCTION public.set_secure_param(cstring,cstring)
RETURNS cstring
AS 'MODULE_PATHNAME', 'set_secure_param'
LANGUAGE C STRICT;

alter function public.show_secure_param owner to syssso;
alter function public.set_secure_param owner to syssso;