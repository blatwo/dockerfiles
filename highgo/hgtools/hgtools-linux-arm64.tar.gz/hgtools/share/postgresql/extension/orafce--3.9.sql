/* orafce--3.8.sql */
-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION orafce" to load this file. \quit
CREATE SCHEMA oracle;

/*create oracle clob and blob type*/
CREATE DOMAIN oracle.clob AS text;
CREATE DOMAIN oracle.blob AS bytea;

--can't overwrite PostgreSQL DATE data type!!!
CREATE DOMAIN oracle.date AS timestamp(0);

CREATE DOMAIN oracle.number as numeric;

CREATE FUNCTION oracle.trunc(value pg_catalog.date, fmt text)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','ora_date_trunc'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.trunc(pg_catalog.date,text) IS 'truncate date according to the specified format';

CREATE FUNCTION oracle.round(value pg_catalog.date, fmt text)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','ora_date_round'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.round(pg_catalog.date, text) IS 'round dates according to the specified format';

CREATE FUNCTION oracle.next_day(value pg_catalog.date, weekday text)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.next_day (pg_catalog.date, text) IS 'returns the first weekday that is greater than a date value';

CREATE FUNCTION oracle.next_day(value pg_catalog.date, weekday integer)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME', 'next_day_by_index'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.next_day (pg_catalog.date, integer) IS 'returns the first weekday that is greater than a date value';

CREATE FUNCTION oracle.last_day(value pg_catalog.date)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.last_day(pg_catalog.date) IS 'returns last day of the month based on a date value';

CREATE FUNCTION oracle.months_between(date1 pg_catalog.date, date2 pg_catalog.date)
RETURNS numeric
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.months_between(pg_catalog.date, pg_catalog.date) IS 'returns the number of months between date1 and date2';

CREATE FUNCTION oracle.add_months(day pg_catalog.date, value int)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.add_months(pg_catalog.date, int) IS 'RETURNS oracle.date plus n months';

CREATE FUNCTION oracle.trunc(value timestamp with time zone, fmt text)
RETURNS timestamp with time zone
AS 'MODULE_PATHNAME', 'ora_timestamptz_trunc'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.trunc(timestamp with time zone, text) IS 'truncate date according to the specified format';

CREATE FUNCTION oracle.round(value timestamp with time zone, fmt text)
RETURNS timestamp with time zone
AS 'MODULE_PATHNAME','ora_timestamptz_round'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.round(timestamp with time zone, text) IS 'round dates according to the specified format';

CREATE FUNCTION oracle.round(value timestamp with time zone)
RETURNS timestamp with time zone
AS $$ SELECT oracle.round($1, 'DDD'); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.round(timestamp with time zone) IS 'will round dates according to the specified format';

CREATE FUNCTION oracle.round(value pg_catalog.date)
RETURNS pg_catalog.date
AS $$ SELECT $1; $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.round(value pg_catalog.date)IS 'will round dates according to the specified format';

CREATE FUNCTION oracle.trunc(value timestamp with time zone)
RETURNS timestamp with time zone
AS $$ SELECT oracle.trunc($1, 'DDD'); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.trunc(timestamp with time zone) IS 'truncate date according to the specified format';

CREATE FUNCTION oracle.trunc(value pg_catalog.date)
RETURNS pg_catalog.date
AS $$ SELECT $1; $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.trunc(pg_catalog.date) IS 'truncate date according to the specified format';


CREATE FUNCTION oracle.set_nls_sort(text)
RETURNS void
AS 'MODULE_PATHNAME', 'ora_set_nls_sort'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.set_nls_sort(text) IS '';

/* author:luotao */
CREATE FUNCTION oracle.instr(char, variadic "any")
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr4'
LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION oracle.instr(text, variadic "any")
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr4'
LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION oracle.instr(numeric, variadic "any")
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr4'
LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION oracle.instr(float4, variadic "any")
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr4'
LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION oracle.instr(float8, variadic "any")
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr4'
LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION oracle.instr(pg_catalog.date, variadic "any")
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr4'
LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION oracle.instr(timestamp, variadic "any")
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr4'
LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION oracle.instr(timestamptz, variadic "any")
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr4'
LANGUAGE C IMMUTABLE STRICT;

CREATE FUNCTION oracle.instr(interval, variadic "any")
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr4'
LANGUAGE C IMMUTABLE STRICT;
/* added end by luotao at 2020/03/04 */

/*update at 20200323 author jinhuajian*/
CREATE FUNCTION oracle.to_char(num smallint)
RETURNS text
AS 'MODULE_PATHNAME','orafce_to_char_int4'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.to_char(smallint) IS 'Convert number to string';

CREATE FUNCTION oracle.to_char(num int)
RETURNS text
AS 'MODULE_PATHNAME','orafce_to_char_int4'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.to_char(int) IS 'Convert number to string';

CREATE FUNCTION oracle.to_char(num bigint)
RETURNS text
AS 'MODULE_PATHNAME','orafce_to_char_int8'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.to_char(bigint) IS 'Convert number to string';

CREATE FUNCTION oracle.to_char(num real)
RETURNS text
AS 'MODULE_PATHNAME','orafce_to_char_float4'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.to_char(real) IS 'Convert number to string';

CREATE FUNCTION oracle.to_char(num double precision)
RETURNS text
AS 'MODULE_PATHNAME','orafce_to_char_float8'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.to_char(double precision) IS 'Convert number to string';

CREATE FUNCTION oracle.to_char(num numeric)
RETURNS text
AS 'MODULE_PATHNAME','orafce_to_char_numeric'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.to_char(numeric) IS 'Convert number to string';

/*add at 20191230 authored  jinhuajian*/
CREATE FUNCTION oracle.to_char("any")
RETURNS TEXT
AS 'MODULE_PATHNAME','orafce_to_varchar'
LANGUAGE C STABLE STRICT;
COMMENT ON FUNCTION oracle.to_char("any") IS 'Convert text type to string';

CREATE FUNCTION oracle.to_char(text)
RETURNS text
AS 'MODULE_PATHNAME','orafce_to_varchar'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.to_char(text) IS 'Convert text to string';
/*end*/

/*update at 20200323 author jinhuajian*/
CREATE FUNCTION oracle.to_number(str text)
RETURNS numeric
AS 'MODULE_PATHNAME','orafce_to_number'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.to_number(text) IS 'Convert string to number';

CREATE OR REPLACE FUNCTION oracle.to_number(numeric)
RETURNS numeric AS $$
SELECT oracle.to_number($1::text);
$$ LANGUAGE SQL IMMUTABLE;

CREATE OR REPLACE FUNCTION oracle.to_number(numeric,numeric)
RETURNS numeric AS $$
SELECT pg_catalog.to_number($1::text,$2::text);
$$ LANGUAGE SQL IMMUTABLE;

/*add at 20191230 authored  jinhuajian*/
CREATE OR REPLACE FUNCTION oracle.to_number(float)
RETURNS numeric AS $$
SELECT oracle.to_number($1::text);
$$ LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.interval_to_seconds(value interval) 
RETURNS float8
AS 'MODULE_PATHNAME','orafce_interval_to_seconds'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.interval_to_seconds(interval) IS 'trnasfer interval format to seconds';
/*end*/

/*update at 20200102 authored  jinhuajian*/
CREATE FUNCTION oracle.to_dsinterval(text)
 RETURNS interval
AS 'MODULE_PATHNAME','orafce_to_dsinterval'
 LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.to_dsinterval(text) IS 'converts a interval datatype to an INTERVAL DAY TO SECOND type';

/* add begin by sunqk at 2019.06.12 for unite V4.7.7
del by zyl 20201201
CREATE FUNCTION oracle.to_dsinterval(interval)
 RETURNS interval
AS 'MODULE_PATHNAME','hgdb_orafnp_todsinterval'
 LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.to_dsinterval IS 'converts a interval datatype to an INTERVAL DAY TO SECOND type';
add end by sunqk at 2019.06.12 for unite V4.7.7 */
/* del by zyl 20201201
CREATE FUNCTION oracle.to_dsinterval(str text)
RETURNS interval
AS $$ SELECT pg_catalog.interval_in($1::cstring, 0, 268435456); $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.to_dsinterval(text) IS 'converts a character string datatype to an INTERVAL DAY TO SECOND type';
*/
CREATE FUNCTION oracle.to_yminterval(text)
 RETURNS interval
AS 'MODULE_PATHNAME','orafce_to_yminterval'
 LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.to_yminterval(text) IS 'converts a interval datatype to an INTERVAL YEAR TO MONTH type';

/*add at 20200103 authored  jinhuajian*/
CREATE OR REPLACE FUNCTION oracle.to_timestamp_tz(text ,text)
RETURNS TIMESTAMP WITH TIME ZONE
AS $$ SELECT pg_catalog.to_timestamp($1,$2); $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.to_timestamp_tz(text)
RETURNS timestamp with time zone
AS 'MODULE_PATHNAME','orafce_to_timestamp_tz'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
/*end*/
/*Belong to orafce by jinhuajian,add at 20200228*/
CREATE OR REPLACE FUNCTION oracle.hex_to_decimal(text)
RETURNS int8
AS 'MODULE_PATHNAME','orafce_hex_to_decimal'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
CREATE FUNCTION oracle.to_binary_double(VARIADIC "any")
RETURNS float8
AS 'MODULE_PATHNAME','orafce_to_binary_double'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.to_binary_double("any") IS 'double precision';

CREATE FUNCTION oracle.to_binary_float(VARIADIC "any")
RETURNS float4
AS 'MODULE_PATHNAME','orafce_to_binary_float'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.to_binary_float("any") IS 'signle precision';

CREATE FUNCTION oracle.bin_to_num(VARIADIC "any")
RETURNS int8 
AS 'MODULE_PATHNAME','orafce_bin_to_num'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.bin_to_num("any") IS 'Converts a bit vector to its equivalent number.';

CREATE FUNCTION oracle.bitand(numeric, numeric)
RETURNS numeric
AS $$ SELECT ($1::int8 & $2::int8)::numeric; $$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION oracle.bitand(text, text)
RETURNS bigint
AS $$ SELECT ($1::int8 & $2::int8); $$
LANGUAGE sql IMMUTABLE STRICT;
/*end*/

/*add at 20200303 authored  jinhuajian*/
CREATE OR REPLACE FUNCTION oracle.to_timestamp(text ,text)
RETURNS TIMESTAMP WITHOUT TIME ZONE
AS $$ SELECT pg_catalog.to_timestamp($1,$2)::TIMESTAMP WITHOUT TIME ZONE; $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.to_timestamp(double precision)
RETURNS TIMESTAMP WITHOUT TIME ZONE
AS $$ SELECT pg_catalog.to_timestamp($1)::TIMESTAMP WITHOUT TIME ZONE; $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;
/*end*/

/*update at 20200229 by jinhuajian*/
CREATE FUNCTION oracle.to_multi_byte(str text)
RETURNS text
AS 'MODULE_PATHNAME','orafce_to_multi_byte'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.to_multi_byte(text) IS 'Convert all single-byte characters to their corresponding multibyte characters';

CREATE FUNCTION oracle.to_single_byte(str text)
RETURNS text
AS 'MODULE_PATHNAME','orafce_to_single_byte'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.to_single_byte(text) IS 'Convert characters to their corresponding single-byte characters if possible';
/*end*/

/*modify at 2020303 by jinhuajian*/
CREATE FUNCTION sinh(float8)
RETURNS float8 AS
$$ SELECT (exp($1) - exp(-$1)) / 2; $$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION cosh(float8)
RETURNS float8 AS
$$ SELECT (exp($1) + exp(-$1)) / 2; $$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION tanh(float8)
RETURNS float8 AS
$$ SELECT sinh($1) / cosh($1); $$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION oracle.nanvl(float4, float4)
RETURNS float4 AS
$$ SELECT CASE WHEN $1 = 'NaN' THEN $2 ELSE $1 END; $$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION oracle.nanvl(float8, float8)
RETURNS float8 AS
$$ SELECT CASE WHEN $1 = 'NaN' THEN $2 ELSE $1 END; $$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION oracle.nanvl(numeric, numeric)
RETURNS numeric AS
$$ SELECT CASE WHEN $1 = 'NaN' THEN $2 ELSE $1 END; $$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION oracle.nanvl(float4, varchar)
RETURNS float4 AS
$$ SELECT CASE WHEN $1 = 'NaN' THEN $2::float4 ELSE $1 END; $$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION oracle.nanvl(float8, varchar)
RETURNS float8 AS
$$ SELECT CASE WHEN $1 = 'NaN' THEN $2::float8 ELSE $1 END; $$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION oracle.nanvl(numeric, varchar)
RETURNS numeric AS
$$ SELECT CASE WHEN $1 = 'NaN' THEN $2::numeric ELSE $1 END; $$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION oracle.nanvl(real, float8)
RETURNS real AS
$$ SELECT CASE WHEN $1 = 'NaN' THEN $2::real  ELSE $1 END; $$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION oracle.nanvl(float8, real)
RETURNS real AS
$$ SELECT CASE WHEN $1 = 'NaN' THEN $2  ELSE $1::real END; $$
LANGUAGE sql IMMUTABLE STRICT;

/* added begin by luotao at 2020/03/16 */
CREATE FUNCTION oracle.dump(in "any", format numeric, _start numeric, len numeric)
RETURNS varchar
AS 'MODULE_PATHNAME', 'orafce_dump'
LANGUAGE C PARALLEL SAFE;

CREATE FUNCTION oracle.dump(in "any", format numeric, _start numeric)
RETURNS varchar
AS 'MODULE_PATHNAME', 'orafce_dump'
LANGUAGE C PARALLEL SAFE;

CREATE FUNCTION oracle.dump(in "any", format numeric)
RETURNS varchar
AS 'MODULE_PATHNAME', 'orafce_dump'
LANGUAGE C PARALLEL SAFE;

CREATE FUNCTION oracle.dump(in "any")
RETURNS varchar
AS 'MODULE_PATHNAME', 'orafce_dump'
LANGUAGE C PARALLEL SAFE;

/* added end by luotao at 2020/03/16 */
CREATE SCHEMA plvstr;

CREATE FUNCTION plvstr.rvrs(str text, _start int, _end int)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_rvrs'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plvstr.rvrs(text, int, int) IS 'Reverse string or part of string';

CREATE FUNCTION plvstr.rvrs(str text, _start int)
RETURNS text
AS $$ SELECT plvstr.rvrs($1,$2,NULL);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.rvrs(text, int) IS 'Reverse string or part of string';

CREATE FUNCTION plvstr.rvrs(str text)
RETURNS text
AS $$ SELECT plvstr.rvrs($1,1,NULL);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.rvrs(text) IS 'Reverse string or part of string';

CREATE FUNCTION plvstr.normalize(str text)
RETURNS varchar
AS 'MODULE_PATHNAME','plvstr_normalize'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.normalize(text) IS 'Replace white chars by space, replace  spaces by space';

CREATE FUNCTION plvstr.is_prefix(str text, prefix text, cs bool)
RETURNS bool
AS 'MODULE_PATHNAME','plvstr_is_prefix_text'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.is_prefix(text, text, bool) IS 'Returns true, if prefix is prefix of str';

CREATE FUNCTION plvstr.is_prefix(str text, prefix text)
RETURNS bool
AS $$ SELECT plvstr.is_prefix($1,$2,true);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.is_prefix(text, text) IS 'Returns true, if prefix is prefix of str';

CREATE FUNCTION plvstr.is_prefix(str int, prefix int)
RETURNS bool
AS 'MODULE_PATHNAME','plvstr_is_prefix_int'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.is_prefix(int, int) IS 'Returns true, if prefix is prefix of str';

CREATE FUNCTION plvstr.is_prefix(str bigint, prefix bigint)
RETURNS bool
AS 'MODULE_PATHNAME','plvstr_is_prefix_int64'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.is_prefix(bigint, bigint) IS 'Returns true, if prefix is prefix of str';

CREATE FUNCTION plvstr.instr(str text, patt text, _start int, nth int)
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr4'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.instr(text, text, int, int) IS 'Search pattern in string';

CREATE FUNCTION plvstr.instr(str text, patt text, _start int)
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr3'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.instr(text, text, int) IS 'Search pattern in string';

CREATE FUNCTION plvstr.instr(str text, patt text)
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr2'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.instr(text, text) IS 'Search pattern in string';

CREATE FUNCTION plvstr.lpart(str text, div text, _start int, nth int, all_if_notfound bool)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_lpart'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.lpart(text, text, int, int, bool) IS 'Call this function to return the left part of a string';

CREATE FUNCTION plvstr.lpart(str text, div text, _start int, nth int)
RETURNS text
AS $$ SELECT plvstr.lpart($1,$2, $3, $4, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.lpart(text, text, int, int) IS 'Call this function to return the left part of a string';

CREATE FUNCTION plvstr.lpart(str text, div text, _start int)
RETURNS text
AS $$ SELECT plvstr.lpart($1,$2, $3, 1, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.lpart(text, text, int) IS 'Call this function to return the left part of a string';

CREATE FUNCTION plvstr.lpart(str text, div text)
RETURNS text
AS $$ SELECT plvstr.lpart($1,$2, 1, 1, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.lpart(text, text) IS 'Call this function to return the left part of a string';

CREATE FUNCTION plvstr.rpart(str text, div text, _start int, nth int, all_if_notfound bool)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_rpart'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.rpart(text, text, int, int, bool) IS 'Call this function to return the right part of a string';

CREATE FUNCTION plvstr.rpart(str text, div text, _start int, nth int)
RETURNS text
AS $$ SELECT plvstr.rpart($1,$2, $3, $4, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.rpart(text, text, int, int) IS 'Call this function to return the right part of a string';

CREATE FUNCTION plvstr.rpart(str text, div text, _start int)
RETURNS text
AS $$ SELECT plvstr.rpart($1,$2, $3, 1, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.rpart(text, text, int) IS 'Call this function to return the right part of a string';

CREATE FUNCTION plvstr.rpart(str text, div text)
RETURNS text
AS $$ SELECT plvstr.rpart($1,$2, 1, 1, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.rpart(text, text) IS 'Call this function to return the right part of a string';

CREATE FUNCTION plvstr.lstrip(str text, substr text, num int)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_lstrip'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.lstrip(text, text, int) IS 'Call this function to remove characters from the beginning ';

CREATE FUNCTION plvstr.lstrip(str text, substr text)
RETURNS text
AS $$ SELECT plvstr.lstrip($1, $2, 1); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.lstrip(text, text) IS 'Call this function to remove characters from the beginning ';

CREATE FUNCTION plvstr.rstrip(str text, substr text, num int)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_rstrip'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.rstrip(text, text, int) IS 'Call this function to remove characters from the end';

CREATE FUNCTION plvstr.rstrip(str text, substr text)
RETURNS text
AS $$ SELECT plvstr.rstrip($1, $2, 1); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.rstrip(text, text) IS 'Call this function to remove characters from the end';

CREATE FUNCTION plvstr.swap(str text, replace text, _start int, length int)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_swap'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plvstr.swap(text,text, int, int) IS 'Replace a substring in a string with a specified string';

CREATE FUNCTION plvstr.swap(str text, replace text)
RETURNS text
AS $$ SELECT plvstr.swap($1,$2,1, NULL);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.swap(text,text) IS 'Replace a substring in a string with a specified string';

CREATE FUNCTION plvstr.betwn(str text, _start int, _end int, inclusive bool)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_betwn_i'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.betwn(text, int, int, bool) IS 'Find the Substring Between Start and End Locations';

CREATE FUNCTION plvstr.betwn(str text, _start int, _end int)
RETURNS text
AS $$ SELECT plvstr.betwn($1,$2,$3,true);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.betwn(text, int, int) IS 'Find the Substring Between Start and End Locations';

CREATE FUNCTION plvstr.betwn(str text, _start text, _end text, startnth int, endnth int, inclusive bool, gotoend bool)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_betwn_c'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plvstr.betwn(text, text, text, int, int, bool, bool) IS 'Find the Substring Between Start and End Locations';

CREATE FUNCTION plvstr.betwn(str text, _start text, _end text)
RETURNS text
AS $$ SELECT plvstr.betwn($1,$2,$3,1,1,true,false);$$
LANGUAGE SQL IMMUTABLE;
COMMENT ON FUNCTION plvstr.betwn(text, text, text) IS 'Find the Substring Between Start and End Locations';

CREATE FUNCTION plvstr.betwn(str text, _start text, _end text, startnth int, endnth int)
RETURNS text
AS $$ SELECT plvstr.betwn($1,$2,$3,$4,$5,true,false);$$
LANGUAGE SQL IMMUTABLE;
COMMENT ON FUNCTION plvstr.betwn(text, text, text, int, int) IS 'Find the Substring Between Start and End Locations';

--------------------------------------------------------------------------------
--compatible v4 plvstr
--------------------------------------------------------------------------------
CREATE FUNCTION oracle.plvstr_rvrs(str text, _start int, _end int)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_rvrs'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plvstr_rvrs(text, int, int) IS 'Reverse string or part of string';

CREATE FUNCTION oracle.plvstr_rvrs(str text, _start int)
RETURNS text
AS $$ SELECT oracle.plvstr_rvrs($1,$2,NULL);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_rvrs(text, int) IS 'Reverse string or part of string';

CREATE FUNCTION oracle.plvstr_rvrs(str text)
RETURNS text
AS $$ SELECT oracle.plvstr_rvrs($1,1,NULL);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_rvrs(text) IS 'Reverse string or part of string';

CREATE FUNCTION oracle.plvstr_normalize(str text)
RETURNS varchar
AS 'MODULE_PATHNAME','plvstr_normalize'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_normalize(text) IS 'Replace white chars by space, replace  spaces by space';

CREATE FUNCTION oracle.plvstr_is_prefix(str text, prefix text, cs bool)
RETURNS bool
AS 'MODULE_PATHNAME','plvstr_is_prefix_text'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_is_prefix(text, text, bool) IS 'Returns true, if prefix is prefix of str';

CREATE FUNCTION oracle.plvstr_is_prefix(str text, prefix text)
RETURNS bool
AS $$ SELECT oracle.plvstr_is_prefix($1,$2,true);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_is_prefix(text, text) IS 'Returns true, if prefix is prefix of str';

CREATE FUNCTION oracle.plvstr_is_prefix(str int, prefix int)
RETURNS bool
AS 'MODULE_PATHNAME','plvstr_is_prefix_int'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_is_prefix(int, int) IS 'Returns true, if prefix is prefix of str';

CREATE FUNCTION oracle.plvstr_is_prefix(str bigint, prefix bigint)
RETURNS bool
AS 'MODULE_PATHNAME','plvstr_is_prefix_int64'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_is_prefix(bigint, bigint) IS 'Returns true, if prefix is prefix of str';

CREATE FUNCTION oracle.plvstr_instr(str text, patt text, _start int, nth int)
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr4'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_instr(text, text, int, int) IS 'Search pattern in string';

CREATE FUNCTION oracle.plvstr_instr(str text, patt text, _start int)
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr3'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_instr(text, text, int) IS 'Search pattern in string';

CREATE FUNCTION oracle.plvstr_instr(str text, patt text)
RETURNS int
AS 'MODULE_PATHNAME','plvstr_instr2'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_instr(text, text) IS 'Search pattern in string';

CREATE FUNCTION oracle.plvstr_lpart(str text, div text, _start int, nth int, all_if_notfound bool)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_lpart'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_lpart(text, text, int, int, bool) IS 'Call this function to return the left part of a string';

CREATE FUNCTION oracle.plvstr_lpart(str text, div text, _start int, nth int)
RETURNS text
AS $$ SELECT oracle.plvstr_lpart($1,$2, $3, $4, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_lpart(text, text, int, int) IS 'Call this function to return the left part of a string';

CREATE FUNCTION oracle.plvstr_lpart(str text, div text, _start int)
RETURNS text
AS $$ SELECT oracle.plvstr_lpart($1,$2, $3, 1, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_lpart(text, text, int) IS 'Call this function to return the left part of a string';

CREATE FUNCTION oracle.plvstr_lpart(str text, div text)
RETURNS text
AS $$ SELECT oracle.plvstr_lpart($1,$2, 1, 1, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_lpart(text, text) IS 'Call this function to return the left part of a string';

CREATE FUNCTION oracle.plvstr_rpart(str text, div text, _start int, nth int, all_if_notfound bool)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_rpart'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_rpart(text, text, int, int, bool) IS 'Call this function to return the right part of a string';

CREATE FUNCTION oracle.plvstr_rpart(str text, div text, _start int, nth int)
RETURNS text
AS $$ SELECT oracle.plvstr_rpart($1,$2, $3, $4, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_rpart(text, text, int, int) IS 'Call this function to return the right part of a string';

CREATE FUNCTION oracle.plvstr_rpart(str text, div text, _start int)
RETURNS text
AS $$ SELECT oracle.plvstr_rpart($1,$2, $3, 1, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_rpart(text, text, int) IS 'Call this function to return the right part of a string';

CREATE FUNCTION oracle.plvstr_rpart(str text, div text)
RETURNS text
AS $$ SELECT oracle.plvstr_rpart($1,$2, 1, 1, false); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_rpart(text, text) IS 'Call this function to return the right part of a string';

CREATE FUNCTION oracle.plvstr_lstrip(str text, substr text, num int)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_lstrip'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_lstrip(text, text, int) IS 'Call this function to remove characters from the beginning ';

CREATE FUNCTION oracle.plvstr_lstrip(str text, substr text)
RETURNS text
AS $$ SELECT oracle.plvstr_lstrip($1, $2, 1); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_lstrip(text, text) IS 'Call this function to remove characters from the beginning ';

CREATE FUNCTION oracle.plvstr_rstrip(str text, substr text, num int)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_rstrip'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_rstrip(text, text, int) IS 'Call this function to remove characters from the end';

CREATE FUNCTION oracle.plvstr_rstrip(str text, substr text)
RETURNS text
AS $$ SELECT oracle.plvstr_rstrip($1, $2, 1); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_rstrip(text, text) IS 'Call this function to remove characters from the end';

CREATE FUNCTION oracle.plvstr_swap(str text, replace text, _start int, length int)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_swap'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plvstr_swap(text,text, int, int) IS 'Replace a substring in a string with a specified string';

CREATE FUNCTION oracle.plvstr_swap(str text, replace text)
RETURNS text
AS $$ SELECT oracle.plvstr_swap($1,$2,1, NULL);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_swap(text,text) IS 'Replace a substring in a string with a specified string';

CREATE FUNCTION oracle.plvstr_betwn(str text, _start int, _end int, inclusive bool)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_betwn_i'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_betwn(text, int, int, bool) IS 'Find the Substring Between Start and End Locations';

CREATE FUNCTION oracle.plvstr_betwn(str text, _start int, _end int)
RETURNS text
AS $$ SELECT oracle.plvstr_betwn($1,$2,$3,true);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvstr_betwn(text, int, int) IS 'Find the Substring Between Start and End Locations';

CREATE FUNCTION oracle.plvstr_betwn(str text, _start text, _end text, startnth int, endnth int, inclusive bool, gotoend bool)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_betwn_c'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plvstr_betwn(text, text, text, int, int, bool, bool) IS 'Find the Substring Between Start and End Locations';

CREATE FUNCTION oracle.plvstr_betwn(str text, _start text, _end text)
RETURNS text
AS $$ SELECT oracle.plvstr_betwn($1,$2,$3,1,1,true,false);$$
LANGUAGE SQL IMMUTABLE;
COMMENT ON FUNCTION oracle.plvstr_betwn(text, text, text) IS 'Find the Substring Between Start and End Locations';

CREATE FUNCTION oracle.plvstr_betwn(str text, _start text, _end text, startnth int, endnth int)
RETURNS text
AS $$ SELECT oracle.plvstr_betwn($1,$2,$3,$4,$5,true,false);$$
LANGUAGE SQL IMMUTABLE;
COMMENT ON FUNCTION oracle.plvstr_betwn(text, text, text, int, int) IS 'Find the Substring Between Start and End Locations';
-- end v4 plvstr

CREATE FUNCTION oracle.lnnvl(bool)
RETURNS bool
AS 'MODULE_PATHNAME','ora_lnnvl'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.lnnvl(bool) IS '';

-- can't overwrite PostgreSQL functions!!!!

------------------------------------------------------------------------
--compatible date functions.
CREATE FUNCTION oracle.add_months(TIMESTAMP WITH TIME ZONE,INTEGER)
RETURNS oracle.date
AS $$ SELECT (oracle.add_months($1::pg_catalog.date, $2) + $1::time)::oracle.date; $$
LANGUAGE SQL IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION oracle.last_day(TIMESTAMPTZ)
RETURNS oracle.date
AS $$ SELECT (date_trunc('MONTH', $1) + INTERVAL '1 MONTH ' - INTERVAL '1 day' + $1::time)::oracle.date; $$
LANGUAGE SQL IMMUTABLE STRICT;

CREATE FUNCTION oracle.months_between(TIMESTAMPTZ, TIMESTAMPTZ)
RETURNS numeric
AS 'MODULE_PATHNAME','months_betweentimestamptz'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.months_between(TIMESTAMPTZ, TIMESTAMPTZ) IS 'The months difference between the two timestamp values';;

CREATE FUNCTION oracle.next_day(TIMESTAMP WITH TIME ZONE,INTEGER)
RETURNS oracle.date
AS $$ SELECT (oracle.next_day($1::pg_catalog.date,$2) + $1::time)::oracle.date; $$
LANGUAGE SQL IMMUTABLE STRICT;

CREATE FUNCTION oracle.next_day(TIMESTAMP WITH TIME ZONE,TEXT)
RETURNS oracle.date
AS $$ SELECT (oracle.next_day($1::pg_catalog.date,$2) + $1::time)::oracle.date; $$
LANGUAGE SQL IMMUTABLE STRICT;
--end
-----------------------------------------------------------------------------------------

CREATE FUNCTION oracle.to_date(str text)
RETURNS oracle.date
AS 'MODULE_PATHNAME','ora_to_date'
LANGUAGE C STABLE STRICT;
COMMENT ON FUNCTION oracle.to_date(text) IS 'Convert string to timestamp';

CREATE OR REPLACE FUNCTION oracle.to_date(TEXT,TEXT)
RETURNS oracle.date
AS $$ SELECT pg_catalog.TO_TIMESTAMP($1,$2)::oracle.date; $$
LANGUAGE SQL IMMUTABLE STRICT;


/*add at 20200229 by jinhuajian*/
CREATE OR REPLACE FUNCTION oracle.to_date(bigint, text)
RETURNS oracle.date
AS $$ SELECT pg_catalog.TO_TIMESTAMP($1::text,$2)::oracle.date; $$
LANGUAGE SQL IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION oracle.to_date(timestamp, text)
RETURNS oracle.date
AS $$ SELECT pg_catalog.TO_TIMESTAMP($1::text,$2)::oracle.date; $$
LANGUAGE SQL IMMUTABLE STRICT;

CREATE FUNCTION oracle.to_char(timestamp)
RETURNS TEXT
AS 'MODULE_PATHNAME','orafce_to_char_timestamp'
LANGUAGE C STABLE STRICT;
COMMENT ON FUNCTION oracle.to_char(timestamp) IS 'Convert timestamp to string';

CREATE FUNCTION oracle.sysdate()
RETURNS oracle.date
AS 'MODULE_PATHNAME','orafce_sysdate'
LANGUAGE C STABLE STRICT;
COMMENT ON FUNCTION oracle.sysdate() IS 'Returns statement timestamp at server time zone';

CREATE FUNCTION oracle.sessiontimezone()
RETURNS text
AS 'MODULE_PATHNAME','orafce_sessiontimezone'
LANGUAGE C STABLE STRICT;
COMMENT ON FUNCTION oracle.sessiontimezone() IS 'Returns session time zone';

CREATE FUNCTION oracle.orafce_timezone()
RETURNS text
AS 'MODULE_PATHNAME','orafce_dbtimezone'
LANGUAGE C STABLE STRICT;
COMMENT ON FUNCTION oracle.orafce_timezone() IS 'Returns server time zone (orafce.timezone)';

CREATE FUNCTION oracle.dbtimezone()
RETURNS text
AS 'MODULE_PATHNAME','orafce_sessiontimezone'
LANGUAGE C STABLE STRICT;
COMMENT ON FUNCTION oracle.dbtimezone() IS 'Returns session time zone';

-- emulation of dual table
CREATE VIEW oracle.dual AS SELECT 'X'::varchar AS dummy;
REVOKE ALL ON oracle.dual FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.dual TO PUBLIC;

-- this packege is emulation of dbms_output Oracle packege
--

CREATE SCHEMA dbms_output;

CREATE FUNCTION dbms_output.enable(IN buffer_size int4)
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_enable'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_output.enable(IN int4) IS 'Enable package functionality';

CREATE FUNCTION dbms_output.enable()
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_enable_default'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_output.enable() IS 'Enable package functionality';

CREATE FUNCTION dbms_output.disable()
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_disable'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_output.disable() IS 'Disable package functionality';

CREATE FUNCTION dbms_output.serveroutput(IN bool)
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_serveroutput'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_output.serveroutput(IN bool) IS 'Set drowing output';

CREATE FUNCTION dbms_output.put(IN a text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_put'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_output.put(IN text) IS 'Put some text to output';

CREATE FUNCTION dbms_output.put_line(IN a text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_put_line'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_output.put_line(IN text) IS 'Put line to output';

CREATE FUNCTION dbms_output.new_line()
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_new_line'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_output.new_line() IS 'Put new line char to output';

CREATE FUNCTION dbms_output.get_line(OUT line text, OUT status int4)
AS 'MODULE_PATHNAME','dbms_output_get_line'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_output.get_line(OUT text, OUT int4) IS 'Get line from output buffer';

CREATE FUNCTION dbms_output.get_lines(OUT lines text[], INOUT numlines int4)
AS 'MODULE_PATHNAME','dbms_output_get_lines'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_output.get_lines(OUT text[], INOUT int4) IS 'Get lines from output buffer';

---------------------------------------------------------------------------------
--compatible v4 dbms_output_
---------------------------------------------------------------------------------
CREATE FUNCTION oracle.dbms_output_enable(IN buffer_size int4)
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_enable'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_output_enable(IN int4) IS 'Enable package functionality';

CREATE FUNCTION oracle.dbms_output_enable()
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_enable_default'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_output_enable() IS 'Enable package functionality';

CREATE FUNCTION oracle.dbms_output_disable()
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_disable'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_output_disable() IS 'Disable package functionality';

CREATE FUNCTION oracle.dbms_output_serveroutput(IN bool)
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_serveroutput'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_output_serveroutput(IN bool) IS 'Set drowing output';

CREATE FUNCTION oracle.dbms_output_put(IN a text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_put'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_output_put(IN text) IS 'Put some text to output';

CREATE FUNCTION oracle.dbms_output_put_line(IN a text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_put_line'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_output_put_line(IN text) IS 'Put line to output';

CREATE FUNCTION oracle.dbms_output_new_line()
RETURNS void
AS 'MODULE_PATHNAME','dbms_output_new_line'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_output_new_line() IS 'Put new line char to output';

CREATE FUNCTION oracle.dbms_output_get_line(OUT line text, OUT status int4)
AS 'MODULE_PATHNAME','dbms_output_get_line'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_output_get_line(OUT text, OUT int4) IS 'Get line from output buffer';

CREATE FUNCTION oracle.dbms_output_get_lines(OUT lines text[], INOUT numlines int4)
AS 'MODULE_PATHNAME','dbms_output_get_lines'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_output_get_lines(OUT text[], INOUT int4) IS 'Get lines from output buffer';
--end v4 dbms_output_

-- others functions

CREATE FUNCTION oracle.nvl(anyelement, anyelement)
RETURNS anyelement
AS 'MODULE_PATHNAME','ora_nvl'
LANGUAGE C IMMUTABLE;

-------------------------------------------------------------------------------------------------------
--compatible dev group
CREATE OR REPLACE FUNCTION oracle.nvl(numeric, int)
RETURNS numeric AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE;

CREATE OR REPLACE FUNCTION oracle.nvl(float8, bigint)
RETURNS float8 AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(float8, integer)
RETURNS float8 AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(float8, numeric)
RETURNS float8 AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(integer, bigint)
RETURNS bigint AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(integer, numeric)
RETURNS numeric AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(numeric, bigint)
RETURNS numeric AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(numeric, integer)
RETURNS numeric AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(real, bigint)
RETURNS real AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(real, integer)
RETURNS real AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(real, numeric)
RETURNS real AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(smallint, bigint)
RETURNS bigint AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(smallint, integer)
RETURNS integer AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(smallint, numeric)
RETURNS numeric AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.nvl(bigint, numeric)
RETURNS numeric AS $$
SELECT coalesce($1, $2)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE;
-------------------------------------------------------------------------------------------------------

CREATE FUNCTION oracle.nvl2(anyelement, anyelement, anyelement)
RETURNS anyelement
AS 'MODULE_PATHNAME','ora_nvl2'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.nvl2(anyelement, anyelement, anyelement) IS '';

CREATE FUNCTION oracle.decode("any", "any", text)
RETURNS text
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", text, VARIADIC "any")
RETURNS text
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", bpchar)
RETURNS bpchar
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", bpchar, VARIADIC "any")
RETURNS bpchar
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", integer)
RETURNS integer
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", integer, VARIADIC "any")
RETURNS integer
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", bigint)
RETURNS bigint
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", bigint, VARIADIC "any")
RETURNS bigint
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", name)
RETURNS name
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", name, VARIADIC "any")
RETURNS name
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", numeric)
RETURNS numeric
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", numeric, VARIADIC "any")
RETURNS numeric
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", date)
RETURNS date
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", date, VARIADIC "any")
RETURNS date
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", time)
RETURNS time
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", time, VARIADIC "any")
RETURNS time
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", timestamp)
RETURNS timestamp
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", timestamp, VARIADIC "any")
RETURNS timestamp
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", timestamptz)
RETURNS timestamptz
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", timestamptz, VARIADIC "any")
RETURNS timestamptz
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", cstring)
RETURNS cstring
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", cstring, VARIADIC "any")
RETURNS cstring
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", unknown, VARIADIC "any")
RETURNS unknown
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", unknown)
RETURNS unknown
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", boolean)
RETURNS boolean
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", boolean, VARIADIC "any")
RETURNS boolean
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", float8)
RETURNS float8
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", float8, VARIADIC "any")
RETURNS float8
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", smallint)
RETURNS smallint
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", smallint, VARIADIC "any")
RETURNS smallint
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", float4)
RETURNS float4
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", float4, VARIADIC "any")
RETURNS float4
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", timetz)
RETURNS timetz
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;

CREATE FUNCTION oracle.decode("any", "any", timetz, VARIADIC "any")
RETURNS timetz
AS 'MODULE_PATHNAME', 'ora_decode'
LANGUAGE C IMMUTABLE PARALLEL SAFE;


CREATE SCHEMA dbms_pipe;

CREATE FUNCTION dbms_pipe.pack_message(text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_text'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.pack_message(text) IS 'Add text field to message';

CREATE FUNCTION dbms_pipe.unpack_message_text()
RETURNS text
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_text'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_pipe.unpack_message_text() IS 'Get text fiedl from message';

CREATE FUNCTION dbms_pipe.receive_message(text, int)
RETURNS int
AS 'MODULE_PATHNAME','dbms_pipe_receive_message'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_pipe.receive_message(text, int) IS 'Receive message from pipe';

CREATE FUNCTION dbms_pipe.receive_message(text)
RETURNS int
AS $$SELECT dbms_pipe.receive_message($1,NULL::int);$$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION dbms_pipe.receive_message(text) IS 'Receive message from pipe';

CREATE FUNCTION dbms_pipe.send_message(text, int, int)
RETURNS int
AS 'MODULE_PATHNAME','dbms_pipe_send_message'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_pipe.send_message(text, int, int) IS 'Send message to pipe';

CREATE FUNCTION dbms_pipe.send_message(text, int)
RETURNS int
AS $$SELECT dbms_pipe.send_message($1,$2,NULL);$$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION dbms_pipe.send_message(text, int) IS 'Send message to pipe';

CREATE FUNCTION dbms_pipe.send_message(text)
RETURNS int
AS $$SELECT dbms_pipe.send_message($1,NULL,NULL);$$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION dbms_pipe.send_message(text) IS 'Send message to pipe';

CREATE FUNCTION dbms_pipe.unique_session_name()
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_pipe_unique_session_name'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.unique_session_name() IS 'Returns unique session name';

CREATE FUNCTION dbms_pipe.__list_pipes()
RETURNS SETOF RECORD
AS 'MODULE_PATHNAME','dbms_pipe_list_pipes'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.__list_pipes() IS '';

CREATE VIEW dbms_pipe.db_pipes
AS SELECT * FROM dbms_pipe.__list_pipes() AS (Name varchar, Items int, Size int, "limit" int, "private" bool, "owner" varchar);

CREATE FUNCTION dbms_pipe.next_item_type()
RETURNS int
AS 'MODULE_PATHNAME','dbms_pipe_next_item_type'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.next_item_type() IS 'Returns type of next field in message';

CREATE FUNCTION dbms_pipe.create_pipe(text, int, bool)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_create_pipe'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_pipe.create_pipe(text, int, bool) IS 'Create named pipe';

CREATE FUNCTION dbms_pipe.create_pipe(text, int)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_create_pipe_2'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_pipe.create_pipe(text, int) IS 'Create named pipe';

CREATE FUNCTION dbms_pipe.create_pipe(text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_create_pipe_1'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_pipe.create_pipe(text) IS 'Create named pipe';

CREATE FUNCTION dbms_pipe.reset_buffer()
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_reset_buffer'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_pipe.reset_buffer() IS 'Clean input buffer';

CREATE FUNCTION dbms_pipe.purge(text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_purge'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.purge(text) IS 'Clean pipe';

CREATE FUNCTION dbms_pipe.remove_pipe(text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_remove_pipe'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.remove_pipe(text) IS 'Destroy pipe';

CREATE FUNCTION dbms_pipe.pack_message(pg_catalog.date)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_date'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.pack_message(pg_catalog.date) IS 'Add date field to message';

CREATE FUNCTION dbms_pipe.unpack_message_date()
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_date'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.unpack_message_date() IS 'Get date field from message';

CREATE FUNCTION dbms_pipe.pack_message(timestamp with time zone)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_timestamp'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.pack_message(timestamp with time zone) IS 'Add timestamp field to message';

CREATE FUNCTION dbms_pipe.unpack_message_timestamp()
RETURNS timestamp with time zone
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_timestamp'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.unpack_message_timestamp() IS 'Get timestamp field from message';

CREATE FUNCTION dbms_pipe.pack_message(numeric)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_number'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.pack_message(numeric) IS 'Add numeric field to message';

CREATE FUNCTION dbms_pipe.unpack_message_number()
RETURNS numeric
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_number'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.unpack_message_number() IS 'Get numeric field from message';

CREATE FUNCTION dbms_pipe.pack_message(integer)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_integer'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.pack_message(integer) IS 'Add numeric field to message';

CREATE FUNCTION dbms_pipe.pack_message(bigint)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_bigint'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.pack_message(bigint) IS 'Add numeric field to message';

CREATE FUNCTION dbms_pipe.pack_message(bytea)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_bytea'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.pack_message(bytea) IS 'Add bytea field to message';

CREATE FUNCTION dbms_pipe.unpack_message_bytea()
RETURNS bytea
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_bytea'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.unpack_message_bytea() IS 'Get bytea field from message';

CREATE FUNCTION dbms_pipe.pack_message(record)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_record'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.pack_message(record) IS 'Add record field to message';

CREATE FUNCTION dbms_pipe.unpack_message_record()
RETURNS record
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_record'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_pipe.unpack_message_record() IS 'Get record field from message';

------------------------------------------------------------------------------------
--compatible v4 dbms_pipe_
------------------------------------------------------------------------------------
CREATE FUNCTION oracle.dbms_pipe_pack_message(text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_text'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_pack_message(text) IS 'Add text field to message';

CREATE FUNCTION oracle.dbms_pipe_unpack_message_text()
RETURNS text
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_text'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_pipe_unpack_message_text() IS 'Get text fiedl from message';

CREATE FUNCTION oracle.dbms_pipe_receive_message(text, int)
RETURNS int
AS 'MODULE_PATHNAME','dbms_pipe_receive_message'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_pipe_receive_message(text, int) IS 'Receive message from pipe';

CREATE FUNCTION oracle.dbms_pipe_receive_message(text)
RETURNS int
AS $$SELECT oracle.dbms_pipe_receive_message($1,NULL::int);$$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.dbms_pipe_receive_message(text) IS 'Receive message from pipe';

CREATE FUNCTION oracle.dbms_pipe_send_message(text, int, int)
RETURNS int
AS 'MODULE_PATHNAME','dbms_pipe_send_message'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_pipe_send_message(text, int, int) IS 'Send message to pipe';

CREATE FUNCTION oracle.dbms_pipe_send_message(text, int)
RETURNS int
AS $$SELECT oracle.dbms_pipe_send_message($1,$2,NULL);$$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.dbms_pipe_send_message(text, int) IS 'Send message to pipe';

CREATE FUNCTION oracle.dbms_pipe_send_message(text)
RETURNS int
AS $$SELECT oracle.dbms_pipe_send_message($1,NULL,NULL);$$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.dbms_pipe_send_message(text) IS 'Send message to pipe';

CREATE FUNCTION oracle.dbms_pipe_unique_session_name()
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_pipe_unique_session_name'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_unique_session_name() IS 'Returns unique session name';

CREATE FUNCTION oracle.dbms_pipe_list_pipes()
RETURNS SETOF RECORD
AS 'MODULE_PATHNAME','dbms_pipe_list_pipes'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_list_pipes() IS '';

CREATE VIEW oracle.dbms_pipe_db_pipes
AS SELECT * FROM oracle.dbms_pipe_list_pipes() AS (Name varchar, Items int, Size int, "limit" int, "private" bool, "owner" varchar);

CREATE FUNCTION oracle.dbms_pipe_next_item_type()
RETURNS int
AS 'MODULE_PATHNAME','dbms_pipe_next_item_type'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_next_item_type() IS 'Returns type of next field in message';

CREATE FUNCTION oracle.dbms_pipe_create_pipe(text, int, bool)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_create_pipe'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_pipe_create_pipe(text, int, bool) IS 'Create named pipe';

CREATE FUNCTION oracle.dbms_pipe_create_pipe(text, int)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_create_pipe_2'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_pipe_create_pipe(text, int) IS 'Create named pipe';

CREATE FUNCTION oracle.dbms_pipe_create_pipe(text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_create_pipe_1'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_pipe_create_pipe(text) IS 'Create named pipe';

CREATE FUNCTION oracle.dbms_pipe_reset_buffer()
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_reset_buffer'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_pipe_reset_buffer() IS 'Clean input buffer';

CREATE FUNCTION oracle.dbms_pipe_purge(text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_purge'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_purge(text) IS 'Clean pipe';

CREATE FUNCTION oracle.dbms_pipe_remove_pipe(text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_remove_pipe'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_remove_pipe(text) IS 'Destroy pipe';

CREATE FUNCTION oracle.dbms_pipe_pack_message(pg_catalog.date)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_date'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_pack_message(pg_catalog.date) IS 'Add date field to message';

CREATE FUNCTION oracle.dbms_pipe_unpack_message_date()
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_date'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_unpack_message_date() IS 'Get date field from message';

CREATE FUNCTION oracle.dbms_pipe_pack_message(timestamp with time zone)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_timestamp'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_pack_message(timestamp with time zone) IS 'Add timestamp field to message';

CREATE FUNCTION oracle.dbms_pipe_unpack_message_timestamp()
RETURNS timestamp with time zone
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_timestamp'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_unpack_message_timestamp() IS 'Get timestamp field from message';

CREATE FUNCTION oracle.dbms_pipe_pack_message(numeric)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_number'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_pack_message(numeric) IS 'Add numeric field to message';

CREATE FUNCTION oracle.dbms_pipe_unpack_message_number()
RETURNS numeric
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_number'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_unpack_message_number() IS 'Get numeric field from message';

CREATE FUNCTION oracle.dbms_pipe_pack_message(integer)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_integer'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_pack_message(integer) IS 'Add numeric field to message';

CREATE FUNCTION oracle.dbms_pipe_pack_message(bigint)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_bigint'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_pack_message(bigint) IS 'Add numeric field to message';

CREATE FUNCTION oracle.dbms_pipe_pack_message(bytea)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_bytea'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_pack_message(bytea) IS 'Add bytea field to message';

CREATE FUNCTION oracle.dbms_pipe_unpack_message_bytea()
RETURNS bytea
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_bytea'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_unpack_message_bytea() IS 'Get bytea field from message';

CREATE FUNCTION oracle.dbms_pipe_pack_message(record)
RETURNS void
AS 'MODULE_PATHNAME','dbms_pipe_pack_message_record'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_pack_message(record) IS 'Add record field to message';

CREATE FUNCTION oracle.dbms_pipe_unpack_message_record()
RETURNS record
AS 'MODULE_PATHNAME','dbms_pipe_unpack_message_record'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_pipe_unpack_message_record() IS 'Get record field from message';
--end v4 dbms_pipe

-- follow package PLVdate emulation

CREATE SCHEMA plvdate;

CREATE FUNCTION plvdate.add_bizdays(pg_catalog.date, int)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','plvdate_add_bizdays'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.add_bizdays(pg_catalog.date, int) IS 'Get the date created by adding <n> business days to a date';

CREATE FUNCTION plvdate.add_bizdays(timestamptz, int)
RETURNS oracle.date
AS 'select plvdate.add_bizdays($1::pg_catalog.date, $2)::oracle.date'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.add_bizdays(timestamptz, int) IS 'Get the date created by adding <n> business days to a date';

CREATE FUNCTION plvdate.nearest_bizday(pg_catalog.date)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','plvdate_nearest_bizday'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.nearest_bizday(pg_catalog.date) IS 'Get the nearest business date to a given date, user defined';

CREATE FUNCTION plvdate.nearest_bizday(timestamptz)
RETURNS oracle.date
AS 'select plvdate.nearest_bizday($1::pg_catalog.date)::oracle.date'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.nearest_bizday(timestamptz) IS 'Get the nearest business date to a given date, user defined';

CREATE FUNCTION plvdate.next_bizday(pg_catalog.date)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','plvdate_next_bizday'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.next_bizday(pg_catalog.date) IS 'Get the next business date from a given date, user defined';

CREATE FUNCTION plvdate.next_bizday(timestamptz)
RETURNS oracle.date
AS 'select plvdate.next_bizday($1::pg_catalog.date)::oracle.date'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.next_bizday(timestamptz) IS 'Get the next business date from a given date, user defined';

CREATE FUNCTION plvdate.bizdays_between(pg_catalog.date, pg_catalog.date)
RETURNS int
AS 'MODULE_PATHNAME','plvdate_bizdays_between'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.bizdays_between(pg_catalog.date, pg_catalog.date) IS 'Get the number of business days between two dates';

CREATE FUNCTION plvdate.bizdays_between(timestamptz, timestamptz)
RETURNS int
AS 'select plvdate.bizdays_between($1::pg_catalog.date, $2::pg_catalog.date)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.bizdays_between(timestamptz, timestamptz) IS 'Get the number of business days between two dates';

CREATE FUNCTION plvdate.prev_bizday(pg_catalog.date)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','plvdate_prev_bizday'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.prev_bizday(pg_catalog.date) IS 'Get the previous business date from a given date';

CREATE FUNCTION plvdate.prev_bizday(timestamptz)
RETURNS oracle.date
AS 'select plvdate.prev_bizday($1::pg_catalog.date)::oracle.date'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.prev_bizday(timestamptz) IS 'Get the previous business date from a given date';

CREATE FUNCTION plvdate.isbizday(pg_catalog.date)
RETURNS bool
AS 'MODULE_PATHNAME','plvdate_isbizday'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.isbizday(pg_catalog.date) IS 'Call this function to determine if a date is a business day';

CREATE FUNCTION plvdate.isbizday(timestamptz)
RETURNS bool
AS 'select plvdate.isbizday($1::pg_catalog.date)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvdate.isbizday(timestamptz) IS 'Call this function to determine if a date is a business day';

CREATE FUNCTION plvdate.set_nonbizday(text)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_set_nonbizday_dow'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.set_nonbizday(text) IS 'Set day of week as non bussines day';

CREATE FUNCTION plvdate.unset_nonbizday(text)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_unset_nonbizday_dow'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.unset_nonbizday(text) IS 'Unset day of week as non bussines day';

CREATE FUNCTION plvdate.set_nonbizday(pg_catalog.date, bool)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_set_nonbizday_day'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.set_nonbizday(pg_catalog.date, bool) IS 'Set day as non bussines day, if repeat is true, then day is nonbiz every year';

CREATE FUNCTION plvdate.set_nonbizday(timestamptz, bool)
RETURNS void
AS 'select plvdate.set_nonbizday($1::pg_catalog.date, $2)'
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.set_nonbizday(timestamptz, bool) IS 'Set day as non bussines day, if repeat is true, then day is nonbiz every year';

CREATE FUNCTION plvdate.unset_nonbizday(pg_catalog.date, bool)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_unset_nonbizday_day'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.unset_nonbizday(pg_catalog.date, bool) IS 'Unset day as non bussines day, if repeat is true, then day is nonbiz every year';

CREATE FUNCTION plvdate.unset_nonbizday(timestamptz, bool)
RETURNS void
AS 'select plvdate.unset_nonbizday($1::pg_catalog.date, $2)'
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.unset_nonbizday(timestamptz, bool) IS 'Unset day as non bussines day, if repeat is true, then day is nonbiz every year';

CREATE FUNCTION plvdate.set_nonbizday(pg_catalog.date)
RETURNS bool
AS $$SELECT plvdate.set_nonbizday($1, false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.set_nonbizday(pg_catalog.date) IS 'Set day as non bussines day';

CREATE FUNCTION plvdate.set_nonbizday(timestamptz)
RETURNS bool
AS $$SELECT plvdate.set_nonbizday($1::pg_catalog.date, false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.set_nonbizday(timestamptz) IS 'Set day as non bussines day';

CREATE FUNCTION plvdate.unset_nonbizday(pg_catalog.date)
RETURNS bool
AS $$SELECT plvdate.unset_nonbizday($1, false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.unset_nonbizday(pg_catalog.date) IS 'Unset day as non bussines day';

CREATE FUNCTION plvdate.unset_nonbizday(timestamptz)
RETURNS bool
AS $$SELECT plvdate.unset_nonbizday($1::pg_catalog.date, false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.unset_nonbizday(timestamptz) IS 'Unset day as non bussines day';

CREATE FUNCTION plvdate.use_easter(bool)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_use_easter'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.use_easter(bool) IS 'Easter Sunday and easter monday will be holiday';

CREATE FUNCTION plvdate.use_easter()
RETURNS bool
AS $$SELECT plvdate.use_easter(true); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.use_easter() IS 'Easter Sunday and easter monday will be holiday';

CREATE FUNCTION plvdate.unuse_easter()
RETURNS bool
AS $$SELECT plvdate.use_easter(false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.unuse_easter() IS 'Easter Sunday and easter monday will not be holiday';

CREATE FUNCTION plvdate.using_easter()
RETURNS bool
AS 'MODULE_PATHNAME','plvdate_using_easter'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.using_easter() IS 'Use easter?';

CREATE FUNCTION plvdate.use_great_friday(bool)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_use_great_friday'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.use_great_friday(bool) IS 'Great Friday will be holiday';

CREATE FUNCTION plvdate.use_great_friday()
RETURNS bool
AS $$SELECT plvdate.use_great_friday(true); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.use_great_friday() IS 'Great Friday will be holiday';

CREATE FUNCTION plvdate.unuse_great_friday()
RETURNS bool
AS $$SELECT plvdate.use_great_friday(false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.unuse_great_friday() IS 'Great Friday will not be holiday';

CREATE FUNCTION plvdate.using_great_friday()
RETURNS bool
AS 'MODULE_PATHNAME','plvdate_using_great_friday'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.using_great_friday() IS 'Use Great Friday?';

CREATE FUNCTION plvdate.include_start(bool)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_include_start'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.include_start(bool) IS 'Include starting date in bizdays_between calculation';

CREATE FUNCTION plvdate.include_start()
RETURNS bool
AS $$SELECT plvdate.include_start(true); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.include_start() IS '';

CREATE FUNCTION plvdate.noinclude_start()
RETURNS bool
AS $$SELECT plvdate.include_start(false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.noinclude_start() IS '';

CREATE FUNCTION plvdate.including_start()
RETURNS bool
AS 'MODULE_PATHNAME','plvdate_including_start'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.including_start() IS '';

CREATE FUNCTION plvdate.version()
RETURNS cstring
AS 'MODULE_PATHNAME','plvdate_version'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.version() IS '';

CREATE FUNCTION plvdate.default_holidays(text)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_default_holidays'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.default_holidays(text) IS 'Load calendar for some nations';

CREATE FUNCTION plvdate.days_inmonth(pg_catalog.date)
RETURNS integer
AS 'MODULE_PATHNAME','plvdate_days_inmonth'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.days_inmonth(pg_catalog.date) IS 'Returns number of days in month';

CREATE FUNCTION plvdate.days_inmonth(timestamptz)
RETURNS integer
AS 'select plvdate.days_inmonth($1::pg_catalog.date)'
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.days_inmonth(timestamptz) IS 'Returns number of days in month';

CREATE FUNCTION plvdate.isleapyear(pg_catalog.date)
RETURNS bool
AS 'MODULE_PATHNAME','plvdate_isleapyear'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.isleapyear(pg_catalog.date) IS 'Is leap year';

CREATE FUNCTION plvdate.isleapyear(timestamptz)
RETURNS bool
AS 'select plvdate.isleapyear($1::pg_catalog.date)'
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION plvdate.isleapyear(timestamptz) IS 'Is leap year';

---------------------------------------------------------------------------------------------
--compatible v4 plvdate_
---------------------------------------------------------------------------------------------
CREATE FUNCTION oracle.plvdate_add_bizdays(pg_catalog.date, int)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','plvdate_add_bizdays'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_add_bizdays(pg_catalog.date, int) IS 'Get the date created by adding <n> business days to a date';

CREATE FUNCTION oracle.plvdate_add_bizdays(timestamptz, int)
RETURNS oracle.date
AS 'select plvdate.add_bizdays($1::pg_catalog.date, $2)::oracle.date'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_add_bizdays(timestamptz, int) IS 'Get the date created by adding <n> business days to a date';

CREATE FUNCTION oracle.plvdate_nearest_bizday(pg_catalog.date)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','plvdate_nearest_bizday'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_nearest_bizday(pg_catalog.date) IS 'Get the nearest business date to a given date, user defined';

CREATE FUNCTION oracle.plvdate_nearest_bizday(timestamptz)
RETURNS oracle.date
AS 'select plvdate.nearest_bizday($1::pg_catalog.date)::oracle.date'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_nearest_bizday(timestamptz) IS 'Get the nearest business date to a given date, user defined';

CREATE FUNCTION oracle.plvdate_next_bizday(pg_catalog.date)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','plvdate_next_bizday'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_next_bizday(pg_catalog.date) IS 'Get the next business date from a given date, user defined';

CREATE FUNCTION oracle.plvdate_next_bizday(timestamptz)
RETURNS oracle.date
AS 'select plvdate.next_bizday($1::pg_catalog.date)::oracle.date'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_next_bizday(timestamptz) IS 'Get the next business date from a given date, user defined';

CREATE FUNCTION oracle.plvdate_bizdays_between(pg_catalog.date, pg_catalog.date)
RETURNS int
AS 'MODULE_PATHNAME','plvdate_bizdays_between'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_bizdays_between(pg_catalog.date, pg_catalog.date) IS 'Get the number of business days between two dates';

CREATE FUNCTION oracle.plvdate_bizdays_between(timestamptz, timestamptz)
RETURNS int
AS 'select plvdate.bizdays_between($1::pg_catalog.date, $2::pg_catalog.date)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_bizdays_between(timestamptz, timestamptz) IS 'Get the number of business days between two dates';

CREATE FUNCTION oracle.plvdate_prev_bizday(pg_catalog.date)
RETURNS pg_catalog.date
AS 'MODULE_PATHNAME','plvdate_prev_bizday'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_prev_bizday(pg_catalog.date) IS 'Get the previous business date from a given date';

CREATE FUNCTION oracle.plvdate_prev_bizday(timestamptz)
RETURNS oracle.date
AS 'select plvdate.prev_bizday($1::pg_catalog.date)::oracle.date'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_prev_bizday(timestamptz) IS 'Get the previous business date from a given date';

CREATE FUNCTION oracle.plvdate_isbizday(pg_catalog.date)
RETURNS bool
AS 'MODULE_PATHNAME','plvdate_isbizday'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_isbizday(pg_catalog.date) IS 'Call this function to determine if a date is a business day';

CREATE FUNCTION oracle.plvdate_isbizday(timestamptz)
RETURNS bool
AS 'select plvdate.isbizday($1::pg_catalog.date)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvdate_isbizday(timestamptz) IS 'Call this function to determine if a date is a business day';

CREATE FUNCTION oracle.plvdate_set_nonbizday(text)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_set_nonbizday_dow'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_set_nonbizday(text) IS 'Set day of week as non bussines day';

CREATE FUNCTION oracle.plvdate_unset_nonbizday(text)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_unset_nonbizday_dow'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_unset_nonbizday(text) IS 'Unset day of week as non bussines day';

CREATE FUNCTION oracle.plvdate_set_nonbizday(pg_catalog.date, bool)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_set_nonbizday_day'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_set_nonbizday(pg_catalog.date, bool) IS 'Set day as non bussines day, if repeat is true, then day is nonbiz every year';

CREATE FUNCTION oracle.plvdate_set_nonbizday(timestamptz, bool)
RETURNS void
AS 'select plvdate.set_nonbizday($1::pg_catalog.date, $2)'
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_set_nonbizday(timestamptz, bool) IS 'Set day as non bussines day, if repeat is true, then day is nonbiz every year';

CREATE FUNCTION oracle.plvdate_unset_nonbizday(pg_catalog.date, bool)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_unset_nonbizday_day'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_unset_nonbizday(pg_catalog.date, bool) IS 'Unset day as non bussines day, if repeat is true, then day is nonbiz every year';

CREATE FUNCTION oracle.plvdate_unset_nonbizday(timestamptz, bool)
RETURNS void
AS 'select plvdate.unset_nonbizday($1::pg_catalog.date, $2)'
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_unset_nonbizday(timestamptz, bool) IS 'Unset day as non bussines day, if repeat is true, then day is nonbiz every year';

CREATE FUNCTION oracle.plvdate_set_nonbizday(pg_catalog.date)
RETURNS bool
AS $$SELECT plvdate.set_nonbizday($1, false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_set_nonbizday(pg_catalog.date) IS 'Set day as non bussines day';

CREATE FUNCTION oracle.plvdate_set_nonbizday(timestamptz)
RETURNS bool
AS $$SELECT plvdate.set_nonbizday($1::pg_catalog.date, false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_set_nonbizday(timestamptz) IS 'Set day as non bussines day';

CREATE FUNCTION oracle.plvdate_unset_nonbizday(pg_catalog.date)
RETURNS bool
AS $$SELECT plvdate.unset_nonbizday($1, false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_unset_nonbizday(pg_catalog.date) IS 'Unset day as non bussines day';

CREATE FUNCTION oracle.plvdate_unset_nonbizday(timestamptz)
RETURNS bool
AS $$SELECT plvdate.unset_nonbizday($1::pg_catalog.date, false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_unset_nonbizday(timestamptz) IS 'Unset day as non bussines day';

CREATE FUNCTION oracle.plvdate_use_easter(bool)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_use_easter'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_use_easter(bool) IS 'Easter Sunday and easter monday will be holiday';

CREATE FUNCTION oracle.plvdate_use_easter()
RETURNS bool
AS $$SELECT plvdate.use_easter(true); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_use_easter() IS 'Easter Sunday and easter monday will be holiday';

CREATE FUNCTION oracle.plvdate_unuse_easter()
RETURNS bool
AS $$SELECT plvdate.use_easter(false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_unuse_easter() IS 'Easter Sunday and easter monday will not be holiday';

CREATE FUNCTION oracle.plvdate_using_easter()
RETURNS bool
AS 'MODULE_PATHNAME','plvdate_using_easter'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_using_easter() IS 'Use easter?';

CREATE FUNCTION oracle.plvdate_use_great_friday(bool)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_use_great_friday'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_use_great_friday(bool) IS 'Great Friday will be holiday';

CREATE FUNCTION oracle.plvdate_use_great_friday()
RETURNS bool
AS $$SELECT plvdate.use_great_friday(true); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_use_great_friday() IS 'Great Friday will be holiday';

CREATE FUNCTION oracle.plvdate_unuse_great_friday()
RETURNS bool
AS $$SELECT plvdate.use_great_friday(false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_unuse_great_friday() IS 'Great Friday will not be holiday';

CREATE FUNCTION oracle.plvdate_using_great_friday()
RETURNS bool
AS 'MODULE_PATHNAME','plvdate_using_great_friday'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_using_great_friday() IS 'Use Great Friday?';

CREATE FUNCTION oracle.plvdate_include_start(bool)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_include_start'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_include_start(bool) IS 'Include starting date in bizdays_between calculation';

CREATE FUNCTION oracle.plvdate_include_start()
RETURNS bool
AS $$SELECT plvdate.include_start(true); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_include_start() IS '';

CREATE FUNCTION oracle.plvdate_noinclude_start()
RETURNS bool
AS $$SELECT plvdate.include_start(false); SELECT NULL::boolean;$$
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_noinclude_start() IS '';

CREATE FUNCTION oracle.plvdate_including_start()
RETURNS bool
AS 'MODULE_PATHNAME','plvdate_including_start'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_including_start() IS '';

CREATE FUNCTION oracle.plvdate_version()
RETURNS cstring
AS 'MODULE_PATHNAME','plvdate_version'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_version() IS '';

CREATE FUNCTION oracle.plvdate_default_holidays(text)
RETURNS void
AS 'MODULE_PATHNAME','plvdate_default_holidays'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_default_holidays(text) IS 'Load calendar for some nations';

CREATE FUNCTION oracle.plvdate_days_inmonth(pg_catalog.date)
RETURNS integer
AS 'MODULE_PATHNAME','plvdate_days_inmonth'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_days_inmonth(pg_catalog.date) IS 'Returns number of days in month';

CREATE FUNCTION oracle.plvdate_days_inmonth(timestamptz)
RETURNS integer
AS 'select plvdate.days_inmonth($1::pg_catalog.date)'
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_days_inmonth(timestamptz) IS 'Returns number of days in month';

CREATE FUNCTION oracle.plvdate_isleapyear(pg_catalog.date)
RETURNS bool
AS 'MODULE_PATHNAME','plvdate_isleapyear'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_isleapyear(pg_catalog.date) IS 'Is leap year';

CREATE FUNCTION oracle.plvdate_isleapyear(timestamptz)
RETURNS bool
AS 'select plvdate.isleapyear($1::pg_catalog.date)'
LANGUAGE SQL VOLATILE STRICT;
COMMENT ON FUNCTION oracle.plvdate_isleapyear(timestamptz) IS 'Is leap year';
--end plvdate_

CREATE SCHEMA plvchr;

CREATE FUNCTION plvchr.nth(str text, n int)
RETURNS text
AS 'MODULE_PATHNAME','plvchr_nth'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.nth(text, int) IS 'Call this function to return the Nth character in a string';

CREATE FUNCTION plvchr.first(str text)
RETURNS varchar
AS 'MODULE_PATHNAME','plvchr_first'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.first(text) IS 'Call this function to return the first character in a string';

CREATE FUNCTION plvchr.last(str text)
RETURNS varchar
AS 'MODULE_PATHNAME','plvchr_last'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.last(text) IS 'Call this function to return the last character in a string';

CREATE FUNCTION plvchr._is_kind(str text, kind int)
RETURNS bool
AS 'MODULE_PATHNAME','plvchr_is_kind_a'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr._is_kind(text, int) IS '';

CREATE FUNCTION plvchr._is_kind(c int, kind int)
RETURNS bool
AS 'MODULE_PATHNAME','plvchr_is_kind_i'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr._is_kind(int, int) IS '';

CREATE FUNCTION plvchr.is_blank(c int)
RETURNS BOOL
AS $$ SELECT plvchr._is_kind($1, 1);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.is_blank(int) IS '';

CREATE FUNCTION plvchr.is_blank(c text)
RETURNS BOOL
AS $$ SELECT plvchr._is_kind($1, 1);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.is_blank(text) IS '';

CREATE FUNCTION plvchr.is_digit(c int)
RETURNS BOOL
AS $$ SELECT plvchr._is_kind($1, 2);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.is_digit(int) IS '';

CREATE FUNCTION plvchr.is_digit(c text)
RETURNS BOOL
AS $$ SELECT plvchr._is_kind($1, 2);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.is_digit(text) IS '';

CREATE FUNCTION plvchr.is_quote(c int)
RETURNS BOOL
AS $$ SELECT plvchr._is_kind($1, 3);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.is_quote(int) IS '';

CREATE FUNCTION plvchr.is_quote(c text)
RETURNS BOOL
AS $$ SELECT plvchr._is_kind($1, 3);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.is_quote(text) IS '';

CREATE FUNCTION plvchr.is_other(c int)
RETURNS BOOL
AS $$ SELECT plvchr._is_kind($1, 4);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.is_other(int) IS '';

CREATE FUNCTION plvchr.is_other(c text)
RETURNS BOOL
AS $$ SELECT plvchr._is_kind($1, 4);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.is_other(text) IS '';

CREATE FUNCTION plvchr.is_letter(c int)
RETURNS BOOL
AS $$ SELECT plvchr._is_kind($1, 5);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.is_letter(int) IS '';

CREATE FUNCTION plvchr.is_letter(c text)
RETURNS BOOL
AS $$ SELECT plvchr._is_kind($1, 5);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.is_letter(text) IS '';

CREATE FUNCTION plvchr.char_name(c text)
RETURNS varchar
AS 'MODULE_PATHNAME','plvchr_char_name'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.char_name(text) IS '';

CREATE FUNCTION plvstr.left(str text, n int)
RETURNS varchar
AS 'MODULE_PATHNAME', 'plvstr_left'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.left(text, int) IS 'Returns firs num_in charaters. You can use negative num_in';

CREATE FUNCTION plvstr.right(str text, n int)
RETURNS varchar
AS 'MODULE_PATHNAME','plvstr_right'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr.right(text, int) IS 'Returns last num_in charaters. You can use negative num_ni';

CREATE FUNCTION plvchr.quoted1(str text)
RETURNS varchar
AS $$SELECT ''''||$1||'''';$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.quoted1(text) IS E'Quoted text between ''';

CREATE FUNCTION plvchr.quoted2(str text)
RETURNS varchar
AS $$SELECT '"'||$1||'"';$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.quoted2(text) IS 'Quoted text between "';

CREATE FUNCTION plvchr.stripped(str text, char_in text)
RETURNS varchar
AS $$ SELECT TRANSLATE($1, 'A'||$2, 'A'); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION plvchr.stripped(text, text) IS 'Strips a string of all instances of the specified characters';

----------------------------------------------------------------------------------------
--compatible v4 plvchr_
----------------------------------------------------------------------------------------
CREATE FUNCTION oracle.plvchr_nth(str text, n int)
RETURNS text
AS 'MODULE_PATHNAME','plvchr_nth'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_nth(text, int) IS 'Call this function to return the Nth character in a string';

CREATE FUNCTION oracle.plvchr_first(str text)
RETURNS varchar
AS 'MODULE_PATHNAME','plvchr_first'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_first(text) IS 'Call this function to return the first character in a string';

CREATE FUNCTION oracle.plvchr_last(str text)
RETURNS varchar
AS 'MODULE_PATHNAME','plvchr_last'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_last(text) IS 'Call this function to return the last character in a string';

CREATE FUNCTION oracle.plvchr_is_kind(str text, kind int)
RETURNS bool
AS 'MODULE_PATHNAME','plvchr_is_kind_a'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_kind(text, int) IS '';

CREATE FUNCTION oracle.plvchr_is_kind(c int, kind int)
RETURNS bool
AS 'MODULE_PATHNAME','plvchr_is_kind_i'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_kind(int, int) IS '';

CREATE FUNCTION oracle.plvchr_is_blank(c int)
RETURNS BOOL
AS $$ SELECT oracle.plvchr_is_kind($1, 1);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_blank(int) IS '';

CREATE FUNCTION oracle.plvchr_is_blank(c text)
RETURNS BOOL
AS $$ SELECT oracle.plvchr_is_kind($1, 1);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_blank(text) IS '';

CREATE FUNCTION oracle.plvchr_is_digit(c int)
RETURNS BOOL
AS $$ SELECT oracle.plvchr_is_kind($1, 2);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_digit(int) IS '';

CREATE FUNCTION oracle.plvchr_is_digit(c text)
RETURNS BOOL
AS $$ SELECT oracle.plvchr_is_kind($1, 2);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_digit(text) IS '';

CREATE FUNCTION oracle.plvchr_is_quote(c int)
RETURNS BOOL
AS $$ SELECT oracle.plvchr_is_kind($1, 3);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_quote(int) IS '';

CREATE FUNCTION oracle.plvchr_is_quote(c text)
RETURNS BOOL
AS $$ SELECT oracle.plvchr_is_kind($1, 3);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_quote(text) IS '';

CREATE FUNCTION oracle.plvchr_is_other(c int)
RETURNS BOOL
AS $$ SELECT oracle.plvchr_is_kind($1, 4);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_other(int) IS '';

CREATE FUNCTION oracle.plvchr_is_other(c text)
RETURNS BOOL
AS $$ SELECT oracle.plvchr_is_kind($1, 4);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_other(text) IS '';

CREATE FUNCTION oracle.plvchr_is_letter(c int)
RETURNS BOOL
AS $$ SELECT oracle.plvchr_is_kind($1, 5);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_letter(int) IS '';

CREATE FUNCTION oracle.plvchr_is_letter(c text)
RETURNS BOOL
AS $$ SELECT oracle.plvchr_is_kind($1, 5);$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_is_letter(text) IS '';

CREATE FUNCTION oracle.plvchr_char_name(c text)
RETURNS varchar
AS 'MODULE_PATHNAME','plvchr_char_name'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_char_name(text) IS '';

CREATE FUNCTION plvstr_left(str text, n int)
RETURNS varchar
AS 'MODULE_PATHNAME', 'plvstr_left'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr_left(text, int) IS 'Returns firs num_in charaters. You can use negative num_in';

CREATE FUNCTION plvstr_right(str text, n int)
RETURNS varchar
AS 'MODULE_PATHNAME','plvstr_right'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvstr_right(text, int) IS 'Returns last num_in charaters. You can use negative num_ni';

CREATE FUNCTION oracle.plvchr_quoted1(str text)
RETURNS varchar
AS $$SELECT ''''||$1||'''';$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_quoted1(text) IS E'Quoted text between ''';

CREATE FUNCTION oracle.plvchr_quoted2(str text)
RETURNS varchar
AS $$SELECT '"'||$1||'"';$$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_quoted2(text) IS 'Quoted text between "';

CREATE FUNCTION oracle.plvchr_stripped(str text, char_in text)
RETURNS varchar
AS $$ SELECT TRANSLATE($1, 'A'||$2, 'A'); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvchr_stripped(text, text) IS 'Strips a string of all instances of the specified characters';
--end

-- dbms_alert

CREATE SCHEMA dbms_alert;

CREATE FUNCTION dbms_alert.register(name text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_alert_register'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_alert.register(text) IS 'Register session as recipient of alert name';

CREATE FUNCTION dbms_alert.remove(name text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_alert_remove'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION dbms_alert.remove(text) IS 'Remove session as recipient of alert name';

CREATE FUNCTION dbms_alert.removeall()
RETURNS void
AS 'MODULE_PATHNAME','dbms_alert_removeall'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_alert.removeall() IS 'Remove registration for all alerts';

CREATE FUNCTION dbms_alert._signal(name text, message text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_alert_signal'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_alert._signal(text, text) IS '';

CREATE FUNCTION dbms_alert.waitany(OUT name text, OUT message text, OUT status integer, timeout float8)
RETURNS record
AS 'MODULE_PATHNAME','dbms_alert_waitany'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_alert.waitany(OUT text, OUT text, OUT integer, float8) IS 'Wait for any signal';

CREATE FUNCTION dbms_alert.waitone(name text, OUT message text, OUT status integer, timeout float8)
RETURNS record
AS 'MODULE_PATHNAME','dbms_alert_waitone'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_alert.waitone(text, OUT text, OUT integer, float8) IS 'Wait for specific signal';

CREATE FUNCTION dbms_alert.set_defaults(sensitivity float8)
RETURNS void
AS 'MODULE_PATHNAME','dbms_alert_set_defaults'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_alert.set_defaults(float8) IS '';

CREATE FUNCTION dbms_alert.defered_signal()
RETURNS trigger
AS 'MODULE_PATHNAME','dbms_alert_defered_signal'
LANGUAGE C SECURITY DEFINER;
REVOKE ALL ON FUNCTION dbms_alert.defered_signal() FROM PUBLIC;

CREATE FUNCTION dbms_alert.signal(_event text, _message text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_alert_signal'
LANGUAGE C SECURITY DEFINER;
COMMENT ON FUNCTION dbms_alert.signal(text, text) IS 'Emit signal to all recipients';

---------------------------------------------------------------------------
--compatible v4 dbms_alert_
---------------------------------------------------------------------------
CREATE FUNCTION oracle.dbms_alert_register(name text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_alert_register'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_alert_register(text) IS 'Register session as recipient of alert name';

CREATE FUNCTION oracle.dbms_alert_remove(name text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_alert_remove'
LANGUAGE C VOLATILE STRICT;
COMMENT ON FUNCTION oracle.dbms_alert_remove(text) IS 'Remove session as recipient of alert name';

CREATE FUNCTION oracle.dbms_alert_removeall()
RETURNS void
AS 'MODULE_PATHNAME','dbms_alert_removeall'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_alert_removeall() IS 'Remove registration for all alerts';

CREATE FUNCTION oracle.dbms_alert_waitany(OUT name text, OUT message text, OUT status integer, timeout float8)
RETURNS record
AS 'MODULE_PATHNAME','dbms_alert_waitany'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_alert_waitany(OUT text, OUT text, OUT integer, float8) IS 'Wait for any signal';

CREATE FUNCTION oracle.dbms_alert_waitone(name text, OUT message text, OUT status integer, timeout float8)
RETURNS record
AS 'MODULE_PATHNAME','dbms_alert_waitone'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_alert_waitone(text, OUT text, OUT integer, float8) IS 'Wait for specific signal';

CREATE FUNCTION oracle.dbms_alert_set_defaults(sensitivity float8)
RETURNS void
AS 'MODULE_PATHNAME','dbms_alert_set_defaults'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_alert_set_defaults(float8) IS '';

CREATE FUNCTION oracle.dbms_alert_defered_signal()
RETURNS trigger
AS 'MODULE_PATHNAME','dbms_alert_defered_signal'
LANGUAGE C SECURITY DEFINER;
REVOKE ALL ON FUNCTION oracle.dbms_alert_defered_signal() FROM PUBLIC;

CREATE FUNCTION oracle.dbms_alert_signal(_event text, _message text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_alert_signal'
LANGUAGE C SECURITY DEFINER;
COMMENT ON FUNCTION oracle.dbms_alert_signal(text, text) IS 'Emit signal to all recipients';
--end dbms_alert_

CREATE SCHEMA plvsubst;

CREATE FUNCTION plvsubst.string(template_in text, values_in text[], subst text)
RETURNS text
AS 'MODULE_PATHNAME','plvsubst_string_array'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plvsubst.string(text, text[], text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';

CREATE FUNCTION plvsubst.string(template_in text, values_in text[])
RETURNS text
AS $$SELECT plvsubst.string($1,$2, NULL);$$
LANGUAGE SQL STRICT VOLATILE;
COMMENT ON FUNCTION plvsubst.string(text, text[]) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';

CREATE FUNCTION plvsubst.string(template_in text, vals_in text, delim_in text, subst_in text)
RETURNS text
AS 'MODULE_PATHNAME','plvsubst_string_string'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plvsubst.string(text, text, text, text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';

CREATE FUNCTION plvsubst.string(template_in text, vals_in text)
RETURNS text
AS 'MODULE_PATHNAME','plvsubst_string_string'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plvsubst.string(text, text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';

CREATE FUNCTION plvsubst.string(template_in text, vals_in text, delim_in text)
RETURNS text
AS 'MODULE_PATHNAME','plvsubst_string_string'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plvsubst.string(text, text, text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';

CREATE FUNCTION plvsubst.setsubst(str text)
RETURNS void
AS 'MODULE_PATHNAME','plvsubst_setsubst'
LANGUAGE C STRICT VOLATILE;
COMMENT ON FUNCTION plvsubst.setsubst(text) IS 'Change the substitution keyword';

CREATE FUNCTION plvsubst.setsubst()
RETURNS void
AS 'MODULE_PATHNAME','plvsubst_setsubst_default'
LANGUAGE C STRICT VOLATILE;
COMMENT ON FUNCTION plvsubst.setsubst() IS 'Change the substitution keyword to default %s';

CREATE FUNCTION plvsubst.subst()
RETURNS text
AS 'MODULE_PATHNAME','plvsubst_subst'
LANGUAGE C STRICT VOLATILE;
COMMENT ON FUNCTION plvsubst.subst() IS 'Retrieve the current substitution keyword';

------------------------------------------------------------------------------------
-- compatible v4 plvsubst_
------------------------------------------------------------------------------------
CREATE FUNCTION oracle.plvsubst_string(template_in text, values_in text[], subst text)
RETURNS text
AS 'MODULE_PATHNAME','plvsubst_string_array'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plvsubst_string(text, text[], text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';

CREATE FUNCTION oracle.plvsubst_string(template_in text, values_in text[])
RETURNS text
AS $$SELECT oracle.plvsubst_string($1,$2, NULL);$$
LANGUAGE SQL STRICT VOLATILE;
COMMENT ON FUNCTION oracle.plvsubst_string(text, text[]) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';

CREATE FUNCTION oracle.plvsubst_string(template_in text, vals_in text, delim_in text, subst_in text)
RETURNS text
AS 'MODULE_PATHNAME','plvsubst_string_string'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plvsubst_string(text, text, text, text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';

CREATE FUNCTION oracle.plvsubst_string(template_in text, vals_in text)
RETURNS text
AS 'MODULE_PATHNAME','plvsubst_string_string'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plvsubst_string(text, text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';

CREATE FUNCTION oracle.plvsubst_string(template_in text, vals_in text, delim_in text)
RETURNS text
AS 'MODULE_PATHNAME','plvsubst_string_string'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plvsubst_string(text, text, text) IS 'Scans a string for all instances of the substitution keyword and replace it with the next value in the substitution values list';

CREATE FUNCTION oracle.plvsubst_setsubst(str text)
RETURNS void
AS 'MODULE_PATHNAME','plvsubst_setsubst'
LANGUAGE C STRICT VOLATILE;
COMMENT ON FUNCTION oracle.plvsubst_setsubst(text) IS 'Change the substitution keyword';

CREATE FUNCTION oracle.plvsubst_setsubst()
RETURNS void
AS 'MODULE_PATHNAME','plvsubst_setsubst_default'
LANGUAGE C STRICT VOLATILE;
COMMENT ON FUNCTION oracle.plvsubst_setsubst() IS 'Change the substitution keyword to default %s';

CREATE FUNCTION oracle.plvsubst_subst()
RETURNS text
AS 'MODULE_PATHNAME','plvsubst_subst'
LANGUAGE C STRICT VOLATILE;
COMMENT ON FUNCTION oracle.plvsubst_subst() IS 'Retrieve the current substitution keyword';
--end plvsubst_

CREATE SCHEMA dbms_utility;

CREATE FUNCTION dbms_utility.format_call_stack(text)
RETURNS text
AS 'MODULE_PATHNAME','dbms_utility_format_call_stack1'
LANGUAGE C STRICT VOLATILE;
COMMENT ON FUNCTION dbms_utility.format_call_stack(text) IS 'Return formated call stack';

CREATE FUNCTION dbms_utility.format_call_stack()
RETURNS text
AS 'MODULE_PATHNAME','dbms_utility_format_call_stack0'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_utility.format_call_stack() IS 'Return formated call stack';

CREATE SCHEMA plvlex;

CREATE FUNCTION plvlex.tokens(IN str text, IN skip_spaces bool, IN qualified_names bool,
OUT pos int, OUT token text, OUT code int, OUT class text, OUT separator1 text, OUT mod text)
RETURNS SETOF RECORD
AS 'MODULE_PATHNAME','plvlex_tokens'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION plvlex.tokens(text,bool,bool) IS 'Parse SQL string';

CREATE SCHEMA utl_file;
CREATE DOMAIN utl_file.file_type integer;

CREATE FUNCTION utl_file.fopen(location text, filename text, open_mode text, max_linesize integer, encoding name)
RETURNS utl_file.file_type
AS 'MODULE_PATHNAME','utl_file_fopen'
LANGUAGE C VOLATILE SECURITY DEFINER;
COMMENT ON FUNCTION utl_file.fopen(text,text,text,integer,name) IS 'The FOPEN function open file and return file handle';

CREATE FUNCTION utl_file.fopen(location text, filename text, open_mode text, max_linesize integer)
RETURNS utl_file.file_type
AS 'MODULE_PATHNAME','utl_file_fopen'
LANGUAGE C VOLATILE SECURITY DEFINER;
COMMENT ON FUNCTION utl_file.fopen(text,text,text,integer) IS 'The FOPEN function open file and return file handle';

CREATE FUNCTION utl_file.fopen(location text, filename text, open_mode text)
RETURNS utl_file.file_type
AS $$SELECT utl_file.fopen($1, $2, $3, 1024); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION utl_file.fopen(text,text,text,integer) IS 'The FOPEN function open file and return file handle';

CREATE FUNCTION utl_file.is_open(file utl_file.file_type)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_is_open'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.is_open(utl_file.file_type) IS 'Functions returns true if handle points to file that is open';

CREATE FUNCTION utl_file.get_line(file utl_file.file_type, OUT buffer text)
AS 'MODULE_PATHNAME','utl_file_get_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.get_line(utl_file.file_type) IS 'Returns one line from file';

CREATE FUNCTION utl_file.get_line(file utl_file.file_type, OUT buffer text, len integer)
AS 'MODULE_PATHNAME','utl_file_get_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.get_line(utl_file.file_type, len integer) IS 'Returns one line from file';

CREATE FUNCTION utl_file.get_nextline(file utl_file.file_type, OUT buffer text)
AS 'MODULE_PATHNAME','utl_file_get_nextline'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.get_nextline(utl_file.file_type) IS 'Returns one line from file or returns NULL';

CREATE FUNCTION utl_file.put(file utl_file.file_type, buffer text)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_put'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.put(utl_file.file_type, text) IS 'Puts data to specified file';

CREATE FUNCTION utl_file.put(file utl_file.file_type, buffer anyelement)
RETURNS bool
AS $$SELECT utl_file.put($1, $2::text); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION utl_file.put(utl_file.file_type, anyelement) IS 'Puts data to specified file';

CREATE FUNCTION utl_file.new_line(file utl_file.file_type)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_new_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.new_line(file utl_file.file_type) IS 'Function inserts one ore more newline characters in specified file';

CREATE FUNCTION utl_file.new_line(file utl_file.file_type, lines int)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_new_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.new_line(file utl_file.file_type) IS 'Function inserts one ore more newline characters in specified file';

CREATE FUNCTION utl_file.put_line(file utl_file.file_type, buffer anyelement)
RETURNS bool
AS $$SELECT utl_file.put_line($1, $2::text); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION utl_file.put_line(utl_file.file_type, anyelement) IS 'Puts data to specified file and append newline character';

CREATE FUNCTION utl_file.put_line(file utl_file.file_type, buffer anyelement, autoflush bool)
RETURNS bool
AS $$SELECT utl_file.put_line($1, $2::text, true); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION utl_file.put_line(utl_file.file_type, anyelement, bool) IS 'Puts data to specified file and append newline character';

CREATE FUNCTION utl_file.put_line(file utl_file.file_type, buffer text)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_put_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.put_line(utl_file.file_type, text) IS 'Puts data to specified file and append newline character';

CREATE FUNCTION utl_file.put_line(file utl_file.file_type, buffer text, autoflush bool)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_put_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.put_line(utl_file.file_type, text, bool) IS 'Puts data to specified file and append newline character';

CREATE FUNCTION utl_file.putf(file utl_file.file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text, arg5 text)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_putf'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.putf(utl_file.file_type, text, text, text, text, text, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION utl_file.putf(file utl_file.file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text)
RETURNS bool
AS $$SELECT utl_file.putf($1, $2, $3, $4, $5, $6, NULL); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION utl_file.putf(utl_file.file_type, text, text, text, text, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION utl_file.putf(file utl_file.file_type, format text, arg1 text, arg2 text, arg3 text)
RETURNS bool
AS $$SELECT utl_file.putf($1, $2, $3, $4, $5, NULL, NULL); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION utl_file.putf(utl_file.file_type, text, text, text, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION utl_file.putf(file utl_file.file_type, format text, arg1 text, arg2 text)
RETURNS bool
AS $$SELECT utl_file.putf($1, $2, $3, $4, NULL, NULL, NULL); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION utl_file.putf(utl_file.file_type, text, text, text, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION utl_file.putf(file utl_file.file_type, format text, arg1 text)
RETURNS bool
AS $$SELECT utl_file.putf($1, $2, $3, NULL, NULL, NULL, NULL); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION utl_file.putf(utl_file.file_type, text, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION utl_file.putf(file utl_file.file_type, format text)
RETURNS bool
AS $$SELECT utl_file.putf($1, $2, NULL, NULL, NULL, NULL, NULL); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION utl_file.putf(utl_file.file_type, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION utl_file.fflush(file utl_file.file_type)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fflush'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.fflush(file utl_file.file_type) IS 'This procedure makes sure that all pending data for specified file is written physically out to a file';

CREATE FUNCTION utl_file.fclose(file utl_file.file_type)
RETURNS utl_file.file_type
AS 'MODULE_PATHNAME','utl_file_fclose'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.fclose(utl_file.file_type) IS 'Close file';

CREATE FUNCTION utl_file.fclose_all()
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fclose_all'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.fclose_all() IS 'Close all open files.';

CREATE FUNCTION utl_file.fremove(location text, filename text)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fremove'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.fremove(text, text) IS 'Remove file.';

CREATE FUNCTION utl_file.frename(location text, filename text, dest_dir text, dest_file text, overwrite boolean)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_frename'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.frename(text, text, text, text, boolean) IS 'Rename file.';

CREATE FUNCTION utl_file.frename(location text, filename text, dest_dir text, dest_file text)
RETURNS void
AS $$SELECT utl_file.frename($1, $2, $3, $4, false);$$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION utl_file.frename(text, text, text, text) IS 'Rename file.';

CREATE FUNCTION utl_file.fcopy(src_location text, src_filename text, dest_location text, dest_filename text)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fcopy'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.fcopy(text, text, text, text) IS 'Copy a text file.';

CREATE FUNCTION utl_file.fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fcopy'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.fcopy(text, text, text, text, integer) IS 'Copy a text file.';

CREATE FUNCTION utl_file.fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer, end_line integer)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fcopy'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.fcopy(text, text, text, text, integer, integer) IS 'Copy a text file.';

CREATE FUNCTION utl_file.fgetattr(location text, filename text, OUT fexists boolean, OUT file_length bigint, OUT blocksize integer)
AS 'MODULE_PATHNAME','utl_file_fgetattr'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.fgetattr(text, text) IS 'Get file attributes.';

CREATE FUNCTION utl_file.tmpdir()
RETURNS text
AS 'MODULE_PATHNAME','utl_file_tmpdir'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION utl_file.tmpdir() IS 'Get temp directory path.';

/* carry all safe directories */
CREATE TABLE utl_file.utl_file_dir(dir text);
REVOKE ALL ON utl_file.utl_file_dir FROM PUBLIC;
REVOKE ALL ON FUNCTION utl_file.tmpdir() FROM PUBLIC;

--------------------------------------------------------------------
--compatible v4
--------------------------------------------------------------------
CREATE FUNCTION oracle.dbms_utility_format_call_stack(text)
RETURNS text
AS 'MODULE_PATHNAME','dbms_utility_format_call_stack1'
LANGUAGE C STRICT VOLATILE;
COMMENT ON FUNCTION oracle.dbms_utility_format_call_stack(text) IS 'Return formated call stack';

CREATE FUNCTION oracle.dbms_utility_format_call_stack()
RETURNS text
AS 'MODULE_PATHNAME','dbms_utility_format_call_stack0'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_utility_format_call_stack() IS 'Return formated call stack';


CREATE FUNCTION oracle.plvlex_tokens(IN str text, IN skip_spaces bool, IN qualified_names bool,
OUT pos int, OUT token text, OUT code int, OUT class text, OUT separator1 text, OUT mod text)
RETURNS SETOF RECORD
AS 'MODULE_PATHNAME','plvlex_tokens'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.plvlex_tokens(text,bool,bool) IS 'Parse SQL string';

CREATE DOMAIN oracle.utl_file_file_type integer;

CREATE FUNCTION oracle.utl_file_fopen(location text, filename text, open_mode text, max_linesize integer, encoding name)
RETURNS oracle.utl_file_file_type
AS 'MODULE_PATHNAME','utl_file_fopen'
LANGUAGE C VOLATILE SECURITY DEFINER;
COMMENT ON FUNCTION oracle.utl_file_fopen(text,text,text,integer,name) IS 'The FOPEN function open file and return file handle';

CREATE FUNCTION oracle.utl_file_fopen(location text, filename text, open_mode text, max_linesize integer)
RETURNS oracle.utl_file_file_type
AS 'MODULE_PATHNAME','utl_file_fopen'
LANGUAGE C VOLATILE SECURITY DEFINER;
COMMENT ON FUNCTION oracle.utl_file_fopen(text,text,text,integer) IS 'The FOPEN function open file and return file handle';

CREATE FUNCTION oracle.utl_file_fopen(location text, filename text, open_mode text)
RETURNS oracle.utl_file_file_type
AS $$SELECT oracle.utl_file_fopen($1, $2, $3, 1024); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_fopen(text,text,text,integer) IS 'The FOPEN function open file and return file handle';

CREATE FUNCTION oracle.utl_file_is_open(file oracle.utl_file_file_type)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_is_open'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_is_open(oracle.utl_file_file_type) IS 'Functions returns true if handle points to file that is open';

CREATE FUNCTION oracle.utl_file_get_line(file oracle.utl_file_file_type, OUT buffer text)
AS 'MODULE_PATHNAME','utl_file_get_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_get_line(oracle.utl_file_file_type) IS 'Returns one line from file';

CREATE FUNCTION oracle.utl_file_get_line(file oracle.utl_file_file_type, OUT buffer text, len integer)
AS 'MODULE_PATHNAME','utl_file_get_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_get_line(oracle.utl_file_file_type, len integer) IS 'Returns one line from file';

CREATE FUNCTION oracle.utl_file_get_nextline(file oracle.utl_file_file_type, OUT buffer text)
AS 'MODULE_PATHNAME','utl_file_get_nextline'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_get_nextline(oracle.utl_file_file_type) IS 'Returns one line from file or returns NULL';

CREATE FUNCTION oracle.utl_file_put(file oracle.utl_file_file_type, buffer text)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_put'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_put(oracle.utl_file_file_type, text) IS 'Puts data to specified file';

CREATE FUNCTION oracle.utl_file_put(file oracle.utl_file_file_type, buffer anyelement)
RETURNS bool
AS $$SELECT oracle.utl_file_put($1, $2::text); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_put(oracle.utl_file_file_type, anyelement) IS 'Puts data to specified file';

CREATE FUNCTION oracle.utl_file_new_line(file oracle.utl_file_file_type)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_new_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_new_line(file oracle.utl_file_file_type) IS 'Function inserts one ore more newline characters in specified file';

CREATE FUNCTION oracle.utl_file_new_line(file oracle.utl_file_file_type, lines int)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_new_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_new_line(file oracle.utl_file_file_type) IS 'Function inserts one ore more newline characters in specified file';

CREATE FUNCTION oracle.utl_file_put_line(file oracle.utl_file_file_type, buffer anyelement)
RETURNS bool
AS $$SELECT oracle.utl_file_put_line($1, $2::text); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_put_line(oracle.utl_file_file_type, anyelement) IS 'Puts data to specified file and append newline character';

CREATE FUNCTION oracle.utl_file_put_line(file oracle.utl_file_file_type, buffer anyelement, autoflush bool)
RETURNS bool
AS $$SELECT oracle.utl_file_put_line($1, $2::text, true); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_put_line(oracle.utl_file_file_type, anyelement, bool) IS 'Puts data to specified file and append newline character';

CREATE FUNCTION oracle.utl_file_put_line(file oracle.utl_file_file_type, buffer text)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_put_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_put_line(oracle.utl_file_file_type, text) IS 'Puts data to specified file and append newline character';

CREATE FUNCTION oracle.utl_file_put_line(file oracle.utl_file_file_type, buffer text, autoflush bool)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_put_line'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_put_line(oracle.utl_file_file_type, text, bool) IS 'Puts data to specified file and append newline character';

CREATE FUNCTION oracle.utl_file_putf(file oracle.utl_file_file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text, arg5 text)
RETURNS bool
AS 'MODULE_PATHNAME','utl_file_putf'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_putf(oracle.utl_file_file_type, text, text, text, text, text, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION oracle.utl_file_putf(file oracle.utl_file_file_type, format text, arg1 text, arg2 text, arg3 text, arg4 text)
RETURNS bool
AS $$SELECT oracle.utl_file_putf($1, $2, $3, $4, $5, $6, NULL); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_putf(oracle.utl_file_file_type, text, text, text, text, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION oracle.utl_file_putf(file oracle.utl_file_file_type, format text, arg1 text, arg2 text, arg3 text)
RETURNS bool
AS $$SELECT oracle.utl_file_putf($1, $2, $3, $4, $5, NULL, NULL); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_putf(oracle.utl_file_file_type, text, text, text, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION oracle.utl_file_putf(file oracle.utl_file_file_type, format text, arg1 text, arg2 text)
RETURNS bool
AS $$SELECT oracle.utl_file_putf($1, $2, $3, $4, NULL, NULL, NULL); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_putf(oracle.utl_file_file_type, text, text, text, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION oracle.utl_file_putf(file oracle.utl_file_file_type, format text, arg1 text)
RETURNS bool
AS $$SELECT oracle.utl_file_putf($1, $2, $3, NULL, NULL, NULL, NULL); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_putf(oracle.utl_file_file_type, text, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION oracle.utl_file_putf(file oracle.utl_file_file_type, format text)
RETURNS bool
AS $$SELECT oracle.utl_file_putf($1, $2, NULL, NULL, NULL, NULL, NULL); $$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_putf(oracle.utl_file_file_type, text) IS 'Puts formatted data to specified file';

CREATE FUNCTION oracle.utl_file_fflush(file oracle.utl_file_file_type)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fflush'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_fflush(file oracle.utl_file_file_type) IS 'This procedure makes sure that all pending data for specified file is written physically out to a file';

CREATE FUNCTION oracle.utl_file_fclose(file oracle.utl_file_file_type)
RETURNS oracle.utl_file_file_type
AS 'MODULE_PATHNAME','utl_file_fclose'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_fclose(oracle.utl_file_file_type) IS 'Close file';

CREATE FUNCTION oracle.utl_file_fclose_all()
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fclose_all'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_fclose_all() IS 'Close all open files.';

CREATE FUNCTION oracle.utl_file_fremove(location text, filename text)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fremove'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_fremove(text, text) IS 'Remove file.';

CREATE FUNCTION oracle.utl_file_frename(location text, filename text, dest_dir text, dest_file text, overwrite boolean)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_frename'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_frename(text, text, text, text, boolean) IS 'Rename file.';

CREATE FUNCTION oracle.utl_file_frename(location text, filename text, dest_dir text, dest_file text)
RETURNS void
AS $$SELECT oracle.utl_file_frename($1, $2, $3, $4, false);$$
LANGUAGE SQL VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_frename(text, text, text, text) IS 'Rename file.';

CREATE FUNCTION oracle.utl_file_fcopy(src_location text, src_filename text, dest_location text, dest_filename text)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fcopy'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_fcopy(text, text, text, text) IS 'Copy a text file.';

CREATE FUNCTION oracle.utl_file_fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fcopy'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_fcopy(text, text, text, text, integer) IS 'Copy a text file.';

CREATE FUNCTION oracle.utl_file_fcopy(src_location text, src_filename text, dest_location text, dest_filename text, start_line integer, end_line integer)
RETURNS void
AS 'MODULE_PATHNAME','utl_file_fcopy'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_fcopy(text, text, text, text, integer, integer) IS 'Copy a text file.';

CREATE FUNCTION oracle.utl_file_fgetattr(location text, filename text, OUT fexists boolean, OUT file_length bigint, OUT blocksize integer)
AS 'MODULE_PATHNAME','utl_file_fgetattr'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_fgetattr(text, text) IS 'Get file attributes.';

CREATE FUNCTION oracle.utl_file_tmpdir()
RETURNS text
AS 'MODULE_PATHNAME','utl_file_tmpdir'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.utl_file_tmpdir() IS 'Get temp directory path.';
--end

-- dbms_assert

CREATE SCHEMA dbms_assert;

CREATE FUNCTION dbms_assert.enquote_literal(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_enquote_literal'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION dbms_assert.enquote_literal(varchar) IS 'Add leading and trailing quotes, verify that all single quotes are paired with adjacent single quotes';

CREATE FUNCTION dbms_assert.enquote_name(str varchar, loweralize boolean)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_enquote_name'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION dbms_assert.enquote_name(varchar, boolean) IS 'Enclose name in double quotes';

CREATE FUNCTION dbms_assert.enquote_name(str varchar)
RETURNS varchar
AS 'SELECT dbms_assert.enquote_name($1, true)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION dbms_assert.enquote_name(varchar) IS 'Enclose name in double quotes';

CREATE FUNCTION dbms_assert.noop(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_noop'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION dbms_assert.noop(varchar) IS 'Returns value without any checking.';

CREATE FUNCTION dbms_assert.schema_name(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_schema_name'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION dbms_assert.schema_name(varchar) IS 'Verify input string is an existing schema name.';

CREATE FUNCTION dbms_assert.object_name(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_object_name'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION dbms_assert.object_name(varchar) IS 'Verify input string is an existing object name.';

CREATE FUNCTION dbms_assert.simple_sql_name(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_simple_sql_name'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION dbms_assert.object_name(varchar) IS 'Verify input string is an sql name.';

CREATE FUNCTION dbms_assert.qualified_sql_name(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_qualified_sql_name'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION dbms_assert.object_name(varchar) IS 'Verify input string is an qualified sql name.';

----------------------------------------------------------------------------------------
--compatible v4
CREATE FUNCTION oracle.dbms_assert_enquote_literal(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_enquote_literal'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.dbms_assert_enquote_literal(varchar) IS 'Add leading and trailing quotes, verify that all single quotes are paired with adjacent single quotes';

CREATE FUNCTION oracle.dbms_assert_enquote_name(str varchar, loweralize boolean)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_enquote_name'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.dbms_assert_enquote_name(varchar, boolean) IS 'Enclose name in double quotes';

CREATE FUNCTION oracle.dbms_assert_enquote_name(str varchar)
RETURNS varchar
AS 'SELECT oracle.dbms_assert_enquote_name($1, true)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.dbms_assert_enquote_name(varchar) IS 'Enclose name in double quotes';

CREATE FUNCTION oracle.dbms_assert_noop(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_noop'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.dbms_assert_noop(varchar) IS 'Returns value without any checking.';

CREATE FUNCTION oracle.dbms_assert_schema_name(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_schema_name'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.dbms_assert_schema_name(varchar) IS 'Verify input string is an existing schema name.';

CREATE FUNCTION oracle.dbms_assert_object_name(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_object_name'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.dbms_assert_object_name(varchar) IS 'Verify input string is an existing object name.';

CREATE FUNCTION oracle.dbms_assert_simple_sql_name(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_simple_sql_name'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.dbms_assert_object_name(varchar) IS 'Verify input string is an sql name.';

CREATE FUNCTION oracle.dbms_assert_qualified_sql_name(str varchar)
RETURNS varchar
AS 'MODULE_PATHNAME','dbms_assert_qualified_sql_name'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.dbms_assert_object_name(varchar) IS 'Verify input string is an qualified sql name.';
--end
---------------------------------------------------------------------------------------------------------

CREATE SCHEMA plunit;

CREATE FUNCTION plunit.assert_true(condition boolean)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_true'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_true(condition boolean) IS 'Asserts that the condition is true';

CREATE FUNCTION plunit.assert_true(condition boolean, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_true_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_true(condition boolean, message varchar) IS 'Asserts that the condition is true';

CREATE FUNCTION plunit.assert_false(condition boolean)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_false'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_false(condition boolean) IS 'Asserts that the condition is false';

CREATE FUNCTION plunit.assert_false(condition boolean, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_false_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_false(condition boolean, message varchar) IS 'Asserts that the condition is false';

CREATE FUNCTION plunit.assert_null(actual anyelement)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_null'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_null(actual anyelement) IS 'Asserts that the actual is null';

CREATE FUNCTION plunit.assert_null(actual anyelement, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_null_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_null(actual anyelement, message varchar) IS 'Asserts that the condition is null';

CREATE FUNCTION plunit.assert_not_null(actual anyelement)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_null'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_not_null(actual anyelement) IS 'Asserts that the actual is not null';

CREATE FUNCTION plunit.assert_not_null(actual anyelement, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_null_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_not_null(actual anyelement, message varchar) IS 'Asserts that the condition is not null';

CREATE FUNCTION plunit.assert_equals(expected anyelement, actual anyelement)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_equals'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_equals(expected anyelement, actual anyelement) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION plunit.assert_equals(expected anyelement, actual anyelement, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_equals_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_equals(expected anyelement, actual anyelement, message varchar) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION plunit.assert_equals(expected double precision, actual double precision, "range" double precision)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_equals_range'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_equals(expected double precision, actual double precision, "range" double precision) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION plunit.assert_equals(expected double precision, actual double precision, "range" double precision, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_equals_range_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_equals(expected double precision, actual double precision, "range" double precision, message varchar) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION plunit.assert_not_equals(expected anyelement, actual anyelement)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_equals'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_not_equals(expected anyelement, actual anyelement) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION plunit.assert_not_equals(expected anyelement, actual anyelement, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_equals_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_not_equals(expected anyelement, actual anyelement, message varchar) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION plunit.assert_not_equals(expected double precision, actual double precision, "range" double precision)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_equals_range'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_equals(expected double precision, actual double precision, "range" double precision) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION plunit.assert_not_equals(expected double precision, actual double precision, "range" double precision, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_equals_range_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.assert_not_equals(expected double precision, actual double precision, "range" double precision, message varchar) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION plunit.fail()
RETURNS void
AS 'MODULE_PATHNAME','plunit_fail'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.fail() IS 'Immediately fail.';

CREATE FUNCTION plunit.fail(message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_fail_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION plunit.fail(message varchar) IS 'Immediately fail.';

----------------------------------------------------------------------------
--compatible v4
CREATE FUNCTION oracle.plunit_assert_true(condition boolean)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_true'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_true(condition boolean) IS 'Asserts that the condition is true';

CREATE FUNCTION oracle.plunit_assert_true(condition boolean, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_true_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_true(condition boolean, message varchar) IS 'Asserts that the condition is true';

CREATE FUNCTION oracle.plunit_assert_false(condition boolean)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_false'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_false(condition boolean) IS 'Asserts that the condition is false';

CREATE FUNCTION oracle.plunit_assert_false(condition boolean, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_false_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_false(condition boolean, message varchar) IS 'Asserts that the condition is false';

CREATE FUNCTION oracle.plunit_assert_null(actual anyelement)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_null'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_null(actual anyelement) IS 'Asserts that the actual is null';

CREATE FUNCTION oracle.plunit_assert_null(actual anyelement, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_null_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_null(actual anyelement, message varchar) IS 'Asserts that the condition is null';

CREATE FUNCTION oracle.plunit_assert_not_null(actual anyelement)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_null'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_not_null(actual anyelement) IS 'Asserts that the actual is not null';

CREATE FUNCTION oracle.plunit_assert_not_null(actual anyelement, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_null_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_not_null(actual anyelement, message varchar) IS 'Asserts that the condition is not null';

CREATE FUNCTION oracle.plunit_assert_equals(expected anyelement, actual anyelement)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_equals'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_equals(expected anyelement, actual anyelement) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION oracle.plunit_assert_equals(expected anyelement, actual anyelement, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_equals_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_equals(expected anyelement, actual anyelement, message varchar) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION oracle.plunit_assert_equals(expected double precision, actual double precision, "range" double precision)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_equals_range'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_equals(expected double precision, actual double precision, "range" double precision) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION oracle.plunit_assert_equals(expected double precision, actual double precision, "range" double precision, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_equals_range_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_equals(expected double precision, actual double precision, "range" double precision, message varchar) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION oracle.plunit_assert_not_equals(expected anyelement, actual anyelement)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_equals'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_not_equals(expected anyelement, actual anyelement) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION oracle.plunit_assert_not_equals(expected anyelement, actual anyelement, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_equals_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_not_equals(expected anyelement, actual anyelement, message varchar) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION oracle.plunit_assert_not_equals(expected double precision, actual double precision, "range" double precision)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_equals_range'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_equals(expected double precision, actual double precision, "range" double precision) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION oracle.plunit_assert_not_equals(expected double precision, actual double precision, "range" double precision, message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_assert_not_equals_range_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_assert_not_equals(expected double precision, actual double precision, "range" double precision, message varchar) IS 'Asserts that expected and actual are equal';

CREATE FUNCTION oracle.plunit_fail()
RETURNS void
AS 'MODULE_PATHNAME','plunit_fail'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_fail() IS 'Immediately fail.';

CREATE FUNCTION oracle.plunit_fail(message varchar)
RETURNS void
AS 'MODULE_PATHNAME','plunit_fail_message'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.plunit_fail(message varchar) IS 'Immediately fail.';
--end
----------------------------------------------------------------------------


-- dbms_random
CREATE SCHEMA dbms_random;

CREATE FUNCTION dbms_random.initialize(int)
RETURNS void
AS 'MODULE_PATHNAME','dbms_random_initialize'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION dbms_random.initialize(int) IS 'Initialize package with a seed value';

CREATE FUNCTION dbms_random.normal()
RETURNS double precision
AS 'MODULE_PATHNAME','dbms_random_normal'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_random.normal() IS 'Returns random numbers in a standard normal distribution';

CREATE FUNCTION dbms_random.random()
RETURNS integer
AS 'MODULE_PATHNAME','dbms_random_random'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_random.random() IS 'Generate Random Numeric Values';

CREATE FUNCTION dbms_random.seed(integer)
RETURNS void
AS 'MODULE_PATHNAME','dbms_random_seed_int'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION dbms_random.seed(int) IS 'Reset the seed value';

CREATE FUNCTION dbms_random.seed(text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_random_seed_varchar'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION dbms_random.seed(text) IS 'Reset the seed value';

CREATE FUNCTION dbms_random.string(opt text, len int)
RETURNS text
AS 'MODULE_PATHNAME','dbms_random_string'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION dbms_random.string(text,int) IS 'Create Random Strings';

CREATE FUNCTION dbms_random.terminate()
RETURNS void
AS 'MODULE_PATHNAME','dbms_random_terminate'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION dbms_random.terminate() IS 'Terminate use of the Package';

CREATE FUNCTION dbms_random.value(low double precision, high double precision)
RETURNS double precision
AS 'MODULE_PATHNAME','dbms_random_value_range'
LANGUAGE C STRICT VOLATILE;
COMMENT ON FUNCTION dbms_random.value(double precision, double precision) IS 'Generate Random number x, where x is greater or equal to low and less then high';

CREATE FUNCTION dbms_random.value()
RETURNS double precision
AS 'MODULE_PATHNAME','dbms_random_value'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION dbms_random.value() IS 'Generate Random number x, where x is greater or equal to 0 and less then 1';

----------------------------------------------------------------------------------------------------------------------------
--compatible v4
CREATE FUNCTION oracle.dbms_random_initialize(int)
RETURNS void
AS 'MODULE_PATHNAME','dbms_random_initialize'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.dbms_random_initialize(int) IS 'Initialize package with a seed value';

CREATE FUNCTION oracle.dbms_random_normal()
RETURNS double precision
AS 'MODULE_PATHNAME','dbms_random_normal'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_random_normal() IS 'Returns random numbers in a standard normal distribution';

CREATE FUNCTION oracle.dbms_random_random()
RETURNS integer
AS 'MODULE_PATHNAME','dbms_random_random'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_random_random() IS 'Generate Random Numeric Values';

CREATE FUNCTION oracle.dbms_random_seed(integer)
RETURNS void
AS 'MODULE_PATHNAME','dbms_random_seed_int'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.dbms_random_seed(int) IS 'Reset the seed value';

CREATE FUNCTION oracle.dbms_random_seed(text)
RETURNS void
AS 'MODULE_PATHNAME','dbms_random_seed_varchar'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.dbms_random_seed(text) IS 'Reset the seed value';

CREATE FUNCTION oracle.dbms_random_string(opt text, len int)
RETURNS text
AS 'MODULE_PATHNAME','dbms_random_string'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.dbms_random_string(text,int) IS 'Create Random Strings';

CREATE FUNCTION oracle.dbms_random_terminate()
RETURNS void
AS 'MODULE_PATHNAME','dbms_random_terminate'
LANGUAGE C IMMUTABLE;
COMMENT ON FUNCTION oracle.dbms_random_terminate() IS 'Terminate use of the Package';

CREATE FUNCTION oracle.dbms_random_value(low double precision, high double precision)
RETURNS double precision
AS 'MODULE_PATHNAME','dbms_random_value_range'
LANGUAGE C STRICT VOLATILE;
COMMENT ON FUNCTION oracle.dbms_random_value(double precision, double precision) IS 'Generate Random number x, where x is greater or equal to low and less then high';

CREATE FUNCTION oracle.dbms_random_value()
RETURNS double precision
AS 'MODULE_PATHNAME','dbms_random_value'
LANGUAGE C VOLATILE;
COMMENT ON FUNCTION oracle.dbms_random_value() IS 'Generate Random number x, where x is greater or equal to 0 and less then 1';
--end
--------------------------------------------------------------------------------------------------------------------------------

GRANT USAGE ON SCHEMA dbms_pipe TO PUBLIC;
GRANT USAGE ON SCHEMA dbms_alert TO PUBLIC;
GRANT USAGE ON SCHEMA plvdate TO PUBLIC;
GRANT USAGE ON SCHEMA plvstr TO PUBLIC;
GRANT USAGE ON SCHEMA plvchr TO PUBLIC;
GRANT USAGE ON SCHEMA dbms_output TO PUBLIC;
GRANT USAGE ON SCHEMA plvsubst TO PUBLIC;
GRANT SELECT ON dbms_pipe.db_pipes to PUBLIC;
GRANT USAGE ON SCHEMA dbms_utility TO PUBLIC;
GRANT USAGE ON SCHEMA plvlex TO PUBLIC;
GRANT USAGE ON SCHEMA utl_file TO PUBLIC;
GRANT USAGE ON SCHEMA dbms_assert TO PUBLIC;
GRANT USAGE ON SCHEMA dbms_random TO PUBLIC;
GRANT USAGE ON SCHEMA oracle TO PUBLIC;
GRANT USAGE ON SCHEMA plunit TO PUBLIC;

/* orafce 3.3. related changes */
ALTER FUNCTION dbms_assert.enquote_name ( character varying ) STRICT;
ALTER FUNCTION dbms_assert.enquote_name ( character varying, boolean ) STRICT;
ALTER FUNCTION dbms_assert.noop ( character varying ) STRICT;

---------------------------------------------------------------------------
--compatible
ALTER FUNCTION oracle.dbms_assert_enquote_name ( character varying ) STRICT;
ALTER FUNCTION oracle.dbms_assert_enquote_name ( character varying, boolean ) STRICT;
ALTER FUNCTION oracle.dbms_assert_noop ( character varying ) STRICT;
--end
---------------------------------------------------------------------------

CREATE FUNCTION oracle.listagg1_transfn(internal, text)
RETURNS internal
AS 'MODULE_PATHNAME','orafce_listagg1_transfn'
LANGUAGE C IMMUTABLE;

CREATE FUNCTION oracle.wm_concat_transfn(internal, text)
RETURNS internal
AS 'MODULE_PATHNAME','orafce_wm_concat_transfn'
LANGUAGE C IMMUTABLE;

CREATE FUNCTION oracle.listagg2_transfn(internal, text, text)
RETURNS internal
AS 'MODULE_PATHNAME','orafce_listagg2_transfn'
LANGUAGE C IMMUTABLE;

CREATE FUNCTION oracle.listagg_finalfn(internal)
RETURNS text
AS 'MODULE_PATHNAME','orafce_listagg_finalfn'
LANGUAGE C IMMUTABLE;

CREATE AGGREGATE oracle.listagg(text) (
  SFUNC=oracle.listagg1_transfn,
  STYPE=internal,
  FINALFUNC=oracle.listagg_finalfn
);

/*
 * Undocumented function wm_concat - removed from
 * Oracle 12c.
 */
 create schema wmsys;
 GRANT USAGE ON SCHEMA wmsys TO PUBLIC;
 CREATE AGGREGATE wmsys.wm_concat(text) (
  SFUNC=oracle.wm_concat_transfn,
  STYPE=internal,
  FINALFUNC=oracle.listagg_finalfn
);
 
CREATE AGGREGATE oracle.wm_concat(text) (
  SFUNC=oracle.wm_concat_transfn,
  STYPE=internal,
  FINALFUNC=oracle.listagg_finalfn
);

CREATE AGGREGATE oracle.listagg(text, text) (
  SFUNC=oracle.listagg2_transfn,
  STYPE=internal,
  FINALFUNC=oracle.listagg_finalfn
);

CREATE FUNCTION oracle.median4_transfn(internal, real)
RETURNS internal
AS 'MODULE_PATHNAME','orafce_median4_transfn'
LANGUAGE C IMMUTABLE;

CREATE FUNCTION oracle.median4_finalfn(internal)
RETURNS real
AS 'MODULE_PATHNAME','orafce_median4_finalfn'
LANGUAGE C IMMUTABLE;

CREATE FUNCTION oracle.median8_transfn(internal, double precision)
RETURNS internal
AS 'MODULE_PATHNAME','orafce_median8_transfn'
LANGUAGE C IMMUTABLE;

CREATE FUNCTION oracle.median8_finalfn(internal)
RETURNS double precision
AS 'MODULE_PATHNAME','orafce_median8_finalfn'
LANGUAGE C IMMUTABLE;

CREATE AGGREGATE oracle.median(real) (
  SFUNC=oracle.median4_transfn,
  STYPE=internal,
  FINALFUNC=oracle.median4_finalfn
);

CREATE AGGREGATE pg_catalog.median(double precision) (
  SFUNC=oracle.median8_transfn,
  STYPE=internal,
  FINALFUNC=oracle.median8_finalfn
);

-- oracle.oracle.varchar2 type support

CREATE FUNCTION oracle.varchar2in(cstring,oid,integer)
RETURNS oracle.varchar2
AS 'MODULE_PATHNAME','varchar2in'
LANGUAGE C
STRICT
IMMUTABLE;

CREATE FUNCTION oracle.varchar2out(oracle.varchar2)
RETURNS CSTRING
AS 'MODULE_PATHNAME','varchar2out'
LANGUAGE C
STRICT
IMMUTABLE;

CREATE FUNCTION oracle.varchar2_transform(internal)
RETURNS internal
AS 'MODULE_PATHNAME','orafce_varchar_transform'
LANGUAGE C
STRICT
IMMUTABLE;

CREATE FUNCTION oracle.varchar2recv(internal,oid,integer)
RETURNS oracle.varchar2
AS 'MODULE_PATHNAME','varchar2recv'
LANGUAGE C
STRICT
STABLE;

CREATE FUNCTION oracle.varchar2send(oracle.varchar2)
RETURNS bytea
AS 'varcharsend'
LANGUAGE internal
STRICT
STABLE;

CREATE FUNCTION oracle.varchar2typmodin(cstring[])
RETURNS integer
AS 'varchartypmodin'
LANGUAGE internal
STRICT
IMMUTABLE;

CREATE FUNCTION oracle.varchar2typmodout(integer)
RETURNS CSTRING
AS 'varchartypmodout'
LANGUAGE internal
STRICT
IMMUTABLE;

CREATE FUNCTION oracle.varchar2(oracle.varchar2,integer,boolean)
RETURNS oracle.varchar2
AS 'MODULE_PATHNAME','varchar2'
LANGUAGE C
STRICT
IMMUTABLE;

/* CREATE TYPE */
CREATE TYPE oracle.varchar2 (
internallength = VARIABLE,
input = oracle.varchar2in,
output = oracle.varchar2out,
receive = oracle.varchar2recv,
send = oracle.varchar2send,
category = 'S',
typmod_in = oracle.varchar2typmodin,
typmod_out = oracle.varchar2typmodout,
collatable = true
);

CREATE FUNCTION oracle.orafce_concat2(oracle.varchar2, oracle.varchar2)
RETURNS oracle.varchar2
AS 'MODULE_PATHNAME','orafce_concat2'
LANGUAGE C STABLE;

/* CREATE CAST */
CREATE CAST (oracle.varchar2 AS text)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (text AS oracle.varchar2)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (oracle.varchar2 AS char)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (char AS oracle.varchar2)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (oracle.varchar2 AS varchar)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (varchar AS oracle.varchar2)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (oracle.varchar2 AS oracle.varchar2)
WITH FUNCTION oracle.varchar2(oracle.varchar2,integer,boolean)
AS IMPLICIT;

/*
CREATE CAST (oracle.varchar2 AS real)
WITH INOUT
AS IMPLICIT;

CREATE CAST (real AS oracle.varchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.varchar2 AS double precision)
WITH INOUT
AS IMPLICIT;

CREATE CAST (double precision AS oracle.varchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.varchar2 AS integer)
WITH INOUT
AS IMPLICIT;

CREATE CAST (integer AS oracle.varchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.varchar2 AS smallint)
WITH INOUT
AS IMPLICIT;

CREATE CAST (smallint AS oracle.varchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.varchar2 AS bigint)
WITH INOUT
AS IMPLICIT;

CREATE CAST (bigint AS oracle.varchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.varchar2 AS numeric)
WITH INOUT
AS IMPLICIT;

CREATE CAST (numeric AS oracle.varchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.varchar2 AS pg_catalog.date)
WITH INOUT
AS IMPLICIT;

CREATE CAST (pg_catalog.date AS oracle.varchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.varchar2 AS timestamp)
WITH INOUT
AS IMPLICIT;

CREATE CAST (timestamp AS oracle.varchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.varchar2 AS interval)
WITH INOUT
AS IMPLICIT;

CREATE CAST (interval AS oracle.varchar2)
WITH INOUT
AS IMPLICIT;
*/
----------------------------------------------------------------------------------------------
--add operator, avoid implicit cast
--equal
CREATE OR REPLACE FUNCTION oracle.varchar2_eq(oracle.varchar2, oracle.varchar2)
RETURNS bool AS $$
SELECT $1::text = $2::text;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;


CREATE OPERATOR oracle.= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.varchar2_eq,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

--ne
CREATE OR REPLACE FUNCTION oracle.varchar2_ne(oracle.varchar2, oracle.varchar2)
RETURNS bool AS $$
SELECT $1::text != $2::text;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.<> (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.varchar2_ne,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

-----------------------------------------------------------------
--le and greate
-----------------------------------------------------------------
--le
CREATE OR REPLACE FUNCTION oracle.varchar2_le(oracle.varchar2, oracle.varchar2)
RETURNS bool AS $$
SELECT $1::text <= $2::text;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.<= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.varchar2_le,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

--great
CREATE OR REPLACE FUNCTION oracle.varchar2_gt(oracle.varchar2, oracle.varchar2)
RETURNS bool AS $$
SELECT $1::text > $2::text;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.> (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.varchar2_gt,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

-----------------------------------------------------------------
--ge and letter
-----------------------------------------------------------------
--ge
CREATE OR REPLACE FUNCTION oracle.varchar2_ge(oracle.varchar2, oracle.varchar2)
RETURNS bool AS $$
SELECT $1::text >= $2::text;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.>= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.varchar2_ge,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

--letter
CREATE OR REPLACE FUNCTION oracle.varchar2_lt(oracle.varchar2, oracle.varchar2)
RETURNS bool AS $$
SELECT $1::text < $2::text;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.< (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.varchar2_lt,
  COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);
--end
create operator class varchar2_ops default for type oracle.varchar2 using hash family text_ops as operator 1 oracle.=;

-- modify begin chengyuanhao FOR: solve a problem when create index vevry slow on column, when the coloum type is varchar2, 
-- the main reason is lots of frequent calls plpgsql function, now change theis function to inner c function, -- 2022/06/08

create or replace function oracle.varchar2_btcmp(oracle.varchar2, oracle.varchar2) returns int
as 'bttextcmp'
LANGUAGE internal
STRICT IMMUTABLE;

create or replace function oracle.varchar2_btcmp_text(text, oracle.varchar2) returns int
as 'bttextcmp'
LANGUAGE internal
STRICT IMMUTABLE;

create or replace function oracle.varchar2_sortsupport(internal) returns void
as 'bttextsortsupport'
LANGUAGE internal
STRICT IMMUTABLE;

create operator class varchar2_ops default for type oracle.varchar2 using btree family text_ops as	
	operator 1 oracle.<,
	operator 2 oracle.<=,
	operator 3 oracle.=,
	operator 4 oracle.>=,
	operator 5 oracle.>,
	function 1 oracle.varchar2_btcmp(oracle.varchar2, oracle.varchar2),
	function 2 oracle.varchar2_sortsupport(internal),
	function 1 oracle.varchar2_btcmp_text(text, oracle.varchar2);
-- modify end chengyuanhao

--modify operator class attribute
update pg_opclass set opcintype = 25 , opcdefault = 'f' where opcname = 'varchar2_ops';

----------------------------------------------------------------------------------------------
do $$
BEGIN
  IF EXISTS(SELECT * FROM pg_settings WHERE name = 'server_version_num' AND setting::int >= 120000) THEN
    UPDATE pg_proc SET prosupport= 'oracle.varchar2_transform'::regproc::oid WHERE proname='varchar2';
  ELSE
    UPDATE pg_proc SET protransform= 'oracle.varchar2_transform'::regproc::oid WHERE proname='varchar2';
  END IF;
END
$$;

-- string functions for varchar2 type
-- these are 'byte' versions of corresponsing text/varchar functions

/* author:luotao */
/* Function substrb type support */
CREATE OR REPLACE FUNCTION oracle.substrb(text, integer, integer) RETURNS oracle.varchar2
AS 'bytea_substr'
LANGUAGE internal
STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.substrb(text, integer, integer) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(text, integer) RETURNS oracle.varchar2
AS 'bytea_substr_no_len'
LANGUAGE internal
STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.substrb(text, integer) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(char, integer, integer) RETURNS oracle.varchar2
AS 'bytea_substr'
LANGUAGE internal
STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.substrb(char, integer, integer) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(char, integer) RETURNS oracle.varchar2
AS 'bytea_substr_no_len'
LANGUAGE internal
STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.substrb(char, integer) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(text, float8, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1, trunc($2)::int, trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(text, float8, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(text, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1, trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(text, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(char, float8, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1, trunc($2)::int, trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(char, float8, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(char, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1, trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(char, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

--number
CREATE OR REPLACE FUNCTION oracle.substrb(numeric, float8, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int, trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(numeric, float8, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(numeric, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(numeric, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(float4, float8, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int, trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(float4, float8, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(float4, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(float4, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(float8, float8, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int, trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(float8, float8, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(float8, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(float8, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

--date time
CREATE OR REPLACE FUNCTION oracle.substrb(pg_catalog.date, float8, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int, trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(pg_catalog.date, float8, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(pg_catalog.date, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(pg_catalog.date, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(timestamp, float8, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int, trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(timestamp, float8, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(timestamp, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(timestamp, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(timestamptz, float8, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int, trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(timestamptz, float8, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(timestamptz, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(timestamptz, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(interval, float8, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int, trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(interval, float8, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

CREATE OR REPLACE FUNCTION oracle.substrb(interval, float8) RETURNS oracle.varchar2
AS $$ SELECT oracle.substrb($1::text, trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.substrb(interval, float8) IS 'extracts specified number of bytes from the input string starting at the specified byte position (1-based) and returns as a varchar2 string';

/* author:luotao */
--string
CREATE OR REPLACE FUNCTION oracle.lengthb(char) RETURNS integer
AS 'byteaoctetlen'
LANGUAGE internal STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.lengthb(char) IS 'returns byte length of the input string';

CREATE OR REPLACE FUNCTION oracle.lengthb(text) RETURNS integer
AS 'byteaoctetlen'
LANGUAGE internal STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.lengthb(text) IS 'returns byte length of the input string';

--number
CREATE OR REPLACE FUNCTION oracle.lengthb(smallint) RETURNS integer
AS 'select oracle.lengthb($1::text)'
LANGUAGE SQL STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.lengthb(smallint) IS 'returns byte length of the input string';

CREATE OR REPLACE FUNCTION oracle.lengthb(int) RETURNS integer
AS 'select oracle.lengthb($1::text)'
LANGUAGE SQL STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.lengthb(int) IS 'returns byte length of the input string';

CREATE OR REPLACE FUNCTION oracle.lengthb(bigint) RETURNS integer
AS 'select oracle.lengthb($1::text)'
LANGUAGE SQL STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.lengthb(bigint) IS 'returns byte length of the input string';

CREATE OR REPLACE FUNCTION oracle.lengthb(float4) RETURNS integer
AS 'select oracle.lengthb($1::text)'
LANGUAGE SQL STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.lengthb(float4) IS 'returns byte length of the input string';

CREATE OR REPLACE FUNCTION oracle.lengthb(float8) RETURNS integer
AS 'select oracle.lengthb($1::text)'
LANGUAGE SQL STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.lengthb(float8) IS 'returns byte length of the input string';

--date time
CREATE OR REPLACE FUNCTION oracle.lengthb(pg_catalog.date) RETURNS integer
AS 'select oracle.lengthb($1::text)'
LANGUAGE SQL STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.lengthb(pg_catalog.date) IS 'returns byte length of the input string';

CREATE OR REPLACE FUNCTION oracle.lengthb(timestamp) RETURNS integer
AS 'select oracle.lengthb($1::text)'
LANGUAGE SQL STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.lengthb(timestamp) IS 'returns byte length of the input string';

CREATE OR REPLACE FUNCTION oracle.lengthb(timestamptz) RETURNS integer
AS 'select oracle.lengthb($1::text)'
LANGUAGE SQL STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.lengthb(timestamptz) IS 'returns byte length of the input string';

--interval
CREATE OR REPLACE FUNCTION oracle.lengthb(interval) RETURNS integer
AS 'select oracle.lengthb($1::text)'
LANGUAGE SQL STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.lengthb(interval) IS 'returns byte length of the input string';

/* author:luotao */
--string
CREATE OR REPLACE FUNCTION oracle.strposb(text, variadic "any") RETURNS integer
AS 'MODULE_PATHNAME','orafce_strposb'
LANGUAGE C
STRICT IMMUTABLE;
COMMENT ON FUNCTION oracle.strposb(text, variadic "any") IS 'returns the byte position of a specified string in the input string';

CREATE OR REPLACE FUNCTION oracle.strposb(char, variadic "any") RETURNS integer
AS 'MODULE_PATHNAME','orafce_strposb'
LANGUAGE C
STRICT IMMUTABLE;

--number
CREATE OR REPLACE FUNCTION oracle.strposb(numeric, variadic "any") RETURNS integer
AS 'MODULE_PATHNAME','orafce_strposb'
LANGUAGE C
STRICT IMMUTABLE;

CREATE OR REPLACE FUNCTION oracle.strposb(float4, variadic "any") RETURNS integer
AS 'MODULE_PATHNAME','orafce_strposb'
LANGUAGE C
STRICT IMMUTABLE;

CREATE OR REPLACE FUNCTION oracle.strposb(float8, variadic "any") RETURNS integer
AS 'MODULE_PATHNAME','orafce_strposb'
LANGUAGE C
STRICT IMMUTABLE;

--date time
CREATE OR REPLACE FUNCTION oracle.strposb(pg_catalog.date, variadic "any") RETURNS integer
AS 'MODULE_PATHNAME','orafce_strposb'
LANGUAGE C
STRICT IMMUTABLE;

CREATE OR REPLACE FUNCTION oracle.strposb(timestamp, variadic "any") RETURNS integer
AS 'MODULE_PATHNAME','orafce_strposb'
LANGUAGE C
STRICT IMMUTABLE;

CREATE OR REPLACE FUNCTION oracle.strposb(timestamptz, variadic "any") RETURNS integer
AS 'MODULE_PATHNAME','orafce_strposb'
LANGUAGE C
STRICT IMMUTABLE;

CREATE OR REPLACE FUNCTION oracle.strposb(interval, variadic "any") RETURNS integer
AS 'MODULE_PATHNAME','orafce_strposb'
LANGUAGE C
STRICT IMMUTABLE;

-- oracle.nvarchar2 type support

CREATE FUNCTION oracle.nvarchar2in(cstring,oid,integer)
RETURNS oracle.nvarchar2
AS 'MODULE_PATHNAME','nvarchar2in'
LANGUAGE C
STRICT
IMMUTABLE;

CREATE FUNCTION oracle.nvarchar2out(oracle.nvarchar2)
RETURNS CSTRING
AS 'MODULE_PATHNAME','nvarchar2out'
LANGUAGE C
STRICT
IMMUTABLE;

CREATE FUNCTION oracle.nvarchar2_transform(internal)
RETURNS internal
AS 'MODULE_PATHNAME','orafce_nvarchar2_transform'
LANGUAGE C
STRICT
IMMUTABLE;

CREATE FUNCTION oracle.nvarchar2recv(internal,oid,integer)
RETURNS oracle.nvarchar2
AS 'MODULE_PATHNAME','nvarchar2recv'
LANGUAGE C
STRICT
IMMUTABLE;


CREATE FUNCTION oracle.nvarchar2send(oracle.nvarchar2)
RETURNS bytea
AS 'MODULE_PATHNAME','nvarchar2send'
LANGUAGE C
STRICT
STABLE;

CREATE FUNCTION oracle.nvarchar2typmodin(cstring[])
RETURNS integer
AS 'MODULE_PATHNAME','nvarchar2typmodin'
LANGUAGE C
STRICT
IMMUTABLE;

CREATE FUNCTION oracle.nvarchar2typmodout(integer)
RETURNS CSTRING
AS 'MODULE_PATHNAME','nvarchar2typmodout'
LANGUAGE C
STRICT
STABLE;


CREATE FUNCTION oracle.nvarchar2(oracle.nvarchar2,integer,boolean)
RETURNS oracle.nvarchar2
AS 'MODULE_PATHNAME','nvarchar2'
LANGUAGE C
STRICT
IMMUTABLE;

/* CREATE TYPE */
CREATE TYPE oracle.nvarchar2 (
internallength = VARIABLE,
input = oracle.nvarchar2in,
output = oracle.nvarchar2out,
receive = oracle.nvarchar2recv,
send = oracle.nvarchar2send,
category = 'S',
typmod_in = oracle.nvarchar2typmodin,
typmod_out = oracle.nvarchar2typmodout,
collatable = true
);

CREATE FUNCTION oracle.orafce_concat2(oracle.nvarchar2, oracle.nvarchar2)
RETURNS oracle.nvarchar2
AS 'MODULE_PATHNAME','orafce_concat2'
LANGUAGE C IMMUTABLE;

/* CREATE CAST */
CREATE CAST (oracle.nvarchar2 AS text)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (text AS oracle.nvarchar2)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (oracle.nvarchar2 AS char)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (char AS oracle.nvarchar2)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (oracle.nvarchar2 AS varchar)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (varchar AS oracle.nvarchar2)
WITHOUT FUNCTION
AS IMPLICIT;

CREATE CAST (oracle.nvarchar2 AS oracle.nvarchar2)
WITH FUNCTION oracle.nvarchar2(oracle.nvarchar2, integer, boolean)
AS IMPLICIT;

/*
CREATE CAST (oracle.nvarchar2 AS real)
WITH INOUT
AS IMPLICIT;

CREATE CAST (real AS oracle.nvarchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.nvarchar2 AS double precision)
WITH INOUT
AS IMPLICIT;

CREATE CAST (double precision AS oracle.nvarchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.nvarchar2 AS integer)
WITH INOUT
AS IMPLICIT;

CREATE CAST (integer AS oracle.nvarchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.nvarchar2 AS smallint)
WITH INOUT
AS IMPLICIT;

CREATE CAST (smallint AS oracle.nvarchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.nvarchar2 AS bigint)
WITH INOUT
AS IMPLICIT;

CREATE CAST (bigint AS oracle.nvarchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.nvarchar2 AS numeric)
WITH INOUT
AS IMPLICIT;

CREATE CAST (numeric AS oracle.nvarchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.nvarchar2 AS pg_catalog.date)
WITH INOUT
AS IMPLICIT;

CREATE CAST (pg_catalog.date AS oracle.nvarchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.nvarchar2 AS timestamp)
WITH INOUT
AS IMPLICIT;

CREATE CAST (timestamp AS oracle.nvarchar2)
WITH INOUT
AS IMPLICIT;

CREATE CAST (oracle.nvarchar2 AS interval)
WITH INOUT
AS IMPLICIT;

CREATE CAST (interval AS oracle.nvarchar2)
WITH INOUT
AS IMPLICIT;
*/

/* Added implicit type conversion by luotao */
CREATE CAST (oracle.nvarchar2 AS oracle.varchar2)
WITH INOUT
AS IMPLICIT;

do $$
BEGIN
  IF EXISTS(SELECT * FROM pg_settings WHERE name = 'server_version_num' AND setting::int >= 120000) THEN
    UPDATE pg_proc SET prosupport='oracle.nvarchar2_transform'::regproc::oid WHERE proname='nvarchar2';
  ELSE
    UPDATE pg_proc SET protransform='oracle.nvarchar2_transform'::regproc::oid WHERE proname='nvarchar2';
  END IF;
END
$$;

/*
 * Note - a procedure keyword is depraceted from PostgreSQL 11, but it used
 * because older release doesn't know function.
 *
 */
CREATE FUNCTION oracle.orafce_concat2(numeric, numeric)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(numeric, text)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(text, numeric)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(float4, float4)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(float4, text)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(text, float4)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;
 
CREATE FUNCTION oracle.orafce_concat2(float8, float8)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(float8, text)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(text, float8)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(pg_catalog.date, pg_catalog.date)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(pg_catalog.date, text)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(text, pg_catalog.date)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(timestamp, timestamp)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(timestamp, text)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(text, timestamp)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(timestamptz, timestamptz)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(timestamptz, text)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(text, timestamptz)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(interval, interval)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(interval, text)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(text, interval)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

/* add by qinshiyu 2021.01.26 */
CREATE FUNCTION oracle.orafce_concat2(text, text)
RETURNS text
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(float4, float8)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;

CREATE FUNCTION oracle.orafce_concat2(float8, float4)
RETURNS oracle.varchar2
AS 'select oracle.orafce_concat2($1::oracle.varchar2, $2::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE;
/* add end */

CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = oracle.varchar2, rightarg = oracle.varchar2);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = numeric, rightarg = numeric);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = float4, rightarg = float4);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = float8, rightarg = float8);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = pg_catalog.date, rightarg = pg_catalog.date);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = timestamp, rightarg = timestamp);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = timestamptz, rightarg = timestamptz);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = interval, rightarg = interval);

CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = numeric, rightarg = text);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = float4, rightarg = text);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = float8, rightarg = text);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = pg_catalog.date, rightarg = text);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = timestamp, rightarg = text);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = timestamptz, rightarg = text);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = interval, rightarg = text);

CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = text, rightarg = numeric);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = text, rightarg = float4);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = text, rightarg = float8);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = text, rightarg = pg_catalog.date);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = text, rightarg = timestamp);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = text, rightarg = timestamptz);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = text, rightarg = interval);

/* add by qinshiyu 2021.01.26 */
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = text, rightarg = text);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = float4, rightarg = float8);
CREATE OPERATOR oracle.|| (procedure = oracle.orafce_concat2, leftarg = float8, rightarg = float4);
/* add end */


/* PAD */

/* LPAD family */

/* Incompatibility #1:
 *     pg_catalog.lpad removes trailing blanks of CHAR arguments
 *     because of implicit cast to text
 *
 * Incompatibility #2:
 *     oracle.lpad considers character length, NOT display length
 *     so, add functions to use custom C implementation of lpad as defined
 *     in charpad.c
 */
/* author:luotao */
CREATE FUNCTION oracle.lpad(text, int, text)
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.lpad(text, int)
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.lpad(text, text, text)
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.lpad(text, text)
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.lpad(text, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.lpad(numeric, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.lpad(float4, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.lpad(float8, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.lpad(pg_catalog.date, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.lpad(timestamp, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.lpad(timestamptz, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.lpad(interval, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_lpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

/* RPAD family */

/* Incompatibility #1:
 *     pg_catalog.rpad removes trailing blanks of CHAR arguments
 *     because of implicit cast to text
 *
 * Incompatibility #2:
 *     oracle.rpad considers character length, NOT display length
 *     so, add functions to use custom C implementation of rpad as defined
 *     in charpad.c
 */
/* author:luotao */
CREATE FUNCTION oracle.rpad(text, int, text)
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.rpad(text, int)
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.rpad(text, text, text)
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.rpad(text, text)
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.rpad(text, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.rpad(numeric, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.rpad(float4, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.rpad(float8, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.rpad(pg_catalog.date, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.rpad(timestamp, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.rpad(timestamptz, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;

CREATE FUNCTION oracle.rpad(interval, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafce_rpad'
LANGUAGE 'c'
STRICT IMMUTABLE;
;

/* --author:luotao */
/* increase nls_initcap function */
CREATE OR REPLACE FUNCTION oracle.nls_initcap(text)
RETURNS text
AS 'initcap'
LANGUAGE internal
IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.nls_initcap(text) IS 'first letter of each word in uppercase, all other letters in lowercase.';

CREATE OR REPLACE FUNCTION oracle.nls_initcap(char)
RETURNS text
AS 'initcap'
LANGUAGE internal
IMMUTABLE PARALLEL SAFE STRICT;

--number
CREATE OR REPLACE FUNCTION oracle.nls_initcap(numeric)
RETURNS text
AS 'select oracle.nls_initcap($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_initcap(float4)
RETURNS text
AS 'select oracle.nls_initcap($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_initcap(float8)
RETURNS text
AS 'select oracle.nls_initcap($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

--date time
CREATE OR REPLACE FUNCTION oracle.nls_initcap(pg_catalog.date)
RETURNS text
AS 'select oracle.nls_initcap($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_initcap(timestamp)
RETURNS text
AS 'select oracle.nls_initcap($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_initcap(timestamptz)
RETURNS text
AS 'select oracle.nls_initcap($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_initcap(interval)
RETURNS text
AS 'select oracle.nls_initcap($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;
/* --author:luotao */
/* increase nls_lower function */
CREATE OR REPLACE FUNCTION oracle.nls_lower(text)
RETURNS text
AS 'lower'
LANGUAGE internal
IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.nls_lower(text) IS 'all letters forced to lowercase.';

CREATE OR REPLACE FUNCTION oracle.nls_lower(char)
RETURNS text
AS 'lower'
LANGUAGE internal
IMMUTABLE PARALLEL SAFE STRICT;

--number
CREATE OR REPLACE FUNCTION oracle.nls_lower(numeric)
RETURNS text
AS 'select oracle.nls_lower($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_lower(float4)
RETURNS text
AS 'select oracle.nls_lower($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_lower(float8)
RETURNS text
AS 'select oracle.nls_lower($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

--date time
CREATE OR REPLACE FUNCTION oracle.nls_lower(pg_catalog.date)
RETURNS text
AS 'select oracle.nls_lower($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_lower(timestamp)
RETURNS text
AS 'select oracle.nls_lower($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_lower(timestamptz)
RETURNS text
AS 'select oracle.nls_lower($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_lower(interval)
RETURNS text
AS 'select oracle.nls_lower($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

/* --author:luotao */
/* increase nls_upper function */
CREATE OR REPLACE FUNCTION oracle.nls_upper(text)
RETURNS text
AS 'upper'
LANGUAGE internal
IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.nls_upper(text) IS 'all letters forced to uppercase.';

CREATE OR REPLACE FUNCTION oracle.nls_upper(char)
RETURNS text
AS 'upper'
LANGUAGE internal
IMMUTABLE PARALLEL SAFE STRICT;

--number
CREATE OR REPLACE FUNCTION oracle.nls_upper(numeric)
RETURNS text
AS 'select oracle.nls_upper($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_upper(float4)
RETURNS text
AS 'select oracle.nls_upper($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_upper(float8)
RETURNS text
AS 'select oracle.nls_upper($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

--date time
CREATE OR REPLACE FUNCTION oracle.nls_upper(pg_catalog.date)
RETURNS text
AS 'select oracle.nls_upper($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_upper(timestamp)
RETURNS text
AS 'select oracle.nls_upper($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_upper(timestamptz)
RETURNS text
AS 'select oracle.nls_upper($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.nls_upper(interval)
RETURNS text
AS 'select oracle.nls_upper($1::text)'
LANGUAGE SQL
IMMUTABLE PARALLEL SAFE STRICT;

/* --author:luotao */
/* increase ascii function */
CREATE OR REPLACE FUNCTION oracle.ascii(oracle.varchar2)
RETURNS integer
AS 'ascii'
LANGUAGE internal
IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.ascii(oracle.varchar2) IS 'returns the decimal representation of the first character from string.';

--number
CREATE OR REPLACE FUNCTION oracle.ascii(smallint)
RETURNS integer
AS 'select oracle.ascii($1::text)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.ascii(smallint) IS 'returns the decimal representation of the first character from string.';

CREATE OR REPLACE FUNCTION oracle.ascii(int)
RETURNS integer
AS 'select oracle.ascii($1::text)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.ascii(int) IS 'returns the decimal representation of the first character from string.';

CREATE OR REPLACE FUNCTION oracle.ascii(numeric)
RETURNS integer
AS 'select oracle.ascii($1::text)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.ascii(numeric) IS 'returns the decimal representation of the first character from string.';

CREATE OR REPLACE FUNCTION oracle.ascii(bigint)
RETURNS integer
AS 'select oracle.ascii($1::text)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.ascii(bigint) IS 'returns the decimal representation of the first character from string.';

CREATE OR REPLACE FUNCTION oracle.ascii(float4)
RETURNS integer
AS 'select oracle.ascii($1::text)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.ascii(float4) IS 'returns the decimal representation of the first character from string.';

CREATE OR REPLACE FUNCTION oracle.ascii(float8)
RETURNS integer
AS 'select oracle.ascii($1::text)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.ascii(float8) IS 'returns the decimal representation of the first character from string.';

--date
CREATE OR REPLACE FUNCTION oracle.ascii(pg_catalog.date)
RETURNS integer
AS 'select oracle.ascii($1::text)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.ascii(pg_catalog.date) IS 'returns the decimal representation of the first character from string.';

--timestamp
CREATE OR REPLACE FUNCTION oracle.ascii(timestamp)
RETURNS integer
AS 'select oracle.ascii($1::text)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.ascii(timestamp) IS 'returns the decimal representation of the first character from string.';

CREATE OR REPLACE FUNCTION oracle.ascii(timestamptz)
RETURNS integer
AS 'select oracle.ascii($1::text)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.ascii(timestamptz) IS 'returns the decimal representation of the first character from string.';

--interval
CREATE OR REPLACE FUNCTION oracle.ascii(interval)
RETURNS integer
AS 'select oracle.ascii($1::text)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.ascii(interval) IS 'returns the decimal representation of the first character from string.';

/* --author:luotao */
/* increase instrb function and its ellipsis parameter function */

--number
CREATE FUNCTION oracle.instrb(smallint, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(smallint, variadic "any") IS 'search string for substring uses bytes.';


CREATE FUNCTION oracle.instrb(int, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(int, variadic "any") IS 'search string for substring uses bytes.';

CREATE FUNCTION oracle.instrb(bigint, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(bigint, variadic "any") IS 'search string for substring uses bytes.';

CREATE FUNCTION oracle.instrb(numeric, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(numeric, variadic "any") IS 'search string for substring uses bytes.';

CREATE FUNCTION oracle.instrb(float4, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(float4, variadic "any") IS 'search string for substring uses bytes.';

CREATE FUNCTION oracle.instrb(float8, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(float8, variadic "any") IS 'search string for substring uses bytes.';

--string
CREATE FUNCTION oracle.instrb(char, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(char, variadic "any") IS 'search string for substring uses bytes.';

CREATE FUNCTION oracle.instrb(text, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(text, variadic "any") IS 'search string for substring uses bytes.';

--date time
CREATE FUNCTION oracle.instrb(pg_catalog.date, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(pg_catalog.date, variadic "any") IS 'search string for substring uses bytes.';

CREATE FUNCTION oracle.instrb(timestamp, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(timestamp, variadic "any") IS 'search string for substring uses bytes.';

CREATE FUNCTION oracle.instrb(timestamptz, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(timestamptz, variadic "any") IS 'search string for substring uses bytes.';

--interval
CREATE FUNCTION oracle.instrb(interval, variadic "any")
RETURNS integer
AS 'MODULE_PATHNAME','plvstr_instrb'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.instrb(interval, variadic "any") IS 'search string for substring uses bytes.';

/* --author:luotao */
/* increase vsize function */
CREATE FUNCTION oracle.vsize(var "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafce_vsize'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.vsize("any") IS 'returns the number of bytes in the internal representation of expr';

/* --author:luotao */
/* increase substr function and its ellipsis parameter function */
--overwrite pg_catalog.substr(text, integer, integer)
CREATE OR REPLACE FUNCTION oracle.substr(text, integer, integer)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_substr3'
LANGUAGE c
IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.substr(text, integer, integer) IS 'Returns substring started on start_in len chars.';

CREATE OR REPLACE FUNCTION oracle.substr(text, integer)
RETURNS text
AS 'MODULE_PATHNAME','plvstr_substr2'
LANGUAGE c
IMMUTABLE PARALLEL SAFE STRICT;
COMMENT ON FUNCTION  oracle.substr(text, integer) IS 'Returns substring started on start_in to end.';
--text

CREATE OR REPLACE FUNCTION oracle.substr(text, float8, float8)
RETURNS text
AS $$ SELECT oracle.substr($1, pg_catalog.trunc($2)::int, pg_catalog.trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(text, float8, float8) IS 'Returns substring started on start_in len chars.';

CREATE OR REPLACE FUNCTION oracle.substr(text, float8)
RETURNS text
AS $$ SELECT oracle.substr($1, pg_catalog.trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(text, float8) IS 'Returns substring started on start_in to end.';

--number
CREATE OR REPLACE FUNCTION oracle.substr(numeric, float8, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int, pg_catalog.trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(numeric, float8, float8) IS 'Returns substring started on start_in len chars.';

CREATE OR REPLACE FUNCTION oracle.substr(numeric, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(numeric, float8) IS 'Returns substring started on start_in to end.';

CREATE OR REPLACE FUNCTION oracle.substr(float4, float8, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int, pg_catalog.trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(float4, float8, float8) IS 'Returns substring started on start_in len chars.';

CREATE OR REPLACE FUNCTION oracle.substr(float4, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(float4, float8) IS 'Returns substring started on start_in to end.';

CREATE OR REPLACE FUNCTION oracle.substr(float8, float8, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int, pg_catalog.trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(float8, float8, float8) IS 'Returns substring started on start_in len chars.';

CREATE OR REPLACE FUNCTION oracle.substr(float8, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(float8, float8) IS 'Returns substring started on start_in to end.';

--date
CREATE OR REPLACE FUNCTION oracle.substr(pg_catalog.date, float8, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int, pg_catalog.trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(pg_catalog.date, float8, float8) IS 'Returns substring started on start_in len chars.';

CREATE OR REPLACE FUNCTION oracle.substr(pg_catalog.date, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(pg_catalog.date, float8) IS 'Returns substring started on start_in to end.';

--timestmap
CREATE OR REPLACE FUNCTION oracle.substr(timestamp, float8, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int, pg_catalog.trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(timestamp, float8, float8) IS 'Returns substring started on start_in len chars.';

CREATE OR REPLACE FUNCTION oracle.substr(timestamp, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(timestamp, float8) IS 'Returns substring started on start_in to end.';

CREATE OR REPLACE FUNCTION oracle.substr(timestamptz, float8, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int, pg_catalog.trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(timestamptz, float8, float8) IS 'Returns substring started on start_in len chars.';

CREATE OR REPLACE FUNCTION oracle.substr(timestamptz, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(timestamptz, float8) IS 'Returns substring started on start_in to end.';


--interval
CREATE OR REPLACE FUNCTION oracle.substr(interval, float8, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int, pg_catalog.trunc($3)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(interval, float8, float8) IS 'Returns substring started on start_in len chars.';

CREATE OR REPLACE FUNCTION oracle.substr(interval, float8)
RETURNS text
AS $$ SELECT oracle.substr($1::text, pg_catalog.trunc($2)::int) $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION  oracle.substr(interval, float8) IS 'Returns substring started on start_in to end.';

/* TRIM */
/* Incompatibility #1:
 *     oracle.ltrim, oracle.rtrim and oracle.btrim remove
 *     trailing blanks of CHAR arguments because of implicit cast to
 *     text
 *
 *     Following re-definitions address this incompatbility so that
 *     trailing blanks of CHAR arguments are preserved and considered
 *     significant for the trimming process.
 *
 * author:luotao
 *
 */

/* LTRIM family */
/* author:luotao */

CREATE FUNCTION oracle.ltrim("any", "any")
RETURNS text
AS 'MODULE_PATHNAME', 'ltrim_any2'
LANGUAGE C STRICT IMMUTABLE;

CREATE FUNCTION oracle.ltrim("any")
RETURNS text
AS 'MODULE_PATHNAME','ltrim_any1'
LANGUAGE C STRICT IMMUTABLE;

CREATE FUNCTION oracle.ltrim(text, text)
RETURNS text
AS 'ltrim'
LANGUAGE internal STRICT IMMUTABLE;

CREATE FUNCTION oracle.ltrim(text)
RETURNS text
AS 'ltrim1'
LANGUAGE internal STRICT IMMUTABLE;

/* RTRIM family */
/* author:luotao */
CREATE FUNCTION oracle.rtrim("any", "any")
RETURNS text
AS 'MODULE_PATHNAME', 'rtrim_any2'
LANGUAGE C STRICT IMMUTABLE;

CREATE FUNCTION oracle.rtrim("any")
RETURNS text
AS 'MODULE_PATHNAME','rtrim_any1'
LANGUAGE C STRICT IMMUTABLE;

CREATE FUNCTION oracle.rtrim(text, text)
RETURNS text
AS 'rtrim'
LANGUAGE internal STRICT IMMUTABLE;

CREATE FUNCTION oracle.rtrim(text)
RETURNS text
AS 'rtrim1'
LANGUAGE internal STRICT IMMUTABLE;

/* BTRIM family */
/* author:luotao */
CREATE FUNCTION oracle.btrim("any", "any")
RETURNS text
AS 'MODULE_PATHNAME', 'btrim_any2'
LANGUAGE C STRICT IMMUTABLE;

CREATE FUNCTION oracle.btrim("any")
RETURNS text
AS 'MODULE_PATHNAME','btrim_any1'
LANGUAGE C STRICT IMMUTABLE;

CREATE FUNCTION oracle.btrim(text, text)
RETURNS text
AS 'btrim'
LANGUAGE internal STRICT IMMUTABLE;

CREATE FUNCTION oracle.btrim(text)
RETURNS text
AS 'btrim1'
LANGUAGE internal STRICT IMMUTABLE;

/* LENGTH */
CREATE FUNCTION oracle.length(char)
RETURNS integer
AS 'MODULE_PATHNAME','orafce_bpcharlen'
LANGUAGE 'c'
STRICT IMMUTABLE
;

/* author:luotao */
CREATE OR REPLACE FUNCTION oracle.length(text)
RETURNS integer
AS 'textlen'
LANGUAGE internal IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.length(numeric)
RETURNS integer
AS 'select oracle.length($1::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.length(float4)
RETURNS integer
AS 'select oracle.length($1::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.length(float8)
RETURNS integer
AS 'select oracle.length($1::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.length(pg_catalog.date)
RETURNS integer
AS 'select oracle.length($1::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.length(timestamp)
RETURNS integer
AS 'select oracle.length($1::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.length(timestamptz)
RETURNS integer
AS 'select oracle.length($1::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.length(interval)
RETURNS integer
AS 'select oracle.length($1::oracle.varchar2)'
LANGUAGE SQL IMMUTABLE PARALLEL SAFE STRICT;

/* added begin by luotao at 2020/03/04 */
/* regexp_instr fucntion */
CREATE FUNCTION oracle.regexp_instr(char, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_instr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.regexp_instr(char, variadic "any") IS 'extends the functionality of the INSTR function by letting you search a string for a regular expression pattern.';

CREATE FUNCTION oracle.regexp_instr(text, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_instr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_instr(numeric, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_instr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_instr(float4, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_instr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_instr(float8, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_instr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_instr(pg_catalog.date, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_instr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_instr(timestamp, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_instr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_instr(timestamptz, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_instr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_instr(interval, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_instr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
/* added end by luotao at 2020/03/04 */

/* added begin by luotao at 2020/03/04 */
/* nlssort fucntion */
CREATE FUNCTION oracle.nlssort(text, text)
RETURNS bytea
AS 'MODULE_PATHNAME', 'ora_nlssort'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(text, text) IS '';

CREATE FUNCTION oracle.nlssort(text)
RETURNS bytea
AS 'MODULE_PATHNAME', 'ora_nlssort'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(text) IS '';

--number
CREATE FUNCTION oracle.nlssort(numeric, text)
RETURNS bytea
AS 'select oracle.nlssort($1::text, $2)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(numeric, text) IS '';

CREATE FUNCTION oracle.nlssort(numeric)
RETURNS bytea
AS 'select oracle.nlssort($1::text)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(numeric) IS '';

CREATE FUNCTION oracle.nlssort(float4, text)
RETURNS bytea
AS 'select oracle.nlssort($1::text, $2)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(float4, text) IS '';

CREATE FUNCTION oracle.nlssort(float4)
RETURNS bytea
AS 'select oracle.nlssort($1::text)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(float4) IS '';

CREATE FUNCTION oracle.nlssort(float8, text)
RETURNS bytea
AS 'select oracle.nlssort($1::text, $2)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(float8, text) IS '';

CREATE FUNCTION oracle.nlssort(float8)
RETURNS bytea
AS 'select oracle.nlssort($1::text)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(float8) IS '';

--date
CREATE FUNCTION oracle.nlssort(pg_catalog.date, text)
RETURNS bytea
AS 'select oracle.nlssort($1::text, $2)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(pg_catalog.date, text) IS '';

CREATE FUNCTION oracle.nlssort(pg_catalog.date)
RETURNS bytea
AS 'select oracle.nlssort($1::text)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(pg_catalog.date) IS '';

--timestamp
CREATE FUNCTION oracle.nlssort(timestamp, text)
RETURNS bytea
AS 'select oracle.nlssort($1::text, $2)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(timestamp, text) IS '';

CREATE FUNCTION oracle.nlssort(timestamp)
RETURNS bytea
AS 'select oracle.nlssort($1::text)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(timestamp) IS '';

CREATE FUNCTION oracle.nlssort(timestamptz, text)
RETURNS bytea
AS 'select oracle.nlssort($1::text, $2)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(timestamptz, text) IS '';

CREATE FUNCTION oracle.nlssort(timestamptz)
RETURNS bytea
AS 'select oracle.nlssort($1::text)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(timestamptz) IS '';

--interval
CREATE FUNCTION oracle.nlssort(interval, text)
RETURNS bytea
AS 'select oracle.nlssort($1::text, $2)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(interval, text) IS '';

CREATE FUNCTION oracle.nlssort(interval)
RETURNS bytea
AS 'select oracle.nlssort($1::text)'
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.nlssort(interval) IS '';
---
/* added end by luotao at 2020/03/04 */

/* added begin by luotao at 2020/03/04 */
/* regexp_count fucntion */
CREATE FUNCTION oracle.regexp_count(char, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_count'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_count(text, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_count'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_count(numeric, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_count'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_count(float4, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_count'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_count(float8, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_count'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_count(pg_catalog.date, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_count'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_count(timestamp, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_count'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_count(timestamptz, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_count'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_count(interval, variadic "any")
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_regexp_count'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
/* added end by luotao at 2020/03/04 */

/* added begin by luotao at 2020/03/04 */
/* regexp_substr fucntion */
CREATE FUNCTION oracle.regexp_substr(char, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafnp_regexp_substr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_substr(text, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafnp_regexp_substr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_substr(numeric, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafnp_regexp_substr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_substr(float4, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafnp_regexp_substr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_substr(float8, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafnp_regexp_substr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_substr(pg_catalog.date, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafnp_regexp_substr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_substr(timestamp, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafnp_regexp_substr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_substr(timestamptz, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafnp_regexp_substr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.regexp_substr(interval, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','orafnp_regexp_substr'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
/* added end by luotao at 2020/03/04 */

/* added begin by luotao at 2020/03/04 */
/* replace fucntion */
CREATE OR REPLACE FUNCTION oracle.replace(text, text, text)
RETURNS text
AS 'MODULE_PATHNAME','ora_replace_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.replace(text, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_replace_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.replace(char, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_replace_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.replace(numeric, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_replace_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.replace(float4, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_replace_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.replace(float8, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_replace_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.replace(pg_catalog.date, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_replace_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.replace(timestamp, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_replace_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.replace(timestamptz, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_replace_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.replace(interval, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_replace_text'
LANGUAGE C
IMMUTABLE PARALLEL SAFE;
/* added end by luotao at 2020/03/04 */

/* added begin by luotao at 2020/03/04 */
/* translate fucntion */
CREATE OR REPLACE FUNCTION oracle.translate(text, text, text)
RETURNS text
AS 'MODULE_PATHNAME','ora_translate'
LANGUAGE C
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.translate(text, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_translate'
LANGUAGE C
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.translate(char, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_translate'
LANGUAGE C
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.translate(numeric, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_translate'
LANGUAGE C
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.translate(float4, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_translate'
LANGUAGE C
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.translate(float8, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_translate'
LANGUAGE C
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.translate(pg_catalog.date, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_translate'
LANGUAGE C
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.translate(timestamp, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_translate'
LANGUAGE C
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.translate(timestamptz, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_translate'
LANGUAGE C
IMMUTABLE PARALLEL SAFE STRICT;

CREATE OR REPLACE FUNCTION oracle.translate(interval, variadic "any")
RETURNS text
AS 'MODULE_PATHNAME','ora_translate'
LANGUAGE C
IMMUTABLE PARALLEL SAFE STRICT;
/* added end by luotao at 2020/03/04 */

/* added begin by luotao at 2020/03/04 */
/* unistr fucntion */
CREATE FUNCTION oracle.unistr(text)
RETURNS text
AS 'MODULE_PATHNAME','orafnp_unistr'
LANGUAGE C IMMUTABLE STRICT  PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.unistr(text) IS 'takes as its argument a text literal or an expression that resolves to character data and returns it in the national character set.';

CREATE FUNCTION oracle.unistr(numeric)
RETURNS text
AS 'select oracle.unistr($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.unistr(float4)
RETURNS text
AS 'select oracle.unistr($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.unistr(float8)
RETURNS text
AS 'select oracle.unistr($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.unistr(pg_catalog.date)
RETURNS text
AS 'select oracle.unistr($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.unistr(timestamp)
RETURNS text
AS 'select oracle.unistr($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.unistr(timestamptz)
RETURNS text
AS 'select oracle.unistr($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.unistr(interval)
RETURNS text
AS 'select oracle.unistr($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;
/* added end by luotao at 2020/03/04 */

/* added begin by luotao at 2020/03/04 */
/* soundex fucntion */
CREATE FUNCTION oracle.soundex(text)
RETURNS text
AS 'MODULE_PATHNAME','orafnp_soundex'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.soundex(text) IS 'returns a character string containing the phonetic representation of char.';

CREATE FUNCTION oracle.soundex(numeric)
RETURNS text
AS 'select oracle.soundex($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.soundex(float4)
RETURNS text
AS 'select oracle.soundex($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.soundex(float8)
RETURNS text
AS 'select oracle.soundex($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.soundex(pg_catalog.date)
RETURNS text
AS 'select oracle.soundex($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.soundex(timestamp)
RETURNS text
AS 'select oracle.soundex($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.soundex(timestamptz)
RETURNS text
AS 'select oracle.soundex($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;

CREATE FUNCTION oracle.soundex(interval)
RETURNS text
AS 'select oracle.soundex($1::text)'
LANGUAGE SQL IMMUTABLE STRICT  PARALLEL SAFE;
/* added end by luotao at 2020/03/04 */

CREATE FUNCTION oracle.trunc(value timestamp without time zone, fmt text)
RETURNS timestamp without time zone
AS 'MODULE_PATHNAME', 'ora_timestamp_trunc'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.trunc(timestamp without time zone, text) IS 'truncate date according to the specified format';

CREATE FUNCTION oracle.round(value timestamp without time zone, fmt text)
RETURNS timestamp without time zone
AS 'MODULE_PATHNAME','ora_timestamp_round'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.round(timestamp with time zone, text) IS 'round dates according to the specified format';

CREATE FUNCTION oracle.round(value timestamp without time zone)
RETURNS timestamp without time zone
AS $$ SELECT oracle.round($1, 'DDD'); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.round(timestamp without time zone) IS 'will round dates according to the specified format';

CREATE FUNCTION oracle.trunc(value timestamp without time zone)
RETURNS timestamp without time zone
AS $$ SELECT oracle.trunc($1, 'DDD'); $$
LANGUAGE SQL IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.trunc(timestamp without time zone) IS 'truncate date according to the specified format';

CREATE OR REPLACE FUNCTION oracle.round(double precision, int)
RETURNS numeric
AS $$SELECT pg_catalog.round($1::numeric, $2)$$
LANGUAGE sql IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION oracle.trunc(double precision, int)
RETURNS numeric
AS $$SELECT pg_catalog.trunc($1::numeric, $2)$$
LANGUAGE sql IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION oracle.round(float4, int)
RETURNS numeric
AS $$SELECT pg_catalog.round($1::numeric, $2)$$
LANGUAGE sql IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION oracle.round(text)
RETURNS numeric
AS $$SELECT pg_catalog.round($1::numeric,  0)$$
LANGUAGE sql IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION oracle.round(text, int)
RETURNS numeric
AS $$SELECT pg_catalog.round($1::numeric, $2)$$
LANGUAGE sql IMMUTABLE STRICT;


CREATE OR REPLACE FUNCTION oracle.trunc(float4, int)
RETURNS numeric
AS $$SELECT pg_catalog.trunc($1::numeric, $2)$$
LANGUAGE sql IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION oracle.trunc(text)
RETURNS numeric
AS $$SELECT pg_catalog.trunc($1::numeric, 0)$$
LANGUAGE sql IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION oracle.trunc(text, int)
RETURNS numeric
AS $$SELECT pg_catalog.trunc($1::numeric, $2)$$
LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION oracle.get_major_version()
RETURNS text
AS 'MODULE_PATHNAME','ora_get_major_version'
LANGUAGE 'c' STRICT IMMUTABLE;

CREATE FUNCTION oracle.get_major_version_num()
RETURNS text
AS 'MODULE_PATHNAME','ora_get_major_version_num'
LANGUAGE 'c' STRICT IMMUTABLE;

CREATE FUNCTION oracle.get_full_version_num()
RETURNS text
AS 'MODULE_PATHNAME','ora_get_full_version_num'
LANGUAGE 'c' STRICT IMMUTABLE;

CREATE FUNCTION oracle.get_platform()
RETURNS text
AS 'MODULE_PATHNAME','ora_get_platform'
LANGUAGE 'c' STRICT IMMUTABLE;

CREATE FUNCTION oracle.get_status()
RETURNS text
AS 'MODULE_PATHNAME','ora_get_status'
LANGUAGE 'c' STRICT IMMUTABLE;

/*add by xuji*/
CREATE FUNCTION oracle.NLS_CHARSET_ID(Name)
RETURNS integer
AS 'MODULE_PATHNAME','pg_name_to_encoding'
LANGUAGE 'c' STRICT IMMUTABLE;

CREATE FUNCTION oracle.NLS_CHARSET_NAME(integer)
RETURNS Name
AS 'MODULE_PATHNAME','pg_encoding_to_name'
LANGUAGE 'c' STRICT IMMUTABLE;

CREATE TYPE oracle.line_num_text AS (line integer, text text);

CREATE FUNCTION oracle.num_with_line(text)
RETURNS SETOF oracle.line_num_text
AS 'MODULE_PATHNAME', 'num_with_line'
LANGUAGE C IMMUTABLE STRICT;
/*
-- Oracle system views
create view oracle.user_tab_columns as
    select table_name,
           column_name,
           data_type,
           coalesce(character_maximum_length, numeric_precision) AS data_length,
           numeric_precision AS data_precision,
           numeric_scale AS data_scale,
           is_nullable AS nullable,
           ordinal_position AS column_id,
           is_updatable AS data_upgraded,
           table_schema
    from information_schema.columns;

REVOKE ALL ON oracle.user_tab_columns FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_tab_columns TO PUBLIC;
*/
/*
create view oracle.user_tables as
    select table_name
      from information_schema.tables
     where table_type = 'BASE TABLE';

REVOKE ALL ON oracle.user_tables FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_tables TO PUBLIC;
*/
create view oracle.user_cons_columns as
   select constraint_name, column_name, table_name
     from information_schema.constraint_column_usage ;

REVOKE ALL ON oracle.user_cons_columns FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_cons_columns TO PUBLIC;

/*
create view oracle.user_constraints as
    select conname as constraint_name,
           conindid::regclass as index_name,
           case contype when 'p' then 'P' when 'f' then 'R' end as constraint_type,
           conrelid::regclass as table_name,
           case contype when 'f' then (select conname
                                         from pg_constraint c2
                                        where contype = 'p' and c2.conindid = c1.conindid)
                                      end as r_constraint_name
      from pg_constraint c1, pg_class
     where conrelid = pg_class.oid;

REVOKE ALL ON oracle.user_constraints FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_constraints TO PUBLIC;
*/
create view oracle.product_component_version as
    select oracle.get_major_version() as product,
           oracle.get_full_version_num() as version,
           oracle.get_platform() || ' ' || oracle.get_status() as status
    union all
    select extname,
           case when extname = 'plpgsql' then oracle.get_full_version_num() else extversion end,
           oracle.get_platform() || ' ' || oracle.get_status()
      from pg_extension;

REVOKE ALL ON oracle.product_component_version FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.product_component_version TO PUBLIC;

/*
create view oracle.user_objects as
    select relname as object_name,
           null::text as subject_name,
           c.oid as object_id,
           case relkind when 'r' then 'TABLE'
                        when 'i' then 'INDEX'
                        when 'S' then 'SEQUENCE'
                        when 'v' then 'VIEW'
                        when 'm' then 'VIEW'
                        when 'f' then 'FOREIGN TABLE' end as object_type,
           null::timestamp(0) as created,
           null::timestamp(0) as last_ddl_time,
           case when relkind = 'i' then (select case when indisvalid then 'VALID' else 'INVALID' end
                                          from pg_index
                                         where indexrelid = c.oid)
                                   else case when relispopulated then 'VALID' else 'INVALID' end end as status,
           relnamespace as namespace
      from pg_class c join pg_namespace n on c.relnamespace = n.oid
     where relkind not in  ('t','c')
       and nspname not in ('pg_toast','pg_catalog','information_schema')
    union all
    select tgname, null, t.oid, 'TRIGGER',null, null,'VALID', relnamespace
      from pg_trigger t join pg_class c on t.tgrelid = c.oid
     where not tgisinternal
    union all
    select proname, null, p.oid, 'FUNCTION', null, null, 'VALID', pronamespace
      from pg_proc p join pg_namespace n on p.pronamespace = n.oid
     where nspname not in ('pg_toast','pg_catalog','information_schema') order by 1;

REVOKE ALL ON oracle.user_objects FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_objects TO PUBLIC;
*/
create view oracle.user_procedures as
    select proname as object_name
      from pg_proc p join pg_namespace n on p.pronamespace = n.oid
       and nspname <> 'pg_catalog';

REVOKE ALL ON oracle.user_procedures FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_procedures TO PUBLIC;

create view oracle.user_source as
    select row_number() over (partition by oid) as line, *
      from ( select oid, unnest(string_to_array(prosrc, e'\n')) as text,
                    proname as name, 'FUNCTION'::text as type
               from pg_proc) s;

REVOKE ALL ON oracle.user_source FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_source TO PUBLIC;

create view oracle.user_views
   as select c.relname as view_name,
  pg_catalog.pg_get_userbyid(c.relowner) as owner,
  length((select definition from pg_catalog.pg_views where viewname = c.relname)) as text_length,
  (select definition from pg_catalog.pg_views where viewname = c.relname) as text,
  NULL as type_text_length,
  NULL as type_text,
  NULL as oid_text_length,
  NULL as oid_text,
  NULL as view_type_owner,
  NULL as view_type,
  NULL as superview_name,
  'N'  as editioning_view,
  'N'  as read_only
	from pg_catalog.pg_class c
     	left join pg_catalog.pg_namespace n on n.oid = c.relnamespace
	where c.relkind in ('v','')
      and n.nspname <> 'pg_catalog'
      and n.nspname <> 'information_schema'
      and n.nspname !~ '^pg_toast'
      and pg_catalog.pg_table_is_visible(c.oid);

REVOKE ALL ON oracle.user_views FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_views TO PUBLIC;

CREATE VIEW oracle.dba_source AS
 SELECT quote_ident((u.rolname)::text) AS owner,
    quote_ident((n.nspname)::text) AS schema_name,
    quote_ident((p.proname)::text) AS name,
        CASE
            WHEN (p.prokind = 'p'::"char") THEN 'PROCEDURE'::text
            ELSE 'FUNCTION'::text
        END AS type,
    (p.lt).line AS line,
    (p.lt).text AS text
   FROM ((( SELECT pg_proc.proname,
            pg_proc.pronamespace,
            pg_proc.proowner,
            pg_proc.prorettype,
            pg_proc.proargtypes,
            pg_proc.prokind,
            oracle.num_with_line(pg_get_functiondef(pg_proc.oid)) AS lt
           FROM pg_proc
          WHERE (pg_proc.prokind = ANY (ARRAY['f'::"char", 'p'::"char", 'a'::"char", 'w'::"char"]))) p
     JOIN pg_namespace n ON ((n.oid = p.pronamespace)))
     JOIN pg_authid u ON ((u.oid = p.proowner)))
  WHERE ((p.prorettype <> ('cstring'::regtype)::oid) AND ((p.proargtypes[0] IS NULL) OR (p.proargtypes[0] <> ('cstring'::regtype)::oid)) AND (p.prokind <> 'a'::"char"))
UNION ALL
 SELECT quote_ident((u.rolname)::text) AS owner,
    quote_ident((n.nspname)::text) AS schema_name,
    quote_ident((p.tgname)::text) AS name,
    'TRIGGER'::text AS type,
    (p.lt).line AS line,
    (p.lt).text AS text
   FROM ((( SELECT t.tgname,
            c.relnamespace,
            c.relowner,
            oracle.num_with_line(pg_get_triggerdef(t.oid)) AS lt
           FROM pg_trigger t,
            pg_class c
          WHERE (t.tgrelid = c.oid)) p
     JOIN pg_namespace n ON ((n.oid = p.relnamespace)))
     JOIN pg_authid u ON ((u.oid = p.relowner)));

REVOKE ALL ON oracle.dba_source FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_views TO PUBLIC;

/*
create view oracle.user_ind_columns as
    select attname as column_name, c1.relname as index_name, c2.relname as table_name
      from (select unnest(indkey) attno, indexrelid, indrelid from pg_index) s
           join pg_attribute on attno = attnum and attrelid = indrelid
           join pg_class c1 on indexrelid = c1.oid
           join pg_class c2 on indrelid = c2.oid
           join pg_namespace n on c2.relnamespace = n.oid
     where attno > 0 and nspname not in ('pg_catalog','information_schema');

REVOKE ALL ON oracle.user_ind_columns FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_ind_columns TO PUBLIC;
*/
CREATE VIEW oracle.dba_segments AS
SELECT
    pg_namespace.nspname AS owner,
    pg_class.relname AS segment_name,
    CASE
        WHEN pg_class.relkind = 'r' THEN CAST( 'TABLE' AS VARCHAR( 18 ) )
        WHEN pg_class.relkind = 'i' THEN CAST( 'INDEX' AS VARCHAR( 18 ) )
        WHEN pg_class.relkind = 'f' THEN CAST( 'FOREIGN TABLE' AS VARCHAR( 18 ) )
        WHEN pg_class.relkind = 'S' THEN CAST( 'SEQUENCE' AS VARCHAR( 18 ) )
        WHEN pg_class.relkind = 's' THEN CAST( 'SPECIAL' AS VARCHAR( 18 ) )
        WHEN pg_class.relkind = 't' THEN CAST( 'TOAST TABLE' AS VARCHAR( 18 ) )
        WHEN pg_class.relkind = 'v' THEN CAST( 'VIEW' AS VARCHAR( 18 ) )
        ELSE CAST( pg_class.relkind AS VARCHAR( 18 ) )
    END AS segment_type,
    spcname AS tablespace_name,
    relfilenode AS header_file,
    NULL::oid AS header_block,
    pg_relation_size( pg_class.oid ) AS bytes,
    relpages AS blocks
FROM
    pg_class
    INNER JOIN pg_namespace
     ON pg_class.relnamespace = pg_namespace.oid
    LEFT OUTER JOIN pg_tablespace
     ON pg_class.reltablespace = pg_tablespace.oid
WHERE
    pg_class.relkind not in ('f','S','v');

REVOKE ALL ON oracle.dba_segments FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.dba_segments TO PUBLIC;

--compatible time function
CREATE OR REPLACE FUNCTION oracle.numtodsinterval(double precision, text)
RETURNS interval AS $$
  SELECT $1 * ('1' || $2)::interval
$$ LANGUAGE sql IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION oracle.numtodsinterval(numeric, text)
RETURNS interval AS $$
  SELECT $1 * ('1' || $2)::interval
$$ LANGUAGE sql IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION oracle.numtoyminterval(double precision, text)
RETURNS interval AS $$
  SELECT $1 * ('1' || $2)::interval
$$ LANGUAGE sql IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION oracle.numtoyminterval(numeric, text)
RETURNS interval AS $$
  SELECT $1 * ('1' || $2)::interval
$$ LANGUAGE sql IMMUTABLE STRICT;

CREATE FUNCTION oracle.from_tz(TIMESTAMP, TEXT)
RETURNS cstring                
AS 'MODULE_PATHNAME','ora_fromtz'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.from_tz(TIMESTAMP, TEXT) IS 'Convert timestamp value of specific time zone to a timestamp with a time zone value.';

CREATE FUNCTION oracle.systimestamp()
RETURNS timestamptz
AS 'MODULE_PATHNAME','ora_systimestamp'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.systimestamp() IS 'get the system timestamp';

CREATE FUNCTION oracle.sys_extract_utc(tm timestamptz)
RETURNS timestamp              
AS 'MODULE_PATHNAME','ora_sys_extract_utc'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE; 
COMMENT ON FUNCTION  oracle.sys_extract_utc(timestamptz) IS 'extracts the UTC from a datetime value with time zone offset or time zone region name.';

CREATE FUNCTION oracle.days_between(TIMESTAMP, TIMESTAMP)
RETURNS numeric
AS 'MODULE_PATHNAME','ora_days_between'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.days_between(TIMESTAMP, TIMESTAMP) IS 'The days difference between the two timestamp values';

CREATE FUNCTION oracle.days_between_tmtz(TIMESTAMPTZ, TIMESTAMPTZ)
RETURNS numeric
AS 'MODULE_PATHNAME','ora_days_between_tmtz'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.days_between_tmtz(TIMESTAMPTZ, TIMESTAMPTZ) IS 'The days difference between the two timestamptz values';

--compatible v4 function add_days_to_timestamp
CREATE OR REPLACE FUNCTION oracle.add_days_to_timestamp(timestamp, numeric)
RETURNS timestamp AS $$
SELECT $1 + interval '1 day' * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.add_days_to_timestamp(timestamp, numeric)
RETURNS timestamp AS $$
SELECT $1 + interval '1 day' * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

--compatible v4 function subtract
CREATE OR REPLACE FUNCTION oracle.subtract(timestamptz, numeric)
RETURNS timestamptz AS $$
SELECT $1 - interval '1 day' * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.subtract(timestamptz, timestamptz)
RETURNS double precision AS $$
SELECT date_part('epoch', ($1 OPERATOR(pg_catalog.-) $2)/3600/24);
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.subtract(timestamp, numeric)
RETURNS timestamp AS $$
SELECT $1 - interval '1 day' * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.subtract(timestamp, timestamp)
RETURNS double precision AS $$
SELECT date_part('epoch', ($1 OPERATOR(pg_catalog.-) $2)/3600/24);
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

--compatible operator timestmap +/-
CREATE OR REPLACE FUNCTION oracle.timestamp_add_numeric(timestamp, numeric)
RETURNS timestamp AS $$
SELECT $1 + interval '1 day' * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_add_timestamp(numeric, timestamp)
RETURNS timestamp AS $$
SELECT $2 + interval '1 day' * $1;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.timestamp_add_text(timestamp, text)
RETURNS timestamp AS $$
SELECT $1 + $2::interval;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_add_timestamp(text, timestamp)
RETURNS timestamp AS $$
SELECT $2 + $1::interval;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.timestamp_subtract_numeric (timestamp, numeric)
RETURNS timestamp AS $$
SELECT $1 - interval '1 day' * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.timestamp_subtract_timestamp(timestamp,timestamp)
RETURNS interval AS $$
SELECT ($1 OPERATOR(pg_catalog.-) $2);
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.odate_subtract_odate(oracle.date, oracle.date)
RETURNS double precision AS $$
SELECT date_part('epoch', ($1::timestamp OPERATOR(pg_catalog.-) $2::timestamp)/3600/24);
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.timestamptz_add_numeric(timestamptz,numeric)
RETURNS timestamptz AS $$
SELECT $1 + interval '1 day' * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_add_timestamptz(numeric, timestamptz)
RETURNS timestamptz AS $$
SELECT $2 + interval '1 day' * $1;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.timestamptz_add_text(timestamptz, text)
RETURNS timestamptz AS $$
SELECT $1 + $2::interval;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_add_timestamptz(text, timestamptz)
RETURNS timestamptz AS $$
SELECT $2 + $1::interval;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.timestamptz_subtract_numeric(timestamptz, numeric)
RETURNS timestamptz AS $$
SELECT $1 - interval '1 day' * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.timestamptz_subtract_timestamptz(timestamptz, timestamptz)
RETURNS interval AS $$
SELECT ($1 OPERATOR(pg_catalog.-) $2);
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

--compatible timestamp +/- numeric,timestamp
CREATE OPERATOR oracle.+ (
  LEFTARG   = timestamp,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.timestamp_add_numeric
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = numeric,
  RIGHTARG  = timestamp,
  PROCEDURE = oracle.numeric_add_timestamp
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = timestamp,
  RIGHTARG  = text,
  PROCEDURE = oracle.timestamp_add_text
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = text,
  RIGHTARG  = timestamp,
  PROCEDURE = oracle.text_add_timestamp
);

CREATE OPERATOR oracle.- (
  LEFTARG   = timestamp,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.timestamp_subtract_numeric
);

CREATE OPERATOR oracle.- (
  LEFTARG   = timestamp,
  RIGHTARG  = timestamp,
  PROCEDURE = oracle.timestamp_subtract_timestamp
);

CREATE OPERATOR oracle.- (
  LEFTARG   = oracle.date,
  RIGHTARG  = oracle.date,
  PROCEDURE = oracle.odate_subtract_odate
);

--compatible timestamptz +/- numeric,timestamptz
CREATE OPERATOR oracle.+ (
  LEFTARG   = timestamptz,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.timestamptz_add_numeric
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = numeric,
  RIGHTARG  = timestamptz,
  PROCEDURE = oracle.numeric_add_timestamptz
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = timestamptz,
  RIGHTARG  = text,
  PROCEDURE = oracle.timestamptz_add_text
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = text,
  RIGHTARG  = timestamptz,
  PROCEDURE = oracle.text_add_timestamptz
);

CREATE OPERATOR oracle.- (
  LEFTARG   = timestamptz,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.timestamptz_subtract_numeric
);

CREATE OPERATOR oracle.- (
  LEFTARG   = timestamptz,
  RIGHTARG  = timestamptz,
  PROCEDURE = oracle.timestamptz_subtract_timestamptz
);

/*add at 20200116 authored  jinhuajian*/
--timestamptz +/- float
CREATE FUNCTION  oracle.timestamptz_pl_float4(t timestamptz, day float4 )
RETURNS timestamptz
AS 'MODULE_PATHNAME','timestamptz_pl_float4'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION   oracle.timestamptz_pl_float4(timestamptz, float4) IS 'Return to time with add days.';

CREATE FUNCTION  oracle.timestamptz_pl_float8(t timestamptz, day float8 )
RETURNS timestamptz
AS 'MODULE_PATHNAME','timestamptz_pl_float8'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION   oracle.timestamptz_pl_float8(timestamptz, float8) IS 'Return to time with add days.';

CREATE FUNCTION  oracle.timestamptz_mi_float4(t timestamptz, day float4 )
RETURNS timestamptz
AS 'MODULE_PATHNAME','timestamptz_mi_float4'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION   oracle.timestamptz_mi_float4(timestamptz, float4) IS 'Return to time with subtract days.'; 

CREATE FUNCTION  oracle.timestamptz_mi_float8(t timestamptz, day float8 )
RETURNS timestamptz
AS 'MODULE_PATHNAME','timestamptz_mi_float8'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION   oracle.timestamptz_mi_float8(timestamptz, float8) IS 'Return to time with subtract days.';

--timestmap +/- float
CREATE FUNCTION  oracle.timestamp_pl_float4(t timestamp, day float4)
RETURNS timestamp
AS $$ SELECT oracle.timestamptz_pl_float4($1::timestamptz, $2)::timestamp $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.timestamp_pl_float4(timestamp, float4) IS 'Return to timestamp with add days.';

CREATE FUNCTION  oracle.timestamp_pl_float8(t timestamp, day float8)
RETURNS timestamp
AS $$ SELECT oracle.timestamptz_pl_float8($1::timestamptz, $2)::timestamp $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.timestamp_pl_float8(timestamp, float8) IS 'Return to timestamp with add days.';

CREATE FUNCTION  oracle.timestamp_mi_float4(t timestamp, day float4)
RETURNS timestamp
AS $$ SELECT oracle.timestamptz_mi_float4($1::timestamptz, $2)::timestamp $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.timestamp_mi_float4(timestamp, float4) IS 'Return to timestamp with minus days.';

CREATE FUNCTION  oracle.timestamp_mi_float8(t timestamp, day float8)
RETURNS timestamp
AS $$ SELECT oracle.timestamptz_mi_float8($1::timestamptz, $2)::timestamp $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.timestamp_mi_float8(timestamp, float8) IS 'Return to timestamp with minus days.';

--float + timestmap
CREATE FUNCTION  oracle.float4_pl_timestamp(day float4, t timestamp)
RETURNS timestamp
AS $$ SELECT oracle.timestamptz_pl_float4($2::timestamptz, $1)::timestamp $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.float4_pl_timestamp(float4, timestamp) IS 'Return to timestamp with add days.';

CREATE FUNCTION  oracle.float8_pl_timestamp(day float8, t timestamp)
RETURNS timestamp
AS $$ SELECT oracle.timestamptz_pl_float8($2::timestamptz, $1)::timestamp $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.float8_pl_timestamp(float8, timestamp) IS 'Return to timestamp with add days.';

--float + timestamptz
CREATE FUNCTION  oracle.float4_pl_timestamptz(day float4, t timestamptz)
RETURNS timestamptz
AS $$ SELECT oracle.timestamptz_pl_float4($2, $1) $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.float4_pl_timestamptz(float4, timestamptz) IS 'Return to timestamptz with add days.';

CREATE FUNCTION  oracle.float8_pl_timestamptz(day float8, t timestamptz)
RETURNS timestamptz
AS $$ SELECT oracle.timestamptz_pl_float8($2, $1) $$
LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.float8_pl_timestamptz(float8, timestamptz) IS 'Return to timestamptz with add days.';

--timestamptz +/- float
CREATE OPERATOR oracle.+(
	procedure = oracle.timestamptz_pl_float4,
	leftarg = timestamptz,
	rightarg = float4);

CREATE OPERATOR oracle.+(
	procedure = oracle.timestamptz_pl_float8,
	leftarg = timestamptz,
	rightarg = float8);

CREATE OPERATOR oracle.-(
	procedure = oracle.timestamptz_mi_float4,
	leftarg = timestamptz,
	rightarg = float4);

CREATE OPERATOR oracle.-(
	procedure = oracle.timestamptz_mi_float8,
	leftarg = timestamptz,
	rightarg = float8);

--timestmap +/- float
CREATE OPERATOR oracle.+(
	procedure = oracle.timestamp_pl_float4,
	leftarg = timestamp,
	rightarg = float4);

CREATE OPERATOR oracle.+(
	procedure = oracle.timestamp_pl_float8,
	leftarg = timestamp,
	rightarg = float8);

CREATE OPERATOR oracle.-(
	procedure = oracle.timestamp_mi_float4,
	leftarg = timestamp,
	rightarg = float4);

CREATE OPERATOR oracle.-(
	procedure = oracle.timestamp_mi_float8,
	leftarg = timestamp,
	rightarg = float8);

--float + timestmap
CREATE OPERATOR oracle.+(
	procedure = oracle.float4_pl_timestamp,
	leftarg = float4,
	rightarg = timestamp);

CREATE OPERATOR oracle.+(
	procedure = oracle.float8_pl_timestamp,
	leftarg = float8,
	rightarg = timestamp);

--float + timestmap
CREATE OPERATOR oracle.+(
	procedure = oracle.float4_pl_timestamptz,
	leftarg = float4,
	rightarg = timestamptz);

CREATE OPERATOR oracle.+(
	procedure = oracle.float8_pl_timestamptz,
	leftarg = float8,
	rightarg = timestamptz);
/*end*/

-- Oracle system scheam add by qinshiyu

-- Oracle system domain
CREATE DOMAIN oracle.nclob AS text;
CREATE DOMAIN oracle.long AS text; 
CREATE DOMAIN oracle.bfile AS text;
CREATE DOMAIN oracle.binary_float AS float4;
CREATE DOMAIN oracle.binary_double AS float8;


-- oracle."long raw" type support
CREATE FUNCTION oracle.long_rawin(cstring)
RETURNS oracle."long raw"
AS 'MODULE_PATHNAME','long_rawin'
LANGUAGE C
STRICT
IMMUTABLE;

CREATE FUNCTION oracle.long_rawout(oracle."long raw")
RETURNS CSTRING
AS 'MODULE_PATHNAME','long_rawout'
LANGUAGE C
STRICT
IMMUTABLE;

CREATE FUNCTION oracle.long_rawrecv(internal)
RETURNS oracle."long raw"
AS 'MODULE_PATHNAME','long_rawrecv'
LANGUAGE C
STRICT
STABLE;

CREATE FUNCTION oracle.long_rawsend(oracle."long raw")
RETURNS bytea
AS 'MODULE_PATHNAME','long_rawsend'
LANGUAGE C
STRICT
STABLE;

CREATE FUNCTION oracle.long_rawcat(oracle."long raw", oracle."long raw")
RETURNS oracle."long raw"
AS 'MODULE_PATHNAME','long_rawcat'
LANGUAGE C
STRICT
STABLE;

/* CREATE TYPE */    
CREATE TYPE oracle."long raw" (
internallength = VARIABLE,
input = oracle.long_rawin,
output = oracle.long_rawout,
receive = oracle.long_rawrecv,
send = oracle.long_rawsend,
category = 'U',
STORAGE = 'extended'
);    

/* CREATE IMPLICIT */
CREATE CAST (oracle."long raw" AS bytea)
WITHOUT FUNCTION
AS IMPLICIT;

/* CREATE OPERATOR */
CREATE OPERATOR oracle.|| (
  LEFTARG   = oracle."long raw",
  RIGHTARG  = oracle."long raw",
  PROCEDURE = oracle.long_rawcat(oracle."long raw", oracle."long raw")
);

CREATE DOMAIN oracle.raw AS oracle."long raw";

CREATE FUNCTION oracle.new_time(timestamptz, text, text)
RETURNS timestamp
AS 'MODULE_PATHNAME','new_time'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION  oracle.new_time(timestamptz, text, text) IS 'returns the date and time in time zone timezone2 when date and time in time zone timezone1 are date.';

----------------------------------------------------------------------------------------------------
--compatible v4 text convert to numbertype.
CREATE FUNCTION oracle.text_to_int16("any")
RETURNS int2
AS 'MODULE_PATHNAME','text_to_int16'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.text_to_int16("any") IS 'Convert single character to smallint(16bit).';

CREATE FUNCTION oracle.text_to_int32("any")
RETURNS int4
AS 'MODULE_PATHNAME','text_to_int32'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.text_to_int32("any") IS 'Convert single character to integer(32bit).';

CREATE FUNCTION oracle.text_to_int64("any")
RETURNS int8
AS 'MODULE_PATHNAME','text_to_int64'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.text_to_int64("any") IS 'Convert single character to bigint(64bit).';

CREATE FUNCTION oracle.text_to_numeric("any")
RETURNS numeric
AS 'MODULE_PATHNAME','text_to_numeric'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.text_to_numeric("any") IS 'Convert single character to numeric.';

--remainder
CREATE FUNCTION oracle.remainder(arg1 numeric, arg2 numeric)
RETURNS numeric
AS 'MODULE_PATHNAME','orafnp_remainder_num'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION oracle.remainder(numeric, numeric) IS 'returns the  remainder of arg1 divided by arg2.';
--end
------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------
--compatible v4
CREATE FUNCTION oracle.sys_guid()
RETURNS text
AS 'MODULE_PATHNAME','orafnp_sys_guid'
LANGUAGE C VOLATILE STRICT PARALLEL UNSAFE;
COMMENT ON FUNCTION oracle.sys_guid() IS 'Generates and returns a globally unique identifier (text value).';

CREATE OR REPLACE FUNCTION oracle.tz_offset(text) 
RETURNS text as $$
  SELECT utc_offset::text FROM pg_timezone_names WHERE name=$1 limit 1;
$$ LANGUAGE SQL STRICT PARALLEL SAFE;

CREATE FUNCTION oracle.sys_context(nsp text, para text, len int4)
RETURNS text
AS 'MODULE_PATHNAME','orafnp_sys_context'
LANGUAGE C IMMUTABLE STRICT PARALLEL RESTRICTED;
COMMENT ON FUNCTION oracle.sys_context(text, text, int4) IS 'returns the value of parameter associated with the context namespace.';

CREATE FUNCTION oracle.set(arr anyarray)
RETURNS anyarray
AS 'MODULE_PATHNAME','orafnp_set'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.set(anyarray) IS 'converts a nested table into a set by eliminating duplicates.';

CREATE FUNCTION oracle.uid()
RETURNS int4
AS 'MODULE_PATHNAME','orafnp_get_uid'
LANGUAGE C IMMUTABLE STRICT PARALLEL SAFE;
COMMENT ON FUNCTION oracle.uid() IS 'get the user id';

CREATE FUNCTION oracle.userenv(para text)
RETURNS text
AS 'MODULE_PATHNAME','orafnp_userenv'
LANGUAGE C IMMUTABLE STRICT PARALLEL RESTRICTED;
COMMENT ON FUNCTION oracle.userenv(text) IS 'return information of current session';
--end
----------------------------------------------------------------------------------------------------


-----------------------------------------------------------------
--compatible numeric/float/float8 op text
--if you use implicit cast to implement this function. you should iport bug about ambiguity problem when select some function.
-----------------------------------------------------------------
-----------------------------------------------------------------
-- equal and unequal
-----------------------------------------------------------------
--equal
CREATE OR REPLACE FUNCTION oracle.varchar2_eq_numeric(oracle.varchar2, numeric)
RETURNS bool AS $$
SELECT $1::numeric = $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_eq_varchar2(numeric, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 = $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_eq_float4(oracle.varchar2, float4)
RETURNS bool AS $$
SELECT $1::float4 = $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_eq_varchar2(float4, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 = $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_eq_float8(oracle.varchar2, float8)
RETURNS bool AS $$
SELECT $1::float8 = $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_eq_varchar2(float8, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 = $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.varchar2_eq_numeric,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

CREATE OPERATOR oracle.= (
  LEFTARG   = numeric,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.numeric_eq_varchar2,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

CREATE OPERATOR oracle.= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float4,
  PROCEDURE = oracle.varchar2_eq_float4,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

CREATE OPERATOR oracle.= (
  LEFTARG   = float4,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float4_eq_varchar2,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

CREATE OPERATOR oracle.= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float8,
  PROCEDURE = oracle.varchar2_eq_float8,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

CREATE OPERATOR oracle.= (
  LEFTARG   = float8,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float8_eq_varchar2,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);


--equal text
CREATE OR REPLACE FUNCTION oracle.text_eq_numeric(text, numeric)
RETURNS bool AS $$
SELECT $1::numeric = $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_eq_text(numeric, text)
RETURNS bool AS $$
SELECT $1 = $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_eq_float4(text, float4)
RETURNS bool AS $$
SELECT $1::float4 = $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_eq_text(float4, text)
RETURNS bool AS $$
SELECT $1 = $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_eq_float8(text, float8)
RETURNS bool AS $$
SELECT $1::float8 = $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_eq_text(float8, text)
RETURNS bool AS $$
SELECT $1 = $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.= (
  LEFTARG   = text,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.text_eq_numeric,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

CREATE OPERATOR oracle.= (
  LEFTARG   = numeric,
  RIGHTARG  = text,
  PROCEDURE = oracle.numeric_eq_text,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

CREATE OPERATOR oracle.= (
  LEFTARG   = text,
  RIGHTARG  = float4,
  PROCEDURE = oracle.text_eq_float4,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

CREATE OPERATOR oracle.= (
  LEFTARG   = float4,
  RIGHTARG  = text,
  PROCEDURE = oracle.float4_eq_text,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

CREATE OPERATOR oracle.= (
  LEFTARG   = text,
  RIGHTARG  = float8,
  PROCEDURE = oracle.text_eq_float8,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

CREATE OPERATOR oracle.= (
  LEFTARG   = float8,
  RIGHTARG  = text,
  PROCEDURE = oracle.float8_eq_text,
  COMMUTATOR = operator(oracle.=),
  NEGATOR = operator(oracle.<>)
);

--ne
CREATE OR REPLACE FUNCTION oracle.text_ne_numeric(text, numeric)
RETURNS bool AS $$
SELECT $1::numeric != $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_ne_text(numeric, text)
RETURNS bool AS $$
SELECT $1 != $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_ne_float4(text, float4)
RETURNS bool AS $$
SELECT $1::float4 != $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_ne_text(float4, text)
RETURNS bool AS $$
SELECT $1 != $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_ne_float8(text, float8)
RETURNS bool AS $$
SELECT $1::float8 != $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_ne_text(float8, text)
RETURNS bool AS $$
SELECT $1 != $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.<> (
  LEFTARG   = text,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.text_ne_numeric,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

CREATE OPERATOR oracle.<> (
  LEFTARG   = numeric,
  RIGHTARG  = text,
  PROCEDURE = oracle.numeric_ne_text,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

CREATE OPERATOR oracle.<> (
  LEFTARG   = text,
  RIGHTARG  = float4,
  PROCEDURE = oracle.text_ne_float4,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

CREATE OPERATOR oracle.<> (
  LEFTARG   = float4,
  RIGHTARG  = text,
  PROCEDURE = oracle.float4_ne_text,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

CREATE OPERATOR oracle.<> (
  LEFTARG   = text,
  RIGHTARG  = float8,
  PROCEDURE = oracle.text_ne_float8,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

CREATE OPERATOR oracle.<> (
  LEFTARG   = float8,
  RIGHTARG  = text,
  PROCEDURE = oracle.float8_ne_text,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

CREATE OR REPLACE FUNCTION oracle.varchar2_ne_numeric(oracle.varchar2, numeric)
RETURNS bool AS $$
SELECT $1::numeric != $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_ne_varchar2(numeric, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 != $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_ne_float4(oracle.varchar2, float4)
RETURNS bool AS $$
SELECT $1::float4 != $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_ne_varchar2(float4, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 != $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_ne_float8(oracle.varchar2, float8)
RETURNS bool AS $$
SELECT $1::float8 != $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_ne_varchar2(float8, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 != $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.<> (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.varchar2_ne_numeric,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

CREATE OPERATOR oracle.<> (
  LEFTARG   = numeric,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.numeric_ne_varchar2,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

CREATE OPERATOR oracle.<> (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float4,
  PROCEDURE = oracle.varchar2_ne_float4,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

CREATE OPERATOR oracle.<> (
  LEFTARG   = float4,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float4_ne_varchar2,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

CREATE OPERATOR oracle.<> (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float8,
  PROCEDURE = oracle.varchar2_ne_float8,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

CREATE OPERATOR oracle.<> (
  LEFTARG   = float8,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float8_ne_varchar2,
  COMMUTATOR = operator(oracle.<>),
  NEGATOR = operator(oracle.=)
);

-----------------------------------------------------------------
--le and greate
-----------------------------------------------------------------
--le
CREATE OR REPLACE FUNCTION oracle.text_le_numeric(text, numeric)
RETURNS bool AS $$
SELECT $1::numeric <= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_le_text(numeric, text)
RETURNS bool AS $$
SELECT $1 <= $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_le_float4(text, float4)
RETURNS bool AS $$
SELECT $1::float4 <= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_le_text(float4, text)
RETURNS bool AS $$
SELECT $1 <= $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_le_float8(text, float8)
RETURNS bool AS $$
SELECT $1::float8 <= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_le_text(float8, text)
RETURNS bool AS $$
SELECT $1 <= $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.<= (
  LEFTARG   = text,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.text_le_numeric,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

CREATE OPERATOR oracle.<= (
  LEFTARG   = numeric,
  RIGHTARG  = text,
  PROCEDURE = oracle.numeric_le_text,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

CREATE OPERATOR oracle.<= (
  LEFTARG   = text,
  RIGHTARG  = float4,
  PROCEDURE = oracle.text_le_float4,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

CREATE OPERATOR oracle.<= (
  LEFTARG   = float4,
  RIGHTARG  = text,
  PROCEDURE = oracle.float4_le_text,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

CREATE OPERATOR oracle.<= (
  LEFTARG   = text,
  RIGHTARG  = float8,
  PROCEDURE = oracle.text_le_float8,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

CREATE OPERATOR oracle.<= (
  LEFTARG   = float8,
  RIGHTARG  = text,
  PROCEDURE = oracle.float8_le_text,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

CREATE OR REPLACE FUNCTION oracle.varchar2_le_numeric(oracle.varchar2, numeric)
RETURNS bool AS $$
SELECT $1::numeric <= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_le_varchar2(numeric, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 <= $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_le_float4(oracle.varchar2, float4)
RETURNS bool AS $$
SELECT $1::float4 <= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_le_varchar2(float4, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 <= $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_le_float8(oracle.varchar2, float8)
RETURNS bool AS $$
SELECT $1::float8 <= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_le_varchar2(float8, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 <= $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.<= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.varchar2_le_numeric,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

CREATE OPERATOR oracle.<= (
  LEFTARG   = numeric,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.numeric_le_varchar2,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

CREATE OPERATOR oracle.<= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float4,
  PROCEDURE = oracle.varchar2_le_float4,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

CREATE OPERATOR oracle.<= (
  LEFTARG   = float4,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float4_le_varchar2,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

CREATE OPERATOR oracle.<= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float8,
  PROCEDURE = oracle.varchar2_le_float8,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

CREATE OPERATOR oracle.<= (
  LEFTARG   = float8,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float8_le_varchar2,
  COMMUTATOR = operator(oracle.>=),
  NEGATOR = operator(oracle.>)
);

--great
CREATE OR REPLACE FUNCTION oracle.text_gt_numeric(text, numeric)
RETURNS bool AS $$
SELECT $1::numeric > $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_gt_text(numeric, text)
RETURNS bool AS $$
SELECT $1 > $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_gt_float4(text, float4)
RETURNS bool AS $$
SELECT $1::float4 > $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_gt_text(float4, text)
RETURNS bool AS $$
SELECT $1 > $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_gt_float8(text, float8)
RETURNS bool AS $$
SELECT $1::float8 > $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_gt_text(float8, text)
RETURNS bool AS $$
SELECT $1 > $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.> (
  LEFTARG   = text,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.text_gt_numeric,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

CREATE OPERATOR oracle.> (
  LEFTARG   = numeric,
  RIGHTARG  = text,
  PROCEDURE = oracle.numeric_gt_text,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

CREATE OPERATOR oracle.> (
  LEFTARG   = text,
  RIGHTARG  = float4,
  PROCEDURE = oracle.text_gt_float4,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

CREATE OPERATOR oracle.> (
  LEFTARG   = float4,
  RIGHTARG  = text,
  PROCEDURE = oracle.float4_gt_text,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

CREATE OPERATOR oracle.> (
  LEFTARG   = text,
  RIGHTARG  = float8,
  PROCEDURE = oracle.text_gt_float8,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

CREATE OPERATOR oracle.> (
  LEFTARG   = float8,
  RIGHTARG  = text,
  PROCEDURE = oracle.float8_gt_text,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

CREATE OR REPLACE FUNCTION oracle.varchar2_gt_numeric(oracle.varchar2, numeric)
RETURNS bool AS $$
SELECT $1::numeric > $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_gt_varchar2(numeric, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 > $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_gt_float4(oracle.varchar2, float4)
RETURNS bool AS $$
SELECT $1::float4 > $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_gt_varchar2(float4, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 > $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_gt_float8(oracle.varchar2, float8)
RETURNS bool AS $$
SELECT $1::float8 > $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_gt_varchar2(float8, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 > $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.> (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.varchar2_gt_numeric,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

CREATE OPERATOR oracle.> (
  LEFTARG   = numeric,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.numeric_gt_varchar2,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

CREATE OPERATOR oracle.> (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float4,
  PROCEDURE = oracle.varchar2_gt_float4,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

CREATE OPERATOR oracle.> (
  LEFTARG   = float4,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float4_gt_varchar2,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

CREATE OPERATOR oracle.> (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float8,
  PROCEDURE = oracle.varchar2_gt_float8,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

CREATE OPERATOR oracle.> (
  LEFTARG   = float8,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float8_gt_varchar2,
  COMMUTATOR = operator(oracle.<),
  NEGATOR = operator(oracle.<=)
);

-----------------------------------------------------------------
--ge and letter
-----------------------------------------------------------------
--ge
CREATE OR REPLACE FUNCTION oracle.text_ge_numeric(text, numeric)
RETURNS bool AS $$
SELECT $1::numeric >= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_ge_text(numeric, text)
RETURNS bool AS $$
SELECT $1 >= $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_ge_float4(text, float4)
RETURNS bool AS $$
SELECT $1::float4 >= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_ge_text(float4, text)
RETURNS bool AS $$
SELECT $1 >= $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_ge_float8(text, float8)
RETURNS bool AS $$
SELECT $1::float8 >= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_ge_text(float8, text)
RETURNS bool AS $$
SELECT $1 >= $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.>= (
  LEFTARG   = text,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.text_ge_numeric,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

CREATE OPERATOR oracle.>= (
  LEFTARG   = numeric,
  RIGHTARG  = text,
  PROCEDURE = oracle.numeric_ge_text,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

CREATE OPERATOR oracle.>= (
  LEFTARG   = text,
  RIGHTARG  = float4,
  PROCEDURE = oracle.text_ge_float4,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

CREATE OPERATOR oracle.>= (
  LEFTARG   = float4,
  RIGHTARG  = text,
  PROCEDURE = oracle.float4_ge_text,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

CREATE OPERATOR oracle.>= (
  LEFTARG   = text,
  RIGHTARG  = float8,
  PROCEDURE = oracle.text_ge_float8,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

CREATE OPERATOR oracle.>= (
  LEFTARG   = float8,
  RIGHTARG  = text,
  PROCEDURE = oracle.float8_ge_text,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

CREATE OR REPLACE FUNCTION oracle.varchar2_ge_numeric(oracle.varchar2, numeric)
RETURNS bool AS $$
SELECT $1::numeric >= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_ge_varchar2(numeric, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 >= $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_ge_float4(oracle.varchar2, float4)
RETURNS bool AS $$
SELECT $1::float4 >= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_ge_varchar2(float4, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 >= $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_ge_float8(oracle.varchar2, float8)
RETURNS bool AS $$
SELECT $1::float8 >= $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_ge_varchar2(float8, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 >= $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.>= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.varchar2_ge_numeric,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

CREATE OPERATOR oracle.>= (
  LEFTARG   = numeric,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.numeric_ge_varchar2,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

CREATE OPERATOR oracle.>= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float4,
  PROCEDURE = oracle.varchar2_ge_float4,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

CREATE OPERATOR oracle.>= (
  LEFTARG   = float4,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float4_ge_varchar2,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

CREATE OPERATOR oracle.>= (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float8,
  PROCEDURE = oracle.varchar2_ge_float8,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

CREATE OPERATOR oracle.>= (
  LEFTARG   = float8,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float8_ge_varchar2,
  COMMUTATOR = operator(oracle.<=),
  NEGATOR = operator(oracle.<)
);

--letter
CREATE OR REPLACE FUNCTION oracle.text_lt_numeric(text, numeric)
RETURNS bool AS $$
SELECT $1::numeric < $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_lt_text(numeric, text)
RETURNS bool AS $$
SELECT $1 < $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_lt_float4(text, float4)
RETURNS bool AS $$
SELECT $1::float4 < $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_lt_text(float4, text)
RETURNS bool AS $$
SELECT $1 < $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_lt_float8(text, float8)
RETURNS bool AS $$
SELECT $1::float8 < $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_lt_text(float8, text)
RETURNS bool AS $$
SELECT $1 < $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.< (
  LEFTARG   = text,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.text_lt_numeric,
  COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

CREATE OPERATOR oracle.< (
  LEFTARG   = numeric,
  RIGHTARG  = text,
  PROCEDURE = oracle.numeric_lt_text,
  COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

CREATE OPERATOR oracle.< (
  LEFTARG   = text,
  RIGHTARG  = float4,
  PROCEDURE = oracle.text_lt_float4,
  COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

CREATE OPERATOR oracle.< (
  LEFTARG   = float4,
  RIGHTARG  = text,
  PROCEDURE = oracle.float4_lt_text,
   COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

CREATE OPERATOR oracle.< (
  LEFTARG   = text,
  RIGHTARG  = float8,
  PROCEDURE = oracle.text_lt_float8,
  COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

CREATE OPERATOR oracle.< (
  LEFTARG   = float8,
  RIGHTARG  = text,
  PROCEDURE = oracle.float8_lt_text,
  COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

CREATE OR REPLACE FUNCTION oracle.varchar2_lt_numeric(oracle.varchar2, numeric)
RETURNS bool AS $$
SELECT $1::numeric < $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_lt_varchar2(numeric, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 < $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_lt_float4(oracle.varchar2, float4)
RETURNS bool AS $$
SELECT $1::float4 < $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_lt_varchar2(float4, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 < $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_lt_float8(oracle.varchar2, float8)
RETURNS bool AS $$
SELECT $1::float8 < $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_lt_varchar2(float8, oracle.varchar2)
RETURNS bool AS $$
SELECT $1 < $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.< (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.varchar2_lt_numeric,
  COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

CREATE OPERATOR oracle.< (
  LEFTARG   = numeric,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.numeric_lt_varchar2,
  COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

CREATE OPERATOR oracle.< (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float4,
  PROCEDURE = oracle.varchar2_lt_float4,
  COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

CREATE OPERATOR oracle.< (
  LEFTARG   = float4,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float4_lt_varchar2,
   COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

CREATE OPERATOR oracle.< (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float8,
  PROCEDURE = oracle.varchar2_lt_float8,
  COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

CREATE OPERATOR oracle.< (
  LEFTARG   = float8,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float8_lt_varchar2,
  COMMUTATOR = operator(oracle.>),
  NEGATOR = operator(oracle.>=)
);

------------------------------------------------------------------
--add and subtract
------------------------------------------------------------------
--add
CREATE OR REPLACE FUNCTION oracle.text_add_numeric(text, numeric)
RETURNS numeric AS $$
SELECT $1::numeric + $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_add_text(numeric, text)
RETURNS numeric AS $$
SELECT $1 + $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_add_float4(text, float4)
RETURNS float4 AS $$
SELECT $1::float4 + $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_add_text(float4, text)
RETURNS float4 AS $$
SELECT $1 + $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_add_float8(text, float8)
RETURNS float8 AS $$
SELECT $1::float8 + $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_add_text(float8, text)
RETURNS float8 AS $$
SELECT $1 + $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.+ (
  LEFTARG   = text,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.text_add_numeric,
  COMMUTATOR = operator(oracle.+)
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = numeric,
  RIGHTARG  = text,
  PROCEDURE = oracle.numeric_add_text,
  COMMUTATOR = operator(oracle.+)
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = text,
  RIGHTARG  = float4,
  PROCEDURE = oracle.text_add_float4,
  COMMUTATOR = operator(oracle.+)
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = float4,
  RIGHTARG  = text,
  PROCEDURE = oracle.float4_add_text,
  COMMUTATOR = operator(oracle.+)
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = text,
  RIGHTARG  = float8,
  PROCEDURE = oracle.text_add_float8,
  COMMUTATOR = operator(oracle.+)
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = float8,
  RIGHTARG  = text,
  PROCEDURE = oracle.float8_add_text,
  COMMUTATOR = operator(oracle.+)
);

CREATE OR REPLACE FUNCTION oracle.varchar2_add_numeric(oracle.varchar2, numeric)
RETURNS numeric AS $$
SELECT $1::numeric + $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_add_varchar2(numeric, oracle.varchar2)
RETURNS numeric AS $$
SELECT $1 + $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_add_float4(oracle.varchar2, float4)
RETURNS float4 AS $$
SELECT $1::float4 + $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_add_varchar2(float4, oracle.varchar2)
RETURNS float4 AS $$
SELECT $1 + $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_add_float8(oracle.varchar2, float8)
RETURNS float8 AS $$
SELECT $1::float8 + $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_add_varchar2(float8, oracle.varchar2)
RETURNS float8 AS $$
SELECT $1 + $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.+ (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.varchar2_add_numeric,
  COMMUTATOR = operator(oracle.+)
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = numeric,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.numeric_add_varchar2,
  COMMUTATOR = operator(oracle.+)
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float4,
  PROCEDURE = oracle.varchar2_add_float4,
  COMMUTATOR = operator(oracle.+)
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = float4,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float4_add_varchar2,
  COMMUTATOR = operator(oracle.+)
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float8,
  PROCEDURE = oracle.varchar2_add_float8,
  COMMUTATOR = operator(oracle.+)
);

CREATE OPERATOR oracle.+ (
  LEFTARG   = float8,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float8_add_varchar2,
  COMMUTATOR = operator(oracle.+)
);

--sub
CREATE OR REPLACE FUNCTION oracle.text_sub_numeric(text, numeric)
RETURNS numeric AS $$
SELECT $1::numeric - $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_sub_text(numeric, text)
RETURNS numeric AS $$
SELECT $1 - $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_sub_float4(text, float4)
RETURNS float4 AS $$
SELECT $1::float4 - $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_sub_text(float4, text)
RETURNS float4 AS $$
SELECT $1 - $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_sub_float8(text, float8)
RETURNS float8 AS $$
SELECT $1::float8 - $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_sub_text(float8, text)
RETURNS float8 AS $$
SELECT $1 - $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.- (
  LEFTARG   = text,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.text_sub_numeric
);

CREATE OPERATOR oracle.- (
  LEFTARG   = numeric,
  RIGHTARG  = text,
  PROCEDURE = oracle.numeric_sub_text
);

CREATE OPERATOR oracle.- (
  LEFTARG   = text,
  RIGHTARG  = float4,
  PROCEDURE = oracle.text_sub_float4
);

CREATE OPERATOR oracle.- (
  LEFTARG   = float4,
  RIGHTARG  = text,
  PROCEDURE = oracle.float4_sub_text
);

CREATE OPERATOR oracle.- (
  LEFTARG   = text,
  RIGHTARG  = float8,
  PROCEDURE = oracle.text_sub_float8
);

CREATE OPERATOR oracle.- (
  LEFTARG   = float8,
  RIGHTARG  = text,
  PROCEDURE = oracle.float8_sub_text
);

CREATE OR REPLACE FUNCTION oracle.varchar2_sub_numeric(oracle.varchar2, numeric)
RETURNS numeric AS $$
SELECT $1::numeric - $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_sub_varchar2(numeric, oracle.varchar2)
RETURNS numeric AS $$
SELECT $1 - $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_sub_float4(oracle.varchar2, float4)
RETURNS float4 AS $$
SELECT $1::float4 - $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_sub_varchar2(float4, oracle.varchar2)
RETURNS float4 AS $$
SELECT $1 - $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_sub_float8(oracle.varchar2, float8)
RETURNS float8 AS $$
SELECT $1::float8 - $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_sub_varchar2(float8, oracle.varchar2)
RETURNS float8 AS $$
SELECT $1 - $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.- (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.varchar2_sub_numeric
);

CREATE OPERATOR oracle.- (
  LEFTARG   = numeric,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.numeric_sub_varchar2
);

CREATE OPERATOR oracle.- (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float4,
  PROCEDURE = oracle.varchar2_sub_float4
);

CREATE OPERATOR oracle.- (
  LEFTARG   = float4,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float4_sub_varchar2
);

CREATE OPERATOR oracle.- (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float8,
  PROCEDURE = oracle.varchar2_sub_float8
);

CREATE OPERATOR oracle.- (
  LEFTARG   = float8,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float8_sub_varchar2
);

--mul
CREATE OR REPLACE FUNCTION oracle.text_mul_numeric(text, numeric)
RETURNS numeric AS $$
SELECT $1::numeric * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_mul_text(numeric, text)
RETURNS numeric AS $$
SELECT $1 * $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_mul_float4(text, float4)
RETURNS float4 AS $$
SELECT $1::float4 * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_mul_text(float4, text)
RETURNS float4 AS $$
SELECT $1 * $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_mul_float8(text, float8)
RETURNS float8 AS $$
SELECT $1::float8 * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_mul_text(float8, text)
RETURNS float8 AS $$
SELECT $1 * $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.* (
  LEFTARG   = text,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.text_mul_numeric,
  COMMUTATOR = operator(oracle.*)
);

CREATE OPERATOR oracle.* (
  LEFTARG   = numeric,
  RIGHTARG  = text,
  PROCEDURE = oracle.numeric_mul_text,
  COMMUTATOR = operator(oracle.*)
);

CREATE OPERATOR oracle.* (
  LEFTARG   = text,
  RIGHTARG  = float4,
  PROCEDURE = oracle.text_mul_float4,
  COMMUTATOR = operator(oracle.*)
);

CREATE OPERATOR oracle.* (
  LEFTARG   = float4,
  RIGHTARG  = text,
  PROCEDURE = oracle.float4_mul_text,
  COMMUTATOR = operator(oracle.*)
);

CREATE OPERATOR oracle.* (
  LEFTARG   = text,
  RIGHTARG  = float8,
  PROCEDURE = oracle.text_mul_float8,
  COMMUTATOR = operator(oracle.*)
);

CREATE OPERATOR oracle.* (
  LEFTARG   = float8,
  RIGHTARG  = text,
  PROCEDURE = oracle.float8_mul_text,
  COMMUTATOR = operator(oracle.*)
);

CREATE OR REPLACE FUNCTION oracle.varchar2_mul_numeric(oracle.varchar2, numeric)
RETURNS numeric AS $$
SELECT $1::numeric * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_mul_varchar2(numeric, oracle.varchar2)
RETURNS numeric AS $$
SELECT $1 * $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_mul_float4(oracle.varchar2, float4)
RETURNS float4 AS $$
SELECT $1::float4 * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_mul_varchar2(float4, oracle.varchar2)
RETURNS float4 AS $$
SELECT $1 * $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_mul_float8(oracle.varchar2, float8)
RETURNS float8 AS $$
SELECT $1::float8 * $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_mul_varchar2(float8, oracle.varchar2)
RETURNS float8 AS $$
SELECT $1 * $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle.* (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.varchar2_mul_numeric,
  COMMUTATOR = operator(oracle.*)
);

CREATE OPERATOR oracle.* (
  LEFTARG   = numeric,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.numeric_mul_varchar2,
  COMMUTATOR = operator(oracle.*)
);

CREATE OPERATOR oracle.* (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float4,
  PROCEDURE = oracle.varchar2_mul_float4,
  COMMUTATOR = operator(oracle.*)
);

CREATE OPERATOR oracle.* (
  LEFTARG   = float4,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float4_mul_varchar2,
  COMMUTATOR = operator(oracle.*)
);

CREATE OPERATOR oracle.* (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float8,
  PROCEDURE = oracle.varchar2_mul_float8,
  COMMUTATOR = operator(oracle.*)
);

CREATE OPERATOR oracle.* (
  LEFTARG   = float8,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float8_mul_varchar2,
  COMMUTATOR = operator(oracle.*)
);


--div
CREATE OR REPLACE FUNCTION oracle.text_div_numeric(text, numeric)
RETURNS numeric AS $$
SELECT $1::numeric / $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_div_text(numeric, text)
RETURNS numeric AS $$
SELECT $1 / $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_div_float4(text, float4)
RETURNS float4 AS $$
SELECT $1::float4 / $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_div_text(float4, text)
RETURNS float4 AS $$
SELECT $1 / $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.text_div_float8(text, float8)
RETURNS float8 AS $$
SELECT $1::float8 / $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_div_text(float8, text)
RETURNS float8 AS $$
SELECT $1 / $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle./ (
  LEFTARG   = text,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.text_div_numeric
);

CREATE OPERATOR oracle./ (
  LEFTARG   = numeric,
  RIGHTARG  = text,
  PROCEDURE = oracle.numeric_div_text
);

CREATE OPERATOR oracle./ (
  LEFTARG   = text,
  RIGHTARG  = float4,
  PROCEDURE = oracle.text_div_float4
);

CREATE OPERATOR oracle./ (
  LEFTARG   = float4,
  RIGHTARG  = text,
  PROCEDURE = oracle.float4_div_text
);

CREATE OPERATOR oracle./ (
  LEFTARG   = text,
  RIGHTARG  = float8,
  PROCEDURE = oracle.text_div_float8
);

CREATE OPERATOR oracle./ (
  LEFTARG   = float8,
  RIGHTARG  = text,
  PROCEDURE = oracle.float8_div_text
);

CREATE OR REPLACE FUNCTION oracle.varchar2_div_numeric(oracle.varchar2, numeric)
RETURNS numeric AS $$
SELECT $1::numeric / $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.numeric_div_varchar2(numeric, oracle.varchar2)
RETURNS numeric AS $$
SELECT $1 / $2::numeric;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_div_float4(oracle.varchar2, float4)
RETURNS float4 AS $$
SELECT $1::float4 / $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float4_div_varchar2(float4, oracle.varchar2)
RETURNS float4 AS $$
SELECT $1 / $2::float4;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.varchar2_div_float8(oracle.varchar2, float8)
RETURNS float8 AS $$
SELECT $1::float8 / $2;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OR REPLACE FUNCTION oracle.float8_div_varchar2(float8, oracle.varchar2)
RETURNS float8 AS $$
SELECT $1 / $2::float8;
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE OPERATOR oracle./ (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = numeric,
  PROCEDURE = oracle.varchar2_div_numeric
);

CREATE OPERATOR oracle./ (
  LEFTARG   = numeric,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.numeric_div_varchar2
);

CREATE OPERATOR oracle./ (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float4,
  PROCEDURE = oracle.varchar2_div_float4
);

CREATE OPERATOR oracle./ (
  LEFTARG   = float4,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float4_div_varchar2
);

CREATE OPERATOR oracle./ (
  LEFTARG   = oracle.varchar2,
  RIGHTARG  = float8,
  PROCEDURE = oracle.varchar2_div_float8
);

CREATE OPERATOR oracle./ (
  LEFTARG   = float8,
  RIGHTARG  = oracle.varchar2,
  PROCEDURE = oracle.float8_div_varchar2
);


---------------------------------------------
--compatible oracle view
set compatible_db to oracle ;

----------------------------------------------------------------------------------------
--	user_tables
CREATE OR REPLACE VIEW oracle.all_tables(
		  OWNER
		, TABLE_NAME
		, TABLESPACE_NAME
		, CLUSTER_NAME
		, IOT_NAME
		, STATUS
		, PCT_FREE
		, PCT_USED
		, INI_TRANS
		, MAX_TRANS
		, INITIAL_EXTENT
		, NEXT_EXTENT
		, MIN_EXTENTS
		, MAX_EXTENTS
		, PCT_INCREASE
		, FREELISTS
		, FREELIST_GROUPS
		, LOGGING
		, BACKED_UP
		, NUM_ROWS
		, BLOCKS
		, EMPTY_BLOCKS
		, AVG_SPACE
		, CHAIN_CNT
		, AVG_ROW_LEN
		, AVG_SPACE_FREELIST_BLOCKS
		, NUM_FREELIST_BLOCKS
		, DEGREE
		, INSTANCES
		, CACHE
		, TABLE_LOCK
		, SAMPLE_SIZE
		, LAST_ANALYZED
		, PARTITIONED
		, IOT_TYPE
		, TEMPORARY
		, SECONDARY
		, NESTED
		, BUFFER_POOL
		,FLASH_CACHE
		,CELL_FLASH_CACHE
		
		, ROW_MOVEMENT
		, GLOBAL_STATS
		, USER_STATS
		, DURATION
		, SKIP_CORRUPT
		, MONITORING
		, CLUSTER_OWNER
		, DEPENDENCIES
		, COMPRESSION
		,COMPRESS_FOR
		
		,DROPPED				
		,READ_ONLY				
		,SEGMENT_CREATED		
		,RESULT_CACHE			
		,CLUSTERING 			
		,ACTIVITY_TRACKING		
		,DML_TIMESTAMP			
		,HAS_IDENTITY			
		,CONTAINER_DATA 		
		,INMEMORY				
		,INMEMORY_PRIORITY		
		,INMEMORY_DISTRIBUTE	
		,INMEMORY_COMPRESSION	
		,INMEMORY_DUPLICATE 	
		,DEFAULT_COLLATION		
		,DUPLICATED 			
		,SHARDED				
		,EXTERNAL				
		,HYBRID 				
		,CELLMEMORY 			
		,CONTAINERS_DEFAULT 	
		,CONTAINER_MAP			
		,EXTENDED_DATA_LINK 	
		,EXTENDED_DATA_LINK_MAP 
		,INMEMORY_SERVICE		
		,INMEMORY_SERVICE_NAME	
		,CONTAINER_MAP_OBJECT	
		,MEMOPTIMIZE_READ		
		,MEMOPTIMIZE_WRITE		
		,HAS_SENSITIVE_COLUMN	
		,ADMIT_NULL 			
		,DATA_LINK_DML_ENABLED	
		,LOGICAL_REPLICATION	
		
		)
AS
SELECT DISTINCT CAST(pg_GET_USERBYID(c.relowner) AS VARCHAR2(128 ))
		, CAST(relname AS VARCHAR2(128 ))
		, CAST(CASE WHEN c.relkind = 'r' THEN (case reltablespace when 0 then 'database default tablespace' else ts.spcname end) ELSE NULL END AS VARCHAR2(30 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('valid' AS VARCHAR2(8 ))
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 50 END	AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 50 END	AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 'yes' END  AS VARCHAR2(3 ))
		, CAST('N' AS VARCHAR2(1))
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST('DEFAULT' AS VARCHAR2(10 ))
		, CAST('DEFAULT' AS VARCHAR2(10 ))
		, CAST('N' AS VARCHAR2(5 ))
		, CAST('ENABLED' AS VARCHAR2(8 ))
		, CAST(0 AS numeric)
		, CAST(NULL AS DATE)
		, CAST('yes' AS VARCHAR2(3 ))
		, CAST(NULL AS VARCHAR2(12 ))
		, CAST((CASE WHEN c.relpersistence = 't' THEN 'Y' ELSE 'N' END)AS VARCHAR2(1))
		, CAST('N' AS VARCHAR2(1))
		, CAST('no' AS VARCHAR2(3 ))
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 'DEFAULT' END AS VARCHAR2(7 ))
		, CAST('DEFAULT' AS VARCHAR2(7 ))
		, CAST('DEFAULT' AS VARCHAR2(7 ))
		, CAST('DISABLED' AS VARCHAR2(8 ))
		, CAST('yes' AS VARCHAR2(3 ))
		, CAST('yes' AS VARCHAR2(3 ))
		, CAST(
			(CASE WHEN c.relpersistence = 't' THEN
			  (CASE (array_to_string(c.reloptions, ', ') ilike '%oncommit=1%')
				WHEN true THEN 'SYS$SESSION'
				ELSE 'SYS$TRANSACTION'
				END)
			  ELSE ' '
			  END
			)AS VARCHAR2(15 ))
		, CAST('DISABLED' AS VARCHAR2(8 ))
		, CAST('yes' AS VARCHAR2(3 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('DISABLED' AS VARCHAR2(8 ))
		, CAST('DISABLED' AS VARCHAR2(8 ))
		, CAST(NULL AS VARCHAR2(30 ))
		, CAST('no' AS VARCHAR2(3 ))
		,CAST('NO' AS VARCHAR2(3))
		,CAST('NO' AS VARCHAR2(3))
		,CAST('DEFAULT' AS VARCHAR2(7))
		,CAST('no' AS VARCHAR2(3))
		,CAST(NULL AS VARCHAR2(23))
		,CAST(NULL AS VARCHAR2(25))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST(NULL AS VARCHAR2(8))
		,CAST(NULL AS VARCHAR2(8))
		,CAST(NULL AS VARCHAR2(15))
		,CAST(NULL AS VARCHAR2(17))
		,CAST(NULL AS VARCHAR2(13))
		,CAST(NULL AS VARCHAR2(100))
		,CAST('N' AS VARCHAR2(1))
		,CAST('N' AS VARCHAR2(1))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST(NULL AS VARCHAR2(24))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST(NULL AS VARCHAR2(3))
		,CAST('DEFAULT' AS VARCHAR2(12))
		,CAST(NULL AS VARCHAR2(1000))
		,CAST('no' AS VARCHAR2(3))
		,CAST('DISABLED' AS VARCHAR2(8))
		,CAST(NULL AS VARCHAR2(8))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST('DISABLED' AS VARCHAR2(8))
	FROM pg_class c left join pg_index i on c.oid = i.indrelid, pg_tablespace ts,
	pg_authid a
	WHERE (relkind = 'r' or relkind = 'p') 
		AND (c.reltablespace=ts.oid or c.reltablespace = 0)
		AND c.RELNAMESPACE != pg_my_temp_schema()
		and ((c.relowner=a.oid and a.rolname=current_user )
			OR has_table_privilege(c.oid, 'SELECT')
			OR has_table_privilege(c.oid, 'INSERT')
			OR has_table_privilege(c.oid, 'UPDATE')
			OR has_table_privilege(c.oid, 'DELETE')
			OR has_table_privilege(c.oid, 'REFERENCES')
			OR has_table_privilege(c.oid, 'TRIGGER')
			OR has_table_privilege(c.oid, 'SELECT WITH GRANT OPTION')
	  OR has_table_privilege(c.oid, 'INSERT WITH GRANT OPTION')
	  OR has_table_privilege(c.oid, 'UPDATE WITH GRANT OPTION')
	  OR has_table_privilege(c.oid, 'DELETE WITH GRANT OPTION')
	  OR has_table_privilege(c.oid, 'REFERENCES WITH GRANT OPTION')
	  OR has_table_privilege(c.oid, 'TRIGGER WITH GRANT OPTION')
	  OR has_table_privilege(c.oid, 'TRUNCATE WITH GRANT OPTION')
	  OR has_table_privilege(c.oid, 'RULE WITH GRANT OPTION')
	  )
;

REVOKE ALL ON oracle.all_tables FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.all_tables TO PUBLIC;

-------------
CREATE OR REPLACE VIEW oracle.dba_tables(OWNER
		, TABLE_NAME
		, TABLESPACE_NAME
		, CLUSTER_NAME
		, IOT_NAME
		, STATUS
		, PCT_FREE
		, PCT_USED
		, INI_TRANS
		, MAX_TRANS
		, INITIAL_EXTENT
		, NEXT_EXTENT
		, MIN_EXTENTS
		, MAX_EXTENTS
		, PCT_INCREASE
		, FREELISTS
		, FREELIST_GROUPS
		, LOGGING
		, BACKED_UP
		, NUM_ROWS
		, BLOCKS
		, EMPTY_BLOCKS
		, AVG_SPACE
		, CHAIN_CNT
		, AVG_ROW_LEN
		, AVG_SPACE_FREELIST_BLOCKS
		, NUM_FREELIST_BLOCKS
		, DEGREE
		, INSTANCES
		, CACHE
		, TABLE_LOCK
		, SAMPLE_SIZE
		, LAST_ANALYZED
		, PARTITIONED
		, IOT_TYPE
		, TEMPORARY
		, SECONDARY
		, NESTED
		, BUFFER_POOL
		,FLASH_CACHE
		,CELL_FLASH_CACHE
		
		, ROW_MOVEMENT
		, GLOBAL_STATS
		, USER_STATS
		, DURATION
		, SKIP_CORRUPT
		, MONITORING
		, CLUSTER_OWNER
		, DEPENDENCIES
		, COMPRESSION
		,COMPRESS_FOR
		
		,DROPPED				
		,READ_ONLY				
		,SEGMENT_CREATED		
		,RESULT_CACHE			
		,CLUSTERING 			
		,ACTIVITY_TRACKING		
		,DML_TIMESTAMP			
		,HAS_IDENTITY			
		,CONTAINER_DATA 		
		,INMEMORY				
		,INMEMORY_PRIORITY		
		,INMEMORY_DISTRIBUTE	
		,INMEMORY_COMPRESSION	
		,INMEMORY_DUPLICATE 	
		,DEFAULT_COLLATION		
		,DUPLICATED 			
		,SHARDED				
		,EXTERNAL				
		,HYBRID 				
		,CELLMEMORY 			
		,CONTAINERS_DEFAULT 	
		,CONTAINER_MAP			
		,EXTENDED_DATA_LINK 	
		,EXTENDED_DATA_LINK_MAP 
		,INMEMORY_SERVICE		
		,INMEMORY_SERVICE_NAME	
		,CONTAINER_MAP_OBJECT	
		,MEMOPTIMIZE_READ		
		,MEMOPTIMIZE_WRITE		
		,HAS_SENSITIVE_COLUMN	
		,ADMIT_NULL 			
		,DATA_LINK_DML_ENABLED	
		,LOGICAL_REPLICATION	
		
		)
AS
SELECT DISTINCT CAST(pg_GET_USERBYID(c.relowner) AS VARCHAR2(128 ))
		, CAST(relname AS VARCHAR2(128 ))
		, CAST(CASE WHEN c.relkind = 'r' THEN (case reltablespace when 0 then 'database default tablespace' else ts.spcname end) ELSE NULL END AS VARCHAR2(30 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('valid' AS VARCHAR2(8 ))
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 50 END	AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 50 END	AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 0 END  AS numeric)
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 'yes' END  AS VARCHAR2(3 ))
		, CAST('N' AS VARCHAR2(1))
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST(0 AS numeric)
		, CAST('DEFAULT' AS VARCHAR2(10 ))
		, CAST('DEFAULT' AS VARCHAR2(10 ))
		, CAST('N' AS VARCHAR2(5 ))
		, CAST('ENABLED' AS VARCHAR2(8 ))
		, CAST(0 AS numeric)
		, CAST(NULL AS DATE)
		, CAST('yes' AS VARCHAR2(3 ))
		, CAST(NULL AS VARCHAR2(12 ))
		, CAST((CASE WHEN c.relpersistence = 't' THEN 'Y' ELSE 'N' END)AS VARCHAR2(1))
		, CAST('N' AS VARCHAR2(1))
		, CAST('no' AS VARCHAR2(3 ))
		, CAST(CASE WHEN c.relkind = 'p' THEN NULL ELSE 'DEFAULT' END AS VARCHAR2(7 ))
		, CAST('DEFAULT' AS VARCHAR2(7 ))
		, CAST('DEFAULT' AS VARCHAR2(7 ))
		, CAST('DISABLED' AS VARCHAR2(8 ))
		, CAST('yes' AS VARCHAR2(3 ))
		, CAST('yes' AS VARCHAR2(3 ))
		, CAST(
			(CASE WHEN c.relpersistence = 't' THEN
			  (CASE (array_to_string(c.reloptions, ', ') ilike '%oncommit=1%')
				WHEN true THEN 'SYS$SESSION'
				ELSE 'SYS$TRANSACTION'
				END)
			  ELSE ' '
			  END
			)AS VARCHAR2(15 ))
		, CAST('DISABLED' AS VARCHAR2(8 ))
		, CAST('yes' AS VARCHAR2(3 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('DISABLED' AS VARCHAR2(8 ))
		, CAST('DISABLED' AS VARCHAR2(8 ))
		, CAST(NULL AS VARCHAR2(30 ))
		, CAST('no' AS VARCHAR2(3 ))
		,CAST('NO' AS VARCHAR2(3))
		,CAST('NO' AS VARCHAR2(3))
		,CAST('DEFAULT' AS VARCHAR2(7))
		,CAST('no' AS VARCHAR2(3))
		,CAST(NULL AS VARCHAR2(23))
		,CAST(NULL AS VARCHAR2(25))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST(NULL AS VARCHAR2(8))
		,CAST(NULL AS VARCHAR2(8))
		,CAST(NULL AS VARCHAR2(15))
		,CAST(NULL AS VARCHAR2(17))
		,CAST(NULL AS VARCHAR2(13))
		,CAST(NULL AS VARCHAR2(100))
		,CAST('N' AS VARCHAR2(1))
		,CAST('N' AS VARCHAR2(1))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST(NULL AS VARCHAR2(24))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST(NULL AS VARCHAR2(3))
		,CAST('DEFAULT' AS VARCHAR2(12))
		,CAST(NULL AS VARCHAR2(1000))
		,CAST('no' AS VARCHAR2(3))
		,CAST('DISABLED' AS VARCHAR2(8))
		,CAST(NULL AS VARCHAR2(8))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST('no' AS VARCHAR2(3))
		,CAST('DISABLED' AS VARCHAR2(8))
	FROM pg_class c left join pg_index i on c.oid = i.indrelid, pg_tablespace ts,
	pg_authid a
	WHERE (relkind = 'r' or relkind = 'p') 
		AND (c.reltablespace=ts.oid or c.reltablespace = 0)
		AND c.RELNAMESPACE != pg_my_temp_schema();


REVOKE ALL ON oracle.dba_tables FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.dba_tables TO PUBLIC;

CREATE OR REPLACE VIEW oracle.user_tables
AS
	SELECT TABLE_NAME
		, TABLESPACE_NAME
		, CLUSTER_NAME
		, IOT_NAME
		, STATUS
		, PCT_FREE
		, PCT_USED
		, INI_TRANS
		, MAX_TRANS
		, INITIAL_EXTENT
		, NEXT_EXTENT
		, MIN_EXTENTS
		, MAX_EXTENTS
		, PCT_INCREASE
		, FREELISTS
		, FREELIST_GROUPS
		, LOGGING
		, BACKED_UP
		, NUM_ROWS
		, BLOCKS
		, EMPTY_BLOCKS
		, AVG_SPACE
		, CHAIN_CNT
		, AVG_ROW_LEN
		, AVG_SPACE_FREELIST_BLOCKS
		, NUM_FREELIST_BLOCKS
		, DEGREE
		, INSTANCES
		, CACHE
		, TABLE_LOCK
		, SAMPLE_SIZE
		, LAST_ANALYZED
		, PARTITIONED
		, IOT_TYPE
		, TEMPORARY
		, SECONDARY
		, NESTED
		, BUFFER_POOL
		,FLASH_CACHE
		,CELL_FLASH_CACHE
		
		, ROW_MOVEMENT
		, GLOBAL_STATS
		, USER_STATS
		, DURATION
		, SKIP_CORRUPT
		, MONITORING
		, CLUSTER_OWNER
		, DEPENDENCIES
		, COMPRESSION
		,COMPRESS_FOR
		, DROPPED
		,READ_ONLY				
		,SEGMENT_CREATED		
		,RESULT_CACHE			
		,CLUSTERING 			
		,ACTIVITY_TRACKING		
		,DML_TIMESTAMP			
		,HAS_IDENTITY			
		,CONTAINER_DATA 		
		,INMEMORY				
		,INMEMORY_PRIORITY		
		,INMEMORY_DISTRIBUTE	
		,INMEMORY_COMPRESSION	
		,INMEMORY_DUPLICATE 	
		,DEFAULT_COLLATION		
		,DUPLICATED 			
		,SHARDED				
		,EXTERNAL				
		,HYBRID 				
		,CELLMEMORY 			
		,CONTAINERS_DEFAULT 	
		,CONTAINER_MAP			
		,EXTENDED_DATA_LINK 	
		,EXTENDED_DATA_LINK_MAP 
		,INMEMORY_SERVICE		
		,INMEMORY_SERVICE_NAME	
		,CONTAINER_MAP_OBJECT	
		,MEMOPTIMIZE_READ		
		,MEMOPTIMIZE_WRITE		
		,HAS_SENSITIVE_COLUMN	
		,ADMIT_NULL 			
		,DATA_LINK_DML_ENABLED	
		,LOGICAL_REPLICATION	
		
	FROM dba_tables
		WHERE owner = CAST(current_user AS VARCHAR2(128))
;

REVOKE ALL ON oracle.user_tables FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_tables TO PUBLIC;
----------------------------------------------------------------------------------------
--	user_tab_partitions
CREATE OR REPLACE FUNCTION get_partition_root(rootrelid regclass)
	RETURNS regclass
	AS 'SELECT DISTINCT pg_partition_root FROM pg_partition_root(rootrelid)'
	LANGUAGE SQL IMMUTABLE;

CREATE OR REPLACE VIEW oracle.user_tab_partitions AS
	SELECT
		get_partition_root(c.relname::regclass)::varchar2(128) AS TABLE_NAME,
		(
			CASE WHEN (SELECT max(level) FROM pg_partition_tree(get_partition_root(h.inhparent::regclass))) > 1 THEN 'yes'
			ELSE 'no' END
		)::varchar2(3) AS COMPOSITE,
		h.inhrelid::regclass::varchar2(128) AS PARTITION_NAME,
		(
			SELECT count(1) FROM pg_partition_tree(c.relname::regclass)
				WHERE isleaf = 't' AND (SELECT max(level) FROM pg_partition_tree(get_partition_root(h.inhparent::regclass))) > 1
		)::numeric AS SUBPARTITION_COUNT,
		get_partition_uppervalue(h.inhrelid)::text AS HIGH_VALUE,
		(
			CASE WHEN length(get_partition_uppervalue(h.inhrelid)) IS NULL THEN 0
			ELSE length(get_partition_uppervalue(h.inhrelid)) END
		)::numeric AS HIGH_VALUE_LENGTH,
		row_number()over(PARTITION BY get_partition_root(c.relname::regclass) ORDER BY h.inhrelid::regclass)::numeric AS PARTITION_POSITION,
		(
			CASE WHEN (SELECT reltablespace FROM pg_catalog.pg_class WHERE oid = h.inhrelid) != 0 THEN
				(
					SELECT spcname FROM pg_catalog.pg_tablespace
						WHERE oid = (SELECT reltablespace FROM pg_catalog.pg_class WHERE oid = h.inhrelid)
				)
			ELSE
				(
					CASE WHEN t.spcname IS NULL THEN 'default'
					ELSE t.spcname END
				)
			END
		)::varchar2(30) AS TABLESPACE_NAME,
		0::numeric AS PCT_FREE,
		0::numeric AS PCT_USED,
		0::numeric AS INI_TRANS,
		0::numeric AS MAX_TRANS,
		NULL::numeric AS INITIAL_EXTENT,
		NULL::numeric AS NEXT_EXTENT,
		NULL::numeric AS MIN_EXTENT,
		NULL::numeric AS MAX_EXTENT,
		NULL::numeric AS MAX_SIZE,
		NULL::numeric AS PCT_INCREASE,
		NULL::numeric AS FREELISTS,
		NULL::numeric AS FREELIST_GROUPS,
		'none'::varchar2(7) AS LOGGING,
		'none'::varchar2(8) AS COMPRESSION,
		NULL::varchar2(30) AS COMPRESS_FOR,
		c.reltuples::numeric AS NUM_ROWS,
		c.relpages::numeric AS BLOCKS,
		NULL::numeric AS EMPTY_BLOCKS,
		NULL::numeric AS AVG_SPACE,
		NULL::numeric AS CHAIN_CNT,
		NULL::numeric AS AVG_ROW_LEN,
		NULL::numeric AS SAMPLE_SIZE,
		NULL::date AS LAST_ANALYZED,
		NULL::varchar2(7) AS BUFFER_POOL,
		NULL::varchar2(7) AS FLASH_CACHE,
		NULL::varchar2(7) AS CELL_FLASH_CACHE,
		'yes'::varchar2(3) AS GLOBAL_STATS,
		'no'::varchar2(3) AS USER_STATS,
		'no'::varchar2(3) AS IS_NESTED,
		'NULL'::varchar2(128) AS PARENT_TABLE_PARTITION,
		'no'::varchar2(3) AS INTERVAL,
		'none'::varchar2(4) AS SEGMENT_CREATED,
		'on'::varchar2(4) AS INDEXING,
		'no'::varchar2(4) AS READ_ONLY,
		'disabled'::varchar2(8) AS INMEMORY,
		NULL::varchar2(8) AS INMEMORY_PRIORITY,
		NULL::varchar2(15) AS INMEMORY_DISTRIBUTE,
		NULL::varchar2(17) AS INMEMORY_COMPRESSION,
		NULL::varchar2(13) AS INMEMORY_DUPLICATE,
		NULL::varchar2(24) AS CELLMEMORY,
		NULL::varchar2(12) AS INMEMORY_SERVICE,
		NULL::varchar2(100) AS INMEMORY_SERVICE_NAME,
		'disabled'::varchar2(8) AS MEMOPTIMIZE_READ,
		'disabled'::varchar2(8) AS MEMOPTIMIZE_WRITE
	FROM
		(pg_catalog.pg_class c INNER JOIN pg_catalog.pg_inherits h ON
								h.inhparent = c.oid AND
								(c.relkind = 'p' OR
								c.relispartition = 't')
		)
		LEFT JOIN pg_catalog.pg_tablespace t ON
								t.oid = reltablespace
	ORDER BY h.inhparent;

REVOKE ALL ON oracle.user_tab_partitions FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_tab_partitions TO PUBLIC;

----------------------------------------------------------------------------------------
--	user_tab_columns   
create or replace function get_type_name(TYPNAME name) 
returns TEXT as $$	
declare
	tmp TEXT;
begin
	SELECT (CASE $1
	   WHEN 'BPCHAR' THEN 'CHAR'
	 ELSE
	   $1
	 END
	)::TEXT into tmp FROM dual;
	return tmp;
end;$$language plpgsql;


create or replace function get_type_length(ATTLEN smallint , ATTTYPMOD integer, TYPNAME name) 
returns numeric as $$	
declare
	tmp numeric;
begin
	SELECT	
	(CASE WHEN $1 = -1 THEN
		(
			CASE $3 WHEN 'BIT' THEN (CASE($2 >> 16) WHEN 0 THEN ($2 - (($2 >> 16) <<16)) ELSE 0 END)
				WHEN 'BIT VARYING' THEN (CASE($2 >> 16) WHEN 0 THEN ($2 - (($2 >> 16) <<16)) ELSE 0 END)
				WHEN 'TIMETZ' THEN (CASE($2 >> 16) WHEN 0 THEN ($2 - (($2 >> 16) <<16)) ELSE 0 END)
				WHEN 'TIME' THEN (CASE($2 >> 16) WHEN 0 THEN ($2 - (($2 >> 16) <<16)) ELSE 0 END)
				WHEN 'TIMESTAMPTZ' THEN (CASE($2 >> 16) WHEN 0 THEN ($2 - (($2 >> 16) <<16)) ELSE 0 END)
				WHEN 'TIMESTAMP' THEN (CASE($2 >> 16) WHEN 0 THEN ($2 - (($2 >> 16) <<16)) ELSE 0 END)
				WHEN 'INTERVAL' THEN (CASE($2 >> 16) WHEN 0 THEN ($2 - (($2 >> 16) <<16)) ELSE 0 END)
				WHEN 'VARBIT' THEN (CASE($2 >> 16) WHEN 0 THEN ($2 - (($2 >> 16) <<16)) ELSE 0 END)
				WHEN 'VARCHAR' THEN (CASE $2 WHEN -1 THEN NULL ELSE ABS($2) - 4 END)
				WHEN 'BPCHAR' THEN (CASE $2 WHEN -1 THEN NULL ELSE ABS($2) - 4 END)
				ELSE (CASE($2 >> 16) WHEN 0 THEN ($2 - (($2 >> 16) <<16)-4) ELSE 0 END)
			END
		)
		ELSE
			$1
		END
	)::numeric into tmp FROM dual;
	return tmp;
end;$$language plpgsql;
 
CREATE OR REPLACE VIEW oracle.USER_TAB_COLS AS
	SELECT
	C.RELNAME ::VARCHAR2(128 ) AS TABLE_NAME,
	ATTR.ATTNAME ::VARCHAR2(128 ) AS COLUMN_NAME,
	(
	  CASE T.TYPNAME
		WHEN 'BPCHAR' THEN 'CHAR'
	  ELSE
		T.TYPNAME
	  END
	)::VARCHAR2(128 ) AS DATA_TYPE,
	NULL ::VARCHAR2(3 ) AS DATA_TYPE_MOD,
	AU.ROLNAME ::VARCHAR2(128) AS DATA_TYPE_OWNER,
	(
		CASE WHEN ATTR.ATTLEN = -1 THEN
		(
			CASE T.TYPNAME WHEN 'BIT' THEN (CASE(ATTR.ATTTYPMOD >> 16) WHEN 0 THEN (ATTR.ATTTYPMOD - ((ATTR.ATTTYPMOD >> 16) <<16)) ELSE 0 END)
				WHEN 'BIT VARYING' THEN (CASE(ATTR.ATTTYPMOD >> 16) WHEN 0 THEN (ATTR.ATTTYPMOD - ((ATTR.ATTTYPMOD >> 16) <<16)) ELSE 0 END)
				WHEN 'TIMETZ' THEN (CASE(ATTR.ATTTYPMOD >> 16) WHEN 0 THEN (ATTR.ATTTYPMOD - ((ATTR.ATTTYPMOD >> 16) <<16)) ELSE 0 END)
				WHEN 'TIME' THEN (CASE(ATTR.ATTTYPMOD >> 16) WHEN 0 THEN (ATTR.ATTTYPMOD - ((ATTR.ATTTYPMOD >> 16) <<16)) ELSE 0 END)
				WHEN 'TIMESTAMPTZ' THEN (CASE(ATTR.ATTTYPMOD >> 16) WHEN 0 THEN (ATTR.ATTTYPMOD - ((ATTR.ATTTYPMOD >> 16) <<16)) ELSE 0 END)
				WHEN 'TIMESTAMP' THEN (CASE(ATTR.ATTTYPMOD >> 16) WHEN 0 THEN (ATTR.ATTTYPMOD - ((ATTR.ATTTYPMOD >> 16) <<16)) ELSE 0 END)
				WHEN 'INTERVAL' THEN (CASE(ATTR.ATTTYPMOD >> 16) WHEN 0 THEN (ATTR.ATTTYPMOD - ((ATTR.ATTTYPMOD >> 16) <<16)) ELSE 0 END)
				WHEN 'VARBIT' THEN (CASE(ATTR.ATTTYPMOD >> 16) WHEN 0 THEN (ATTR.ATTTYPMOD - ((ATTR.ATTTYPMOD >> 16) <<16)) ELSE 0 END)
				WHEN 'VARCHAR' THEN (CASE ATTR.ATTTYPMOD WHEN -1 THEN NULL ELSE ABS(ATTR.ATTTYPMOD) - 4 END)
				WHEN 'BPCHAR' THEN (CASE ATTR.ATTTYPMOD WHEN -1 THEN NULL ELSE ABS(ATTR.ATTTYPMOD) - 4 END)
				ELSE (CASE(ATTR.ATTTYPMOD >> 16) WHEN 0 THEN (ATTR.ATTTYPMOD - ((ATTR.ATTTYPMOD >> 16) <<16)-4) ELSE 0 END)
			END
		)
		ELSE
			ATTR.ATTLEN
		END
	  )::numeric AS DATA_LENGTH,
	(
		CASE get_type_name(T.TYPNAME)::TEXT
			WHEN 'NUMERIC' THEN
		(
		  CASE WHEN ATTR.ATTTYPMOD = -1 THEN 38
		  ELSE ((ATTR.ATTTYPMOD - 4) >> 16) & 65535
		  END
		)
			WHEN 'FLOAT4' THEN 7
			WHEN 'FLOAT8' THEN 15
		ELSE
			NULL
		END
	)::numeric AS DATA_PRECISION,
	(
		CASE get_type_name(T.TYPNAME)::TEXT
			WHEN 'NUMERIC' THEN (ATTR.ATTTYPMOD - 4) & 65535
		ELSE
			NULL
		END
	)::numeric AS DATA_SCALE,
	(
		case ATTR.ATTNOTNULL when true then 'N' else 'Y' end
	) ::VARCHAR2(1 ) AS NULLABLE,
	ATTR.ATTNUM ::numeric AS COLUMN_ID,
	(
		CASE ATTR.ATTHASDEF WHEN FALSE THEN NULL
		ELSE get_type_length(ATTR.ATTLEN , ATTR.ATTTYPMOD, T.TYPNAME) 
		END
	) AS DEFAULT_LENGTH,
	--DEF.ADSRC::TEXT AS DATA_DEFAULT,/*-The PG12 version of adsrc is deleted-*/
	NULL::TEXT AS DATA_DEFAULT,
	0 ::numeric AS NUM_DISTINCT,
	0 ::numeric AS LOW_VALUE,
	0 ::numeric AS HIGH_VALUE,
	0 ::numeric AS DENSITY,
	0 ::numeric AS NUM_NULLS,
	0 ::numeric AS NUM_BUCKETS,
	NULL::date AS LAST_ANALYZED,
	0 ::numeric AS SAMPLE_SIZE,
	NULL ::VARCHAR2(44 ) AS CHARACTER_SET_NAME,
	0 ::numeric AS CHAR_COL_DECL_LENGTH,
	'NO' ::VARCHAR2(3 ) AS GLOBAL_STATS,
	'NO' ::VARCHAR2(3 ) AS USER_STATS,
	0 ::numeric AS AVG_COL_LEN,
	(
		CASE get_type_name(T.TYPNAME)::TEXT IN('VARCHAR', 'BPCHAR', 'NCHAR', 'NVARCHAR') 
		    WHEN TRUE THEN get_type_length(ATTR.ATTLEN , ATTR.ATTTYPMOD, T.TYPNAME) 
		ELSE 0
		END
	) :: numeric AS CHAR_LENGTH,
	(
		CASE get_type_name(T.TYPNAME)::TEXT IN ('VARCHAR', 'BPCHAR', 'NCHAR', 'NVARCHAR') 
		    AND ATTR.ATTTYPMOD <> -1 WHEN TRUE THEN
		(
			CASE ATTR.ATTTYPMOD >> 16 WHEN 0 THEN 'C'
			ELSE 'B'
			END
		)
		ELSE
			NULL
		END
	) ::VARCHAR2(1 ) AS CHAR_USED,
	'NO' ::VARCHAR2(3 ) AS V80_FMT_IMAGE,
	'NO' ::VARCHAR2(3 ) AS DATA_UPGRADED,
	'NO' ::VARCHAR2(3 ) AS HIDDEN_COLUMN,
	'NO' ::VARCHAR2(3 ) AS VIRTUAL_COLUMN,
	0 ::numeric AS SEGMENT_COLUMN_ID,
	ATTR.ATTNUM ::numeric AS INTERNAL_COLUMN_ID,
	NULL ::VARCHAR2(15 ) AS HISTOGRAM,
	NULL ::VARCHAR2(4000 ) AS QUALIFIED_COL_NAME,
	'NO' ::VARCHAR2(3 ) AS USER_GENERATED,
	'NO' ::VARCHAR2(3 ) AS DEFAULT_ON_NULL,
	'NO' ::VARCHAR2(3 ) AS IDENTITY_COLUMN,
	NULL ::VARCHAR2(128) AS EVALUATION_EDITION,
	NULL ::VARCHAR2(128) AS UNUSABLE_BEFORE,
	NULL ::VARCHAR2(128) AS UNUSABLE_BEGINNING,
	NULL ::VARCHAR2(100) AS COLLATION1          --Keyword conflict
	FROM pg_USER U,	 pg_CLASS C, pg_TYPE T,pg_AUTHID AU, pg_ATTRIBUTE ATTR 
	  left join pg_ATTRDEF DEF
	  on (ATTR.ATTRELID = DEF.ADRELID and ATTR.ATTNUM = DEF.ADNUM)
	WHERE C.RELOWNER = U.USESYSID
	AND ATTR.ATTNUM > 0
	AND ATTR.ATTTYPID = T.OID
	AND ATTR.ATTRELID = C.OID
	AND T.TYPOWNER = AU.OID;
	
REVOKE ALL ON oracle.USER_TAB_COLS FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.USER_TAB_COLS TO PUBLIC;


create or replace view oracle.USER_TAB_COLUMNS
	(TABLE_NAME, COLUMN_NAME, DATA_TYPE, DATA_TYPE_MOD, DATA_TYPE_OWNER,
	 DATA_LENGTH, DATA_PRECISION, DATA_SCALE, NULLABLE, COLUMN_ID,
	 DEFAULT_LENGTH, DATA_DEFAULT, NUM_DISTINCT, LOW_VALUE, HIGH_VALUE,
	 DENSITY, NUM_NULLS, NUM_BUCKETS, LAST_ANALYZED, SAMPLE_SIZE,
	 CHARACTER_SET_NAME, CHAR_COL_DECL_LENGTH,
	 GLOBAL_STATS, USER_STATS, AVG_COL_LEN, CHAR_LENGTH, CHAR_USED,
	 V80_FMT_IMAGE, DATA_UPGRADED, HISTOGRAM,
	 DEFAULT_ON_NULL,IDENTITY_COLUMN,EVALUATION_EDITION,
	 UNUSABLE_BEFORE,UNUSABLE_BEGINNING,COLLATION1)
as
select TABLE_NAME, COLUMN_NAME, DATA_TYPE, DATA_TYPE_MOD, DATA_TYPE_OWNER,
	   DATA_LENGTH, DATA_PRECISION, DATA_SCALE, NULLABLE, COLUMN_ID,
	   DEFAULT_LENGTH, DATA_DEFAULT, NUM_DISTINCT, LOW_VALUE, HIGH_VALUE,
	   DENSITY, NUM_NULLS, NUM_BUCKETS, LAST_ANALYZED, SAMPLE_SIZE,
	   CHARACTER_SET_NAME, CHAR_COL_DECL_LENGTH,
	   GLOBAL_STATS, USER_STATS, AVG_COL_LEN, CHAR_LENGTH, CHAR_USED,
	   V80_FMT_IMAGE, DATA_UPGRADED, HISTOGRAM,
	   DEFAULT_ON_NULL,IDENTITY_COLUMN,EVALUATION_EDITION,
	   UNUSABLE_BEFORE,UNUSABLE_BEGINNING,COLLATION1
  from USER_TAB_COLS
 where HIDDEN_COLUMN = 'NO';

REVOKE ALL ON oracle.user_tab_columns FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_tab_columns TO PUBLIC;

----------------------------------------------------------------------------------------
-- USER_COL_COMMENTS
create or replace view oracle.all_col_comments as
	select
		cast(a.usename as varchar2(128)) as OWNER,
		cast(c.relname as varchar2(128)) as TABLE_NAME,
		cast(at.ATTNAME as varchar2(128)) AS COLUMN_NAME,
		cast(d.DESCRIPTION as varchar2(4000)) AS COMMENTS,
		cast(NULL AS NUMERIC) AS ORIGIN_CON_ID 
	FROM pg_USER a, pg_CLASS c, pg_ATTRIBUTE at left join pg_DESCRIPTION d on (
		d.classoid = 1259 and d.objoid=at.attrelid and at.attnum=d.objsubid)
		WHERE at.attrelid = c.oid
		  and c.relkind in ('r','v')
		  and at.attnum > 0 and at.attisdropped = false
		  and c.relowner = a.usesysid
		  and a.usename = CAST(CURRENT_USER AS varchar2(128));
	  
REVOKE ALL ON oracle.all_col_comments FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.all_col_comments TO PUBLIC;

create or replace view oracle.user_col_comments as
	select TABLE_NAME,COLUMN_NAME,COMMENTS,ORIGIN_CON_ID FROM oracle.all_col_comments 
	WHERE owner = CAST(current_user AS VARCHAR2(128));
	  
REVOKE ALL ON oracle.user_col_comments FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_col_comments TO PUBLIC;


----------------------------------------------------------------------------------------
--	user_ind_columns   
create or replace view oracle.USER_IND_COLUMNS as
select
	ic.relname::VARCHAR2(128) as INDEX_NAME
	--,pg_get_userbyid(tc.relowner)::VARCHAR2(128) as TABLE_OWNER
	,tc.relname::VARCHAR2(128) as TABLE_NAME
	,a.attname::VARCHAR2(4000 ) as COLUMN_NAME
	,ia.attnum as COLUMN_POSITION
	,(
		case when a.attlen = -1 then
		(
			--atttypmod < 0 means its in bytes.
			case t.typname
				when 'BIT'			then (case (a.atttypmod >> 16)!=0 when true then abs(a.atttypmod) else 0 end)
				when 'BIT VARYING'	then (case (a.atttypmod >> 16)!=0 when true then abs(a.atttypmod) else 0 end)
				when 'TIMETZ'		then (case (a.atttypmod >> 16)!=0 when true then abs(a.atttypmod) else 0 end)
				when 'TIME' 		then (case (a.atttypmod >> 16)!=0 when true then abs(a.atttypmod) else 0 end)
				when 'TIMESTAMPTZ'	then (case (a.atttypmod >> 16)!=0 when true then abs(a.atttypmod) else 0 end)
				when 'TIMESTAMP'	then (case (a.atttypmod >> 16)!=0 when true then abs(a.atttypmod) else 0 end)
				when 'INTERVAL' 	then (case (a.atttypmod >> 16)=0 when true then abs(a.atttypmod) else 0 end)
				when 'VARBIT'		then (case (a.atttypmod >> 16)=0 when true then abs(a.atttypmod) else 0 end)
				/* pg_class.relkeyid and pg_attribute.attkeyid all make a.atttypmod = -1, but they are not strings. */
				when 'VARCHAR'		then ( case a.atttypmod = -1 when true then null else (case (a.atttypmod >> 16)=0 when true then null else abs(a.atttypmod)-4 end) end)
				when 'BPCHAR'		then (case a.atttypmod = -1 when true then null else (case(a.atttypmod >> 16)=0 when true then null else abs(a.atttypmod)-4 end) end)
				else (case (a.atttypmod >> 16)=0 when true then a.atttypmod-4 else 0 end)
			end
		)
		else	a.attlen end )::numeric AS COLUMN_LENGTH --Maximum length of column in bytes.
	,(
		case when a.attlen = -1 then
		(
			case T.typname
				when 'VARCHAR'	then (case(a.atttypmod>>16)=0 when true then a.atttypmod - 4 else null end)
				when 'BPCHAR'	then (case(a.atttypmod>>16)=0 when true then a.atttypmod - 4 else null end)
			end
		) else 0 end )::numeric AS CHAR_LENGTH --Maximum length of column in chars. This column will show strings in characters only.
	,(case (i.indoption[ia.attnum-1]&'01')=0 when true then 'ASC' else 'DESC' end)::VARCHAR2(4 ) as DESCEND
	,NULL ::numeric AS COLLATED_COLUMN_ID
from
	pg_index i,
	pg_class tc,	/* table in pg_class */
	pg_class ic,	/* index in pg_class */
	pg_attribute a,/* attribute of column */
	pg_type t,
	pg_attribute ia/* index's column: the columns in indexes will be shown in this table too. */
where
	(i.indrelid = a.attrelid and a.attnum = any(i.indkey))
	and i.indrelid = tc.oid -- table's oid
	and i.indexrelid = ic.oid -- index's oid
	and ia.attrelid = i.indexrelid
	and ia.attname = a.attname
	and ic.relowner = (select oid from pg_authid where rolname = (select current_user) )
	and a.atttypid = t.oid
;

REVOKE ALL ON oracle.user_ind_columns FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_ind_columns TO PUBLIC;

----------------------------------------------------------------------------------------
--	user_indexes
CREATE OR REPLACE  VIEW oracle.USER_INDEXES AS
	SELECT C.RELNAME ::VARCHAR2(128) AS INDEX_NAME,
	A.AMNAME ::VARCHAR2(27) AS INDEX_TYPE,
	pg_GET_USERBYID(c.RELOWNER) ::VARCHAR2(128) AS TABLE_OWNER,
	(SELECT RELNAME FROM pg_CLASS WHERE  OID = INDRELID )::VARCHAR2(128) AS TABLE_NAME,
	'TABLE'::TEXT AS TABLE_TYPE,
	(case I.INDISUNIQUE or I.INDISPRIMARY when true then 'UNIQUE' 
	 else 'NONUNIQUE' end)::VARCHAR2(9) AS UNIQUENESS,
	'DISABLED'::VARCHAR2(13)  AS COMPRESSION,
	0 ::numeric AS PREFIX_LENGTH,
	(case c.reltablespace when 0 then 'database default tablespace' 
	 else ( SELECT SPCNAME FROM pg_TABLESPACE WHERE OID = C.RELTABLESPACE) end)::VARCHAR2(30) AS TABLESPACE_NAME,
	NULL::numeric AS INI_TRANS,
	NULL::numeric AS MAX_TRANS,
	NULL::numeric AS INITIAL_EXTENT,
	NULL::numeric AS NEXT_EXTENT,
	NULL::numeric AS MIN_EXTENTS,
	NULL::numeric AS MAX_EXTENTS,
	NULL::numeric AS PCT_INCREASE,
	NULL::numeric AS PCT_THRESHOLD,
	NULL::numeric AS INCLUDE_COLUMN,
	NULL::numeric AS FREELISTS,
	NULL::numeric AS FREELIST_GROUPS,
	NULL::numeric AS PCT_FREE,
	NULL::VARCHAR2(3) AS LOGGING,
	NULL::numeric AS BLEVEL,
	NULL::numeric AS LEAF_BLOCKS,
	NULL::numeric AS DISTINCT_KEYS,
	NULL::numeric AS AVG_LEAF_BLOCKS_PER_KEY,
	NULL::numeric AS AVG_DATA_BLOCKS_PER_KEY,
	NULL::numeric AS CLUSTERING_FACTOR,
	NULL::VARCHAR2(8) AS STATUS,
	NULL::numeric AS NUM_ROWS,
	NULL::numeric AS SAMPLE_SIZE,
	NULL::DATE AS LAST_ANALYZED,
	NULL::VARCHAR2(40) AS DEGREE,
	NULL::VARCHAR2(40)AS INSTANCES,
	NULL::VARCHAR2(3) AS PARTITIONED,
	NULL::VARCHAR2(1) AS TEMPORARY,
	NULL::VARCHAR2(1) AS GENERATED,
	NULL::VARCHAR2(1) AS SECONDARY,
	'DEFAULT'::VARCHAR2(7) AS BUFFER_POOL,
	'DEFAULT'::VARCHAR2(7) AS FLASH_CACHE,
	'DEFAULT'::VARCHAR2(7) AS CELL_FLASH_CACHE,
	NULL::VARCHAR2(3) AS USER_STATS,
	NULL::VARCHAR2(15) AS DURATION,
	NULL::VARCHAR2(7) AS PCT_DIRECT_ACCESS,
	NULL::VARCHAR2(128) AS ITYP_OWNER,
	NULL::VARCHAR2(128) AS ITYP_NAME,
	NULL::VARCHAR2(1000) AS PARAMETERS,
	NULL::VARCHAR2(3) AS GLOBAL_STATS,
	NULL::VARCHAR2(12) AS DOMIDX_STATUS,
	NULL::VARCHAR2(6) AS DOMIDX_OPSTATUS,
	NULL::VARCHAR2(8) AS FUNCIDX_STATUS,
	'NO'::VARCHAR2(3) AS JOIN_INDEX,
	'NO'::VARCHAR2(3) AS IOT_REDUNDANT_PKEY_ELIM,
	'NO'::VARCHAR2(3) AS DROPPED,
	'VISIBLE'::VARCHAR2(9) AS VISIBILITY,
	NULL::VARCHAR2(14) AS DOMIDX_MANAGEMENT,
	'NO'::VARCHAR2(3) AS SEGMENT_CREATED,
	'NO'::VARCHAR2(3) AS ORPHANED_ENTRIES,
	'FULL'::VARCHAR2(7) AS INDEXING,
	'NO'::VARCHAR2(3) AS AUTO
	
	FROM  pg_INDEX I, pg_CLASS C,pg_AM A
	WHERE
	C.RELOWNER = (select oid from pg_authid where rolname = (select current_user) )
	--AND I.INDRELID = c.OID
	AND I.INDEXRELID = C.OID
	AND A.OID = C.RELAM;

REVOKE ALL ON oracle.USER_INDEXES FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.USER_INDEXES TO PUBLIC;


---------------------------------------------------------------------------------------
--	user_part_key_columns
create or replace view oracle.user_part_key_columns as(
select distinct(a.relname)::varchar2(128) as NAME,
		(case when a.relkind = 'p' then 'table' else 'index' end )::char(5) as OBJECT_TYPE,
		keyname::varchar2(4000) as COLUMN_NAME,
		(select attnum from pg_attribute where attrelid = a.oid and keyname = attname)::numeric as COLUMN_POSITION, 
		null::numeric as COLLATED_COLUMN_ID
			from pg_catalog.pg_class a ,pg_catalog.pg_attribute b ,unnest(string_to_array(pg_catalog.pg_get_partkeydef_col(a.oid),',')) as keyname
				where a.oid = b.attrelid 
				and  b.attnum > 0 
				and  a.relkind = 'p' or a.relkind = 'i' 
				and (SELECT pg_catalog.pg_get_partkeydef(a.oid::pg_catalog.oid)) is not null);

REVOKE ALL ON oracle.user_part_key_columns FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_part_key_columns TO PUBLIC;

----------------------------------------------------------------------------------------
--	user_part_tables
CREATE VIEW oracle.USER_PART_TABLES(TABLE_NAME
		,PARTITIONING_TYPE
		,SUBPARTITIONING_TYPE
		,PARTITION_COUNT
		,DEF_SUBPARTITION_COUNT
		,PARTITIONING_KEY_COUNT
		,SUBPARTITIONING_KEY_COUNT
		,STATUS
		,DEF_TABLESPACE_NAME
		,DEF_PCT_FREE
        ,DEF_PCT_USED
        ,DEF_INI_TRANS
        ,DEF_MAX_TRANS
        ,DEF_INITIAL_EXTENT
        ,DEF_NEXT_EXTENT
        ,DEF_MIN_EXTENTS
        ,DEF_MAX_EXTENTS
        ,DEF_MAX_SIZE
        ,DEF_PCT_INCREASE
        ,DEF_FREELISTS
        ,DEF_FREELIST_GROUPS
        ,DEF_LOGGING
        ,DEF_COMPRESSION
        ,DEF_COMPRESS_FOR
        ,DEF_BUFFER_POOL
        ,DEF_FLASH_CACHE
        ,DEF_CELL_FLASH_CACHE
        ,REF_PTN_CONSTRAINT_NAME
        ,INTERVAL
        ,AUTOLIST
        ,INTERVAL_SUBPARTITION
        ,AUTOLIST_SUBPARTITION
        ,IS_NESTED
        ,DEF_SEGMENT_CREATION
        ,DEF_INDEXING
        ,DEF_INMEMORY
        ,DEF_INMEMORY_PRIORITY
        ,DEF_INMEMORY_DISTRIBUTE
        ,DEF_INMEMORY_COMPRESSION
        ,DEF_INMEMORY_DUPLICATE
        ,DEF_READ_ONLY
        ,DEF_CELLMEMORY
        ,DEF_INMEMORY_SERVICE
        ,DEF_INMEMORY_SERVICE_NAME
		)
AS SELECT DISTINCT CAST(c.relname AS VARCHAR(128))
		,CAST(p.partstrat AS VARCHAR(9))
		,CAST(NULL AS VARCHAR(9))
		,CAST(count(i.inhseqno) AS NUMERIC)
		,CAST(NULL AS  NUMERIC)
		,CAST(p.partnatts AS  NUMERIC)
		,CAST(NULL AS  NUMERIC)
		,CAST('VALID' AS ORACLE.VARCHAR2(8))
		,CAST(t.tablespace AS ORACLE.VARCHAR2(30))
		,CAST(NULL AS  NUMERIC)
		,CAST(NULL AS NUMERIC)
		,CAST(1 AS  NUMERIC) 
		,CAST(255 AS  NUMERIC) 
		,CAST('DEFAULT' AS ORACLE.VARCHAR2(40))
		,CAST('DEFAULT' AS ORACLE.VARCHAR2(40))
		,CAST('DEFAULT' AS ORACLE.VARCHAR2(40))
		,CAST('DEFAULT' AS ORACLE.VARCHAR2(40))
		,CAST('DEFAULT' AS ORACLE.VARCHAR2(40))
		,CAST('DEFAULT' AS ORACLE.VARCHAR2(40))
		,CAST(NULL AS  NUMERIC)
		,CAST(NULL AS  NUMERIC)
		,CAST(NULL AS ORACLE.VARCHAR2(7))
		,CAST(NULL AS ORACLE.VARCHAR2(8))
		,CAST(NULL AS ORACLE.VARCHAR2(30))
		,CAST(NULL AS ORACLE.VARCHAR2(7))
		,CAST(NULL AS ORACLE.VARCHAR2(7))
		,CAST(NULL AS ORACLE.VARCHAR2(7))
		,CAST(NULL AS ORACLE.VARCHAR2(128))
		,CAST(NULL AS ORACLE.VARCHAR2(1000))
		,CAST(NULL AS ORACLE.VARCHAR2(3))
		,CAST(NULL AS ORACLE.VARCHAR2(1000))
		,CAST(NULL AS ORACLE.VARCHAR2(3))
		,CAST(NULL AS ORACLE.VARCHAR2(3))
		,CAST(NULL AS ORACLE.VARCHAR2(4))
		,CAST(NULL AS ORACLE.VARCHAR2(3))
		,CAST(NULL AS ORACLE.VARCHAR2(8))
		,CAST(NULL AS ORACLE.VARCHAR2(8))
		,CAST(NULL AS ORACLE.VARCHAR2(15))
		,CAST(NULL AS ORACLE.VARCHAR2(17))
		,CAST(NULL AS ORACLE.VARCHAR2(13))
		,CAST(NULL AS ORACLE.VARCHAR2(3))
		,CAST(NULL AS ORACLE.VARCHAR2(24))
		,CAST(NULL AS ORACLE.VARCHAR2(12))
		,CAST(NULL AS ORACLE.VARCHAR2(1000))
FROM pg_catalog.pg_class c, pg_catalog.pg_partitioned_table p, pg_catalog.pg_inherits i, pg_catalog.pg_tables t
WHERE c.relkind = 'p' AND p.partrelid = c.oid AND i.inhparent = c.oid AND c.relname = t.tablename
GROUP BY c.relnamespace, c.relname, p.partstrat, p.partstrat, p.partnatts, t.tablespace;		

REVOKE ALL ON oracle.user_part_tables FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_part_tables TO PUBLIC;

----------------------------------------------------------------------------------------
--	user_objects
CREATE OR REPLACE VIEW oracle.all_objects(
		  owner
		, object_name
		, subobject_name
		, object_id
		, data_object_id
		, object_type
		, created
		, last_ddl_time
		, timestamp
		, status
		, temporary
		, generated
		, secondary
		, namespace
		,EDITION_NAME
		,SHARING
		,EDITIONABLE
		,ORACLE_MAINTAINED
		,APPLICATION
		,DEFAULT_COLLATION
		,DUPLICATED
		,SHARDED
		,CREATED_APPID
		,CREATED_VSNID
		,MODIFIED_APPID
		,MODIFIED_VSNID
		)
AS
SELECT	  CAST(u.usename AS VARCHAR2(128 )) 
		, CAST(relname AS VARCHAR2(128 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST(CAST(c.oid AS VARCHAR(38)) AS NUMERIC)
		, CAST(NULL AS NUMERIC)
		, CAST(
			(CASE relkind
				-- when 'c' THEN 'COMPOSITE'
				WHEN 'r' THEN 'TABLE'
				WHEN 'S' THEN 'SEQUENCE'
				-- WHEN 's' THEN 'SPECIAL'
				WHEN 't' THEN 'TYPE'
				WHEN 'v' THEN 'VIEW'
				WHEN 'i' THEN 'INDEX'
				ELSE 'UNKNOWN'
			END)
			AS VARCHAR2(23))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19 ))
		, CAST('VALID' AS VARCHAR2(7 ))
		, CAST((CASE WHEN relpersistence = 't' THEN 'Y' ELSE 'N' END) AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST(CAST(relnamespace AS VARCHAR(38)) AS NUMERIC)
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		
	FROM pg_class c JOIN pg_user u
		ON c.relowner = u.usesysid
/*
UNION

SELECT	  CAST(u.usename AS VARCHAR2(63 ))
		, CAST(synname AS VARCHAR2(63 ))
		, CAST(NULL AS VARCHAR2(63 ))
		, CAST(CAST(syn.oid AS VARCHAR(38)) AS NUMERIC)
		, CAST(NULL AS NUMERIC)
		, CAST('SYNONYM' AS VARCHAR2(23 ))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19 ))
		, CAST('VALID' AS VARCHAR2(7 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST(CAST(synnamespace AS VARCHAR(38)) AS NUMERIC)
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)

	FROM sys_synonym syn JOIN pg_user u
		ON syn.synowner = u.usesysid
*/
/*
UNION
SELECT	  CAST(u.usename AS VARCHAR2(63 )) 
		, CAST(l.relname AS VARCHAR2(63 ))
		, CAST(c.relname AS VARCHAR2(63 ))
		, CAST(CAST(c.oid AS VARCHAR(38 )) AS NUMERIC)
		, CAST(CAST(c.oid AS VARCHAR(38 )) AS NUMERIC)
		, CAST(
			(CASE c.relkind
				WHEN 'r' THEN 'TABLE PARTITION'
				WHEN 'i' THEN 'INDEX PARTITON'
				ELSE 'UNKNOWN'
			END)
		  AS VARCHAR2(23 ))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19 ))
		, CAST('VALID' AS VARCHAR2(7 ))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(CAST(c.relnamespace AS VARCHAR(38 )) AS NUMERIC)
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
	FROM pg_class c JOIN pg_user u ON c.relowner = u.usesysid,
		 pg_class l, pg_partition p
	WHERE c.relparttyp = 'p' AND p.partitionrelid = c.oid
		  AND p.partrelid = l.oid
*/
UNION

SELECT	  CAST(current_user AS VARCHAR2(128 )) 
		, CAST('TRIGGER_PKG' AS VARCHAR2(128 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST(0 AS NUMERIC)
		, CAST(NULL AS NUMERIC)
		, CAST('PACKAGE'  AS VARCHAR2(23 ))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19 ))
		, CAST('VALID' AS VARCHAR2(7 ))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(0 AS NUMERIC(38,0))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)

UNION

SELECT	  CAST(current_user AS VARCHAR2(128 ))
		, CAST('OPEN2000E_PKG' AS VARCHAR2(128 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST(0 AS NUMERIC)
		, CAST(NULL AS NUMERIC)
		, CAST('PACKAGE'  AS VARCHAR2(23))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19))
		, CAST('VALID' AS VARCHAR2(7 ))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(0 AS NUMERIC(38,0))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)

UNION

SELECT	  CAST(current_user AS VARCHAR2(128 ))
		, CAST('FORM_TM_ND_TAP_MEAS' AS VARCHAR2(128 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST(0 AS NUMERIC)
		, CAST(NULL AS NUMERIC)
		, CAST('PACKAGE'  AS VARCHAR2(23))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19 ))
		, CAST('VALID' AS VARCHAR2(7 ))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(0 AS NUMERIC(38,0))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)

UNION

SELECT	  CAST(current_user AS VARCHAR2(128 ))
		, CAST('NEW_STATISTICS_SAMPLE_PKG' AS VARCHAR2(128 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST(0 AS NUMERIC)
		, CAST(NULL AS NUMERIC)
		, CAST('PACKAGE'  AS VARCHAR2(23))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19))
		, CAST('VALID' AS VARCHAR2(7 ))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(0 AS NUMERIC(38,0))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)

UNION

SELECT	  CAST(u.usename AS VARCHAR2(128 ))
		, CAST(proname AS VARCHAR2(128 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST(CAST(p.oid AS VARCHAR(38 )) AS NUMERIC)
		, CAST(NULL AS NUMERIC)
		, CAST(
			(CASE p.prokind
				WHEN 'f' THEN 'FUNCTION'
				WHEN 'p' THEN 'PROCEDURE'
				WHEN 'w' THEN 'WINDOWSFUNCTION'
				ELSE 'UNKNOWN'
			END)
			AS VARCHAR2(23))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19))
		, CAST('VALID' AS VARCHAR2(7 ))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(CAST(pronamespace AS VARCHAR(38 )) AS NUMERIC)
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
	FROM pg_proc p JOIN pg_user u
		ON p.proowner = u.usesysid

UNION

SELECT	  CAST(u.usename AS VARCHAR2(128 )) 
		, CAST(t.tgname AS VARCHAR2(128 ))
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST(CAST(t.oid AS VARCHAR(38 )) AS NUMERIC)
		, CAST(NULL AS NUMERIC)
		, CAST('TRIGGER'AS VARCHAR2(23))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19))
		, CAST('VALID' AS VARCHAR2(7 ))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(CAST(c.relnamespace AS VARCHAR(38 )) AS NUMERIC)
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
	FROM pg_trigger t JOIN pg_class c ON t.tgrelid = c.oid ,
		 pg_user u
	WHERE  c.relowner = u.usesysid
/*
UNION

SELECT	  CAST(u.usename AS VARCHAR2(63 )) 
		, CAST(syn.synname AS VARCHAR2(63 ))
		, CAST(NULL AS VARCHAR2(63 ))
		, CAST(CAST(syn.oid AS VARCHAR(38 )) AS NUMERIC)
		, CAST(NULL AS NUMERIC)
		, CAST('SYNONYM'AS VARCHAR2(23 ))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19))
		, CAST('VALID' AS VARCHAR2(7 ))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(CAST(syn.synnamespace AS VARCHAR(38 )) AS NUMERIC)
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
	FROM sys_synonym syn JOIN pg_user u
		ON syn.synowner = u.usesysid
*/
/*
UNION

SELECT	  CAST(u.usename AS VARCHAR2(63 )) 
		, CAST(pkgname AS VARCHAR2(63 ))
		, CAST(NULL AS VARCHAR2(63 ))
		, CAST(CAST(pkg.oid AS VARCHAR(38 )) AS NUMERIC)
		, CAST(NULL AS NUMERIC)
		, CAST('PACKAGE' AS VARCHAR2(23 ))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19 ))
		, CAST(
			  (CASE pkg.PKGSTATUS
			  WHEN 't' THEN 'VALID'
			  WHEN 'f' THEN 'INVALID'
			  END) AS VARCHAR2(7 ))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(CAST(pkgnamespace AS VARCHAR(38 )) AS NUMERIC)
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
	FROM pg_package pkg JOIN pg_user u
		ON pkg.pkgowner = u.usesysid

UNION

SELECT	  CAST(u.usename AS VARCHAR2(63 )) 
		, CAST(pkgname AS VARCHAR2(63 ))
		, CAST(NULL AS VARCHAR2(63 ))
		, CAST(CAST(pkg.oid AS VARCHAR(38 )) AS NUMERIC)
		, CAST(NULL AS NUMERIC)
		, CAST('PACKAGE BODY' AS VARCHAR2(23 ))
		, CAST(NULL AS DATE)
		, CAST(NULL AS DATE)
		, CAST(NULL AS VARCHAR2(19 ))
		, CAST(
			  (CASE pkg.PKGSTATUS
			  WHEN 't' THEN 'VALID'
			  WHEN 'f' THEN 'INVALID'
			  END) AS VARCHAR2(7 ))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(NULL AS VARCHAR2(1))
		, CAST(CAST(pkgnamespace AS VARCHAR(38 )) AS NUMERIC)
		, CAST(NULL AS VARCHAR2(128 ))
		, CAST('NONE' AS VARCHAR2(13 ))
		, CAST(NULL AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS VARCHAR2(100 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST('N' AS VARCHAR2(1 ))
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
		, CAST(NULL AS numeric)
	FROM pg_package pkg JOIN pg_user u
		ON pkg.pkgowner = u.usesysid AND pkg.pkgbodysrc IS NOT NULL
		
*/		
;

REVOKE ALL ON oracle.all_objects FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.all_objects TO PUBLIC;


CREATE OR REPLACE VIEW oracle.user_objects
   AS
	SELECT		  object_name
		, subobject_name
		, object_id
		, data_object_id
		, object_type
		, created
		, last_ddl_time
		, timestamp
		, status
		, temporary
		, generated
		, secondary
		, namespace
		,EDITION_NAME
		,SHARING
		,EDITIONABLE
		,ORACLE_MAINTAINED
		,APPLICATION
		,DEFAULT_COLLATION
		,DUPLICATED
		,SHARDED
		,CREATED_APPID
		,CREATED_VSNID
		,MODIFIED_APPID
		,MODIFIED_VSNID
	FROM all_objects
	WHERE owner = CAST(current_user AS VARCHAR2(128))
;

REVOKE ALL ON oracle.user_objects FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_objects TO PUBLIC;

----------------------------------------------------------------------------------------
--	user_tab_comments
create or replace view oracle.user_tab_comments as
	select cast(c.relname as VARCHAR2(128 )) as TABLE_NAME,
		cast((case c.relkind when 'r' then 'TABLE' when 'v' then 'VIEW' else 'TABLE' end) as VARCHAR2(11 )) as TABLE_TYPE,
		cast(d.DESCRIPTION as VARCHAR2(4000 )) as COMMENTS,
		NULL::numeric AS ORIGIN_CON_ID
	FROM  pg_CLASS C, pg_DESCRIPTION d, pg_USER au
	where c.oid = d.objoid and d.classoid = 1259
		and d.objsubid=0
		and c.relowner=au.usesysid
		and c.relkind in ('r','v')
		and au.usename = CAST(CURRENT_USER AS VARCHAR2(128));

REVOKE ALL ON oracle.user_tab_comments FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_tab_comments TO PUBLIC;


----------------------------------------------------------------------------------------
-- user_constraints
CREATE OR REPLACE  VIEW oracle.ALL_CONSTRAINTS AS
	SELECT (pg_get_userbyid(c.relowner))::VARCHAR2(128) AS OWNER ,
	(cs1.CONNAME)::VARCHAR2(128) AS CONSTRAINT_NAME,
	(
		CASE WHEN (cs1.CONTYPE = 'c'::"char") THEN 'C'::TEXT
			 WHEN (cs1.CONTYPE = 'p'::"char") THEN 'P'::TEXT
			 WHEN (cs1.CONTYPE = 'u'::"char") THEN 'U'::TEXT
			 WHEN (cs1.CONTYPE = 'f'::"char") THEN 'R'::TEXT
			 WHEN (cs1.CONTYPE = 't'::"char") THEN 'T'::TEXT
			 WHEN (cs1.CONTYPE = 'x'::"char") THEN 'X'::TEXT
			 ELSE NULL::TEXT
		END
	)::VARCHAR2(1) AS CONSTRAINT_TYPE,
	(C.RELNAME)::VARCHAR2(128) AS TABLE_NAME,
	pg_get_constraintdef(cs1.oid) AS SEARCH_CONDITION,

	NULL :: VARCHAR2(4000) AS SEARCH_CONDITION_VC,
	pg_GET_USERBYID(c_ref.RELOWNER)::VARCHAR2(128) AS R_OWNER,
	(
	cs2.conname::VARCHAR2(128 )
	) AS R_CONSTRAINT_NAME,
	(
	CASE WHEN (cs1.CONFDELTYPE = 'a'::"char") THEN 'NO ACTION'::TEXT
		WHEN (cs1.CONFDELTYPE = 'c'::"char") THEN 'CASCADE'::TEXT
		WHEN (cs1.CONFDELTYPE = 'r'::"char") THEN 'RESTRICT'::TEXT
		WHEN (cs1.CONFDELTYPE = 'n'::"char") THEN 'SET NULL'::TEXT
		WHEN (cs1.CONFDELTYPE = 'd'::"char") THEN 'SET DEFAULT'::TEXT
		ELSE NULL::TEXT END
	)::VARCHAR2(9 ) AS DELETE_RULE,
	(
	CASE WHEN (cs1.CONTYPE = 'f'::"char") THEN
	(
		SELECT DISTINCT (CASE WHEN (TRG.TGENABLED!='D') THEN 'ENABLED'::TEXT
								ELSE 'DISABLED'::TEXT END )
		FROM pg_TRIGGER TRG
		WHERE  TRG.tgconstraint = cs1.oid
		AND TRG.TGRELID = cs1.CONRELID
	)
	ELSE 'ENABLED'::TEXT
	  END
	)::VARCHAR2(8 ) AS STATUS,

	(
		CASE WHEN (cs1.CONDEFERRABLE = false) THEN 'NOT DEFERRABLE'::TEXT
		ELSE 'DEFERRABLE'::TEXT END
	)::VARCHAR2(14) AS DEFERRABLE,
	(
		CASE WHEN (cs1.CONDEFERRED = false) THEN 'IMMEDIATE'::TEXT
		ELSE 'DEFERRED'::TEXT END
	)::VARCHAR2(9) AS DEFERRED,
	(
	CASE WHEN (cs1.CONVALIDATED ='t') THEN 'VALIDATED'::TEXT
	   WHEN (cs1.CONVALIDATED ='f') THEN 'NOVALIDATED'::TEXT
	  ELSE NULL::TEXT END
	)::VARCHAR2(13 ) AS VALIDATED,
	'USER NAME'::VARCHAR2(14 ) AS GENERATED,
	NULL::VARCHAR2(3) AS BAD,
	NULL::VARCHAR2(4) AS RELY,
	NULL::TIMESTAMP(0) WITHOUT TIME ZONE AS LAST_CHANGE,
	(
	CASE WHEN (cs1.CONTYPE = 'p' OR cs1.CONTYPE = 'u') THEN
		(
			SELECT pg_get_userbyid(t.relowner) FROM pg_INDEX IND, pg_CLASS T, pg_DEPEND DEP
			WHERE INDEXRELID = DEP.OBJID
			AND DEP.REFOBJID = cs1.OID
			AND T.OID = IND.INDEXRELID
		)
	ELSE
		NULL
	END
	)::VARCHAR2(128) AS INDEX_OWNER,
	(
	CASE WHEN (cs1.CONTYPE = 'p' OR cs1.CONTYPE = 'u') THEN
		(
			SELECT T.RELNAME FROM pg_INDEX IND ,pg_CLASS T,pg_DEPEND DEP
			WHERE INDEXRELID = DEP.OBJID
			AND DEP.REFOBJID = cs1.OID
			AND T.OID = IND.INDEXRELID
		)
	ELSE
		NULL
	END
	)::VARCHAR2(128 ) AS INDEX_NAME,
	NULL::VARCHAR2(7 ) AS INVALID,
	NULL::VARCHAR2(14 ) AS VIEW_RELATED,
	NULL::VARCHAR2(256) AS ORIGIN_CON_ID
	from ( pg_constraint cs1 left outer join pg_constraint cs2 on
			(
				cs1.confrelid = cs2.conrelid and
				(cs2.contype = 'u' or cs2.contype = 'p') and
				cs1.contype = 'f' and
				cs2.conkey = cs1.confkey
			)
		)
		left outer join pg_class c_ref on cs1.confrelid = c_ref.oid,
		pg_class c
	WHERE cs1.CONRELID = C.OID
		AND (has_table_privilege(c.oid,'SELECT') = TRUE
		OR has_table_privilege(c.oid, 'INSERT') = TRUE
		OR has_table_privilege(c.oid, 'UPDATE') = TRUE
		OR has_table_privilege(c.oid, 'DELETE') = TRUE
		OR has_table_privilege(c.oid, 'REFERENCES') = TRUE
		OR has_table_privilege(c.oid, 'TRIGGER')= TRUE);

REVOKE ALL ON oracle.ALL_CONSTRAINTS FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.ALL_CONSTRAINTS TO PUBLIC;


CREATE OR REPLACE VIEW oracle.USER_CONSTRAINTS AS
	SELECT * FROM oracle.ALL_CONSTRAINTS
	WHERE OWNER = (SELECT cast(CURRENT_USER as varchar2(128)));

REVOKE ALL ON oracle.user_constraints FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.user_constraints TO PUBLIC;

----------------------------------------------------------------------------------------
-- dba_directories
/* Because the path alias is not used in highgo, 
 * it is not compatible with this table, 
 * which is all shown as empty
 */
CREATE OR REPLACE VIEW oracle.dba_directories AS
   SELECT NULL::VARCHAR2(128 ) AS OWNER, 
   NULL::VARCHAR2(128 ) AS DIRECTORY_NAME, 
   NULL::VARCHAR2(4000) AS DIRECTORY_PATH, 
   null::VARCHAR2(256) AS ORIGIN_CON_ID from dual LIMIT 0 
;

REVOKE ALL ON oracle.dba_directories FROM PUBLIC;
GRANT SELECT, REFERENCES ON oracle.dba_directories TO PUBLIC;

--end
-----------------------------------------------------------------------------
