/*
 * File: flashback.h
 * 
 * Abstract: Support for flashback.
 *
 * Authored by zhangyilin@highgo.com，20180902
 *
 * Copyright: 
 * Copyright (c) 2009-2020, HighGo Software Co.,Ltd. All rights reserved.
 *
 * IDENTIFICATION
 *     src/include/access/flashback.h
 *
 */
#ifndef	HGDB_FLASHBACK_H
#define	HGDB_FLASHBACK_H

#include "utils/timestamp.h"
#include "nodes/pg_list.h"
#include "storage/itemptr.h"
#include "storage/bufpage.h"
#include "utils/relcache.h"
#include "access/htup.h"

extern int hg_fbq_retention;
extern bool hg_fbq_guarantee;

/*
 * Structure for dealing with flashback implementation.
 */
typedef struct FlashBackData
{
	int				tag;
	TimestampTz		flashbacktime;	/*flash back time that user refer to*/
	TimestampTz		flashbackstartime;
	TimestampTz		flashbackendtime;
	Page			curPage;		/*A copy of page that tuple exist.*/
	BlockNumber		curBlkno;
	OffsetNumber	curOffnum;
	bool			isMostOldPage;  /*if true then stop recycle after ayalyse cur page*/
	Relation		rel;			/*Tuple exists in the relation*/
	List			*tupleList;		/*The elem of this list is TupleMapping*/
	bool			inprogress;
	bool			startfbquery;
	bool			fbvacuum;

	int		oidXid;
	int		newXid;
	char*		ts;
}FlashBackData;

void FlashBackInit(void);
bool QueryInvalidTupleFlashbackCheck(HeapTuple tuple);
bool xidInTimeLimit(TransactionId xid);
bool xidInTimeLimitVersion(TransactionId xid);
bool getFlashbackQuery(void);
void flashbackTimeCheck(TimestampTz fbTime);
void startFlashbackQueryByTs(TimestampTz fbTime);
void startFlashbackQueryByXid(uint32 xid);
void startFlashbackVersionsQueryByTs(TimestampTz fbStartime, TimestampTz fbEndtime);
void startFlashbackVersionsQueryByXid(uint32 startXid, uint32 endXid);
void endFlashbackQuery(void);
bool getFlashbackQuarantee(void);
void setFlashbackVacuum(bool flag);
bool getFlashbackVacuum(void);
char * stristr (const char * str1, const char * str2);
void setFlashbackLimit(void);
int getFlashbackLimitOidXid(void);
int getFlashbackLimitNewXid(void);
char * getFlashbackLimitTs(void);


#endif

