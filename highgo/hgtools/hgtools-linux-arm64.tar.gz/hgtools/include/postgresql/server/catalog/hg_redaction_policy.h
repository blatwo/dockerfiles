/*-------------------------------------------------------------------------
 *
 * hg_redaction_policy.h
 *	  definition of the "redaction policy" system catalog (hg_redaction_policy)
 *
 *
 * Portions Copyright (c) 1996-2020, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 * src/include/catalog/hg_redaction_policy.h
 *
 * NOTES
 *	  The Catalog.pm module reads this file and derives schema
 *	  information.
 *
 *-------------------------------------------------------------------------
 */
#ifndef HG_REDACTION_POLICY_H
#define HG_REDACTION_POLICY_H

#include "catalog/genbki.h"
#include "catalog/hg_redaction_policy_d.h"

/* ----------------
 *		pg_policy definition. cpp turns this into
 *		typedef struct FormData_pg_policy
 * ----------------
 */
CATALOG(hg_redaction_policy,9500,RedactionPolicyRelationId)
{
	Oid			polid;			/* oid */
	NameData	polname;		/* Policy name. */
	Oid			tabrelid;		/* Oid of the relation with redaction policy. */
	NameData	tabname;		/* Oid of the relation with redaction policy. */
	bool		polpermissive;	/* restrictive or permissive redaction policy */

#ifdef CATALOG_VARLEN
	text 		poloptions[1];		/* Policy quals. */
#endif
} FormData_hg_redaction_policy;

/* ----------------
 *		Form_pg_policy corresponds to a pointer to a row with
 *		the format of pg_policy relation.
 * ----------------
 */
typedef FormData_hg_redaction_policy *Form_hg_redaction_policy;

#endif							/* HG_REDACTION_POLICY_H */
