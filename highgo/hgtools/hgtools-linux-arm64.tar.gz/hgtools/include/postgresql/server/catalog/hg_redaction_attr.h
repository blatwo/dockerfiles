/*-------------------------------------------------------------------------
 *
 * hg_redaction_attr.h
 *	  definition of the "policy" system catalog (pg_policy)
 *
 *
 * Portions Copyright (c) 1996-2020, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 * src/include/catalog/hg_redaction_attr.h
 *
 * NOTES
 *	  The Catalog.pm module reads this file and derives schema
 *	  information.
 *
 *-------------------------------------------------------------------------
 */
#ifndef HG_REDACTION_ATTR_H
#define HG_REDACTION_ATTR_H

#include "catalog/genbki.h"
#include "catalog/hg_redaction_attr_d.h"

/* ----------------
 *		pg_policy definition. cpp turns this into
 *		typedef struct FormData_pg_policy
 * ----------------
 */
CATALOG(hg_redaction_attr,9600,RedactionAttrRelationId)
{
	Oid			polid;
	NameData	polname;
	Oid			tabrelid;		/* table oid */
	NameData	attname;		/* column name. */
	Oid			procid;		/* pg_proc.proid. */
	NameData	procname;		/* Policy name. */
} FormData_hg_redaction_attr;

/* ----------------
 *		Form_pg_policy corresponds to a pointer to a row with
 *		the format of pg_policy relation.
 * ----------------
 */
typedef FormData_hg_redaction_attr *Form_hg_redaction_attr;

#endif							/* HG_REDACTION_ATTR_H */
