/* -------------------------------------------------------------------------
 *
 * hg_user_seclabel.h
 *	  definition of the "user security label" system catalog
 *
 * Authored by sunchengxi@highgo.com ,20191207
 *
 * Copyright (c) 2009-2020, HighGo Software Co.,Ltd. All right reserved
 *
 * src/include/catalog/hg_user_seclabel.h
 *
 * NOTES
 *	  The Catalog.pm module reads this file and derives schema
 *	  information.
 *
 * -------------------------------------------------------------------------
 */
#ifndef HG_USER_SECLABEL_H
#define HG_USER_SECLABEL_H

#include "catalog/genbki.h"
#include "catalog/hg_user_seclabel_d.h"

/* ----------------
 *		hg_user_seclabel definition.  cpp turns this into
 *		typedef struct FormData_hg_user_seclabel
 * ----------------
 */
CATALOG(hg_user_seclabel,3435,UserSecLabelRelationId) BKI_SHARED_RELATION BKI_ROWTYPE_OID(4142,UserSecLabelRelation_Rowtype_Id) BKI_SCHEMA_MACRO
{
	Oid		useroid;			/* OID of the object itself */

#ifdef CATALOG_VARLEN			/* variable-length fields start here */
	text	label BKI_FORCE_NOT_NULL;	/* security label of the object */
#endif
} FormData_hg_user_seclabel;

typedef FormData_hg_user_seclabel *Form_hg_user_seclabel;

#endif							/* HG_USER_SECLABEL_H */
