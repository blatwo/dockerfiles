/*add by wxm*/
/* ------------------------------------------------ 
* 
* File: hg_t_sys_auditanalyze_rule.h
*
* Abstract: 
*	   �����ϵͳ���Ķ���
*
* Authored by wangxiumin@highgo.com 20200218.
*
* Copyright:
* Copyright (c) 2009-2020, HighGo Software Co.,Ltd. 
* All rights reserved .   
*
* Identification:
*	   src/include/catalog/hg_t_sys_auditanalyze_rule.h  
*-------------------------------------------------
*/	

#ifndef HG_HG_T_SYS_AUDITANALYZE_CONF_H
#define HG_HG_T_SYS_AUDITANALYZE_CONF_H

#include "catalog/genbki.h"
#include "catalog/hg_t_sys_auditanalyze_rule_d.h"

/* ----------------
 *		hg_t_sys_auditanalyze_rule definition.  cpp turns this into
 *		typedef struct FormData_hg_t_sys_auditanalyze_conf
 * ----------------
 */
CATALOG(hg_t_sys_auditanalyze_rule,6236,AuditAnalyzeRelationId)
{
	NameData	rulename;
	char		audittype;  /*enum AuditType*/
	Oid			auditevent; /* confid of stmtaudit/objectaudit */
	char		risklevel;	/* 1 2 3 4 */
} FormData_hg_t_sys_auditanalyze_rule;


/* ----------------
 *		Form_hg_t_sys_auditanalyze_rule corresponds to a pointer to a tuple with
 *		the format of hg_t_sys_auditanalyze_rule relation.
 * ----------------
 */
typedef FormData_hg_t_sys_auditanalyze_rule *Form_hg_t_sys_auditanalyze_rule;

#endif							/* HG_AUDIT_H */

