/*add by wxm*/
/* ------------------------------------------------ 
* 
* File: hg_t_sys_stmtaudit_conf.h
*
* Abstract: 
*	   �����ϵͳ���Ķ���
*
* Authored by wangxiumin@highgo.com 20200218.
*
* Copyright:
* Copyright (c) 2009-2020, HighGo Software Co.,Ltd. 
* All rights reserved .   
*
* Identification:
*	   src/include/catalog/hg_t_sys_globalaudit_conf.h  
*-------------------------------------------------
*/	

#ifndef HG_HG_T_SYS_GLOBALAUDIT_CONF_H
#define HG_HG_T_SYS_GLOBALAUDIT_CONF_H

#include "catalog/genbki.h"
#include "catalog/hg_t_sys_globalaudit_conf_d.h"

/* ----------------
 *		hg_t_sys_globalaudit_conf definition.  cpp turns this into
 *		typedef struct FormData_hg_t_sys_globalaudit_conf
 * ----------------
 */
CATALOG(hg_t_sys_globalaudit_conf,6229,AuditGlobalRelationId) BKI_SHARED_RELATION
{
	Oid	 	 confid;
	Oid		 user;
	char	 auditevent;
	char	 auditmode; 
	char	 risklevel;
	
/*	NameData auditeventname;
//	NameData username;
//	NameData auditmodename;*/
} FormData_hg_t_sys_globalaudit_conf;


/* ----------------
 *		Form_hg_t_sys_globalaudit_conf corresponds to a pointer to a tuple with
 *		the format of hg_t_sys_globalaudit_confrelation.
 * ----------------
 */
typedef FormData_hg_t_sys_globalaudit_conf *Form_hg_t_sys_globalaudit_conf;

#endif							/* HG_AUDIT_H */

