/* ------------------------------------------------------------------------
 * checkpasswd.h
 *   
 * These definitions are needed by both frontend and backend code to work
 * with MD5-encrypted passwords.
 *
 * Copyright (c) 2009-2019, HighGo Software Co.,Ltd. All rights reserved.
 * Authored by shanchengkai@highgo.com 20191224.
 *
 * src/include/common/checkpasswd.h
 * ------------------------------------------------------------------------
 */

#ifndef CHECKPASSWD_H
#define CHECKPASSWD_H

#include "c.h"
#include "utils/elog.h"
#include "utils/errcodes.h"
#include "common/logging.h"

#define MIN_PWD_LENGTH 10
#define MAX_PWD_LENGTH 1024
extern char *str_lower(char *string);
extern int check_keywords(const char *password ,char* error_msg);
extern bool IsSpecial(const char c);
extern int CommonPasswdCheck(const char *shadow_pass, const char *user);
extern int PasswdLength(const char* passwd, const char *user);

#endif
