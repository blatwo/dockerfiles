/*
 * Authored by wangmingjun@highgo.com, 20200126.
 *
 * Copyright (c) 2009-2020, HighGo Software Co.,Ltd. All rights reserved.
 */

/* ------------------------------------------------ 
 * 
 * File: hg_ssha.h
 *
 * Abstract: 
 *		Definations of SSHA role.	
 *
 * Authored by wangmingjun@highgo.com, 20200126.
 *
 * Copyright:
 * Copyright (c) 2009-2020, HighGo Software Co.,Ltd.
 * All rights reserved.
 *
 * Identification:
 *		src/include/common/hg_ssha.h
 *
 *-------------------------------------------------
 */

#ifndef SSHA_H
#define SSHA_H


/* Shared Storage HA, SSHA roles, by jrh
 * this should not be put here
 * */
typedef enum SSHARole
{
    SSHA_ROLE_PRIMARY = 0,            /* primary node, read/write */
    SSHA_ROLE_STANDBY,                        /* standby node, read only */
    SSHA_ROLE_NA,
} SSHARole;

extern bool IsSshaRole(int role);
extern void SetSshaRole(int role);
extern char* GetSshaRole(void);

#endif

