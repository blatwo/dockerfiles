/*
 * --------------------------------------------------------------------
 * File: hg_base64.h
 * 
 * Authored by chengyuanhao@highgo.com, 20210209
 * 
 * Copyright:
 * 	Copyright(c) 2009-2021, HighGo Software Co.,Ltd.
 *  All rights reserved.
 * 
 * Identification:
 * hg_base64.h
 * --------------------------------------------------------------------
 */ 
#ifndef HG_BASE64_H
#define HG_BASE64_H
/* base 64 */
extern int	hg_base64_encode(const char *src, int len, char *dst, int dstlen);
extern int	hg_base64_decode(const char *src, int len, char *dst, int dstlen);
extern int	hg_base64_enc_len(int srclen);
extern int	hg_base64_dec_len(int srclen);

#endif	