/*-------------------------------------------------------------------------
 *
 * user.h
 *	  Commands for manipulating roles (formerly called users).
 * Authored by shanchengkai@highgo.com,20191016.
 *
 * Portions Copyright (c) 2009-2020, HighGo Software Co.,Ltd. All rights reserved.
 * src/include/commands/user.h
 *
 *-------------------------------------------------------------------------
 */
#ifndef USER_H
#define USER_H

#include "catalog/objectaddress.h"
#include "libpq/crypt.h"
#include "nodes/parsenodes.h"
#include "parser/parse_node.h"

/* GUC. Is actually of type PasswordType. */
extern int	Password_encryption;
/* add begin by lichunran at 20200814 */
extern bool HgIdCheckEnable;
extern char *ip_addr;
/* add end by lichunran at 20200814 */

/* modify begin by shanchengkai at 20191016 */
typedef enum
{
	VALID = 0,
	EXPIRE_SOON,
	EXPIRE
}PASSWORD_STATE;

/* Hook to check passwords in CreateRole() and AlterRole() */
typedef void (*check_password_hook_type) (const char *username, const char *shadow_pass, PasswordType password_type, Datum *validuntil_time, bool *validuntil_null);
extern PGDLLIMPORT check_password_hook_type check_password_hook;
/* modify end by shanchengkai at 20191016 */
typedef void (*Alter_user_hook_type) (bool *SOP, Oid roleid, bool altpwd, bool valun, bool deny);
extern PGDLLIMPORT Alter_user_hook_type alter_user_hook;

/* fix bug v4.3.4.8-TD-02 at 20191220 by why begin */
//typedef void (*Alter_user_hook_type) (bool *SOP, Oid roleid, bool altpwd, bool valun, bool deny);
typedef void (*Alter_user_hook_type_v4) (bool *SOP, Oid roleid, bool altpwd, bool valun, bool rep, bool deny);
/* fix bug v4.3.4.8-TD-02 at 20191220 by why end */
extern PGDLLIMPORT Alter_user_hook_type_v4 alter_user_hook_v4;


extern Oid	CreateRole(ParseState *pstate, CreateRoleStmt *stmt);
extern Oid	AlterRole(AlterRoleStmt *stmt);
extern Oid	AlterRoleSet(AlterRoleSetStmt *stmt);
extern void DropRole(DropRoleStmt *stmt);
extern void GrantRole(GrantRoleStmt *stmt);
extern ObjectAddress RenameRole(const char *oldname, const char *newname);
extern void DropOwnedObjects(DropOwnedStmt *stmt);
extern void ReassignOwnedObjects(ReassignOwnedStmt *stmt);
extern List *roleSpecsToIds(List *memberNames);

extern PASSWORD_STATE PasswordState;
#endif							/* USER_H */
