/*-------------------------------------------------------------------------
 *
 * redactionpolicy.h
 *	  prototypes for redactionpolicy.c.
 *
 *
 * Portions Copyright (c) 1996-2020, Highgo Development Group
 *
 * src/include/commands/redactionpolicy.h
 *
 *-------------------------------------------------------------------------
 */
#ifndef REDACTION_POLICY_H
#define REDACTION_POLICY_H

#include "catalog/objectaddress.h"
#include "nodes/parsenodes.h"
#include "parser/parse_node.h"

#define CATALOG_RELID   10
#define VIEW_RELID      11

#define BUFFSIZE        256

typedef struct RedactionOptions
{
	int32		vl_len_;		/* varlena header (do not touch directly!) */
	int			application_offset;
    int         user_offset;
    int         session_user_offset;
    int         ip_offset;
} RedactionOptions;

typedef struct VarParserValue
{
    Oid table_oid;
    char col_name[NAMEDATALEN];
} VarParserValue;

typedef enum{
    M_UNKNOWN,
    REDACT_ALL,
    REDACT_BANKCARD,
    REDACT_EMAILNAME,
    REDACT_EMAILFULL,
    REDACT_DIGITS,
    REDACT_SHUFFLE,
    REDACT_RANDOM,
    REDACT_IDCARD,
    REDACT_NAME,
    REDACT_PHONE
}MaskBehaviour;

typedef struct MaskingFuncsInfo
{
    const char*     func;
    MaskBehaviour   type;
} MaskingFuncsInfo;

static const MaskingFuncsInfo masking_funcs_infos[] =
{
    { "redact_all", REDACT_ALL },
    { "redact_bankcard", REDACT_BANKCARD },
    { "redact_emailname", REDACT_EMAILNAME },
    { "redact_emailfull", REDACT_EMAILFULL },
    { "redact_digits", REDACT_DIGITS },
    { "redact_shuffle", REDACT_SHUFFLE },
    { "redact_random", REDACT_RANDOM },
    { "redact_idcard", REDACT_IDCARD },
    { "redact_name", REDACT_NAME },
    { "redact_phone", REDACT_PHONE },
    { NULL, M_UNKNOWN }
};


extern bool redaction_policy;

extern ObjectAddress CreateRedactionPolicy(CreateRedactionPolicyStmt *stmt);
extern ObjectAddress AlterRedactionPolicy(AlterRedactionPolicyStmt *stmt);
extern ObjectAddress DropRedactionPolicy(DropRedactionPolicyStmt *stmt);
extern void RemoveRedactionPolicyById(Oid policy_id);
extern void validateWithRedactionApplication(const char *value);
extern bool handle_redaction_data(ParseState *pstate, Query *query);

#endif
