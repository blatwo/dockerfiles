/*
 * seclabel.h
 *
 * Prototypes for functions in commands/seclabel.c
 *
 * Portions Copyright (c) 1996-2019, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 * Authored by sunchengxi@highgo.com，20200206.
 *
 * Portions Copyright (c) 2009-2020, HighGo Software Co.,Ltd. All rights reserved.
 */
#ifndef SECLABEL_H
#define SECLABEL_H

#include "catalog/objectaddress.h"

/*
 * Internal APIs
 */
extern char *GetSecurityLabel(const ObjectAddress *object,
							  const char *provider);
extern void SetSecurityLabel(const ObjectAddress *object,
							 const char *provider, const char *label);
extern void DeleteSecurityLabel(const ObjectAddress *object);
extern void DeleteSharedSecurityLabel(Oid objectId, Oid classId);

/*add begin by sunchengxi at 202002012*/
extern char * GetUserSeclabelInternal(const Oid user_oid);
extern void SetUserSeclabelInternal(const Oid user_oid, const char *seclabel, bool setnew);
extern void DeleteUserSeclabelInternal(const Oid user_oid);
/*add end by sunchengxi at 202002012*/

/*add begin by sunchengxi at 202002027*/
extern char * GetTableSeclabelInternal(const Oid table_oid);
extern void SetTableSeclabelInternal(const Oid table_oid, const char *seclabel, bool setnew);
extern void DeleteTableSeclabelInternal(const Oid table_oid);
/*add end by sunchengxi at 202002027*/

/*
 * Statement and ESP hook support
 */
extern ObjectAddress ExecSecLabelStmt(SecLabelStmt *stmt);

typedef void (*check_object_relabel_type) (const ObjectAddress *object,
										   const char *seclabel);
extern void register_label_provider(const char *provider,
									check_object_relabel_type hook);

#endif							/* SECLABEL_H */
