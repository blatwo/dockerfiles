/* contrib/crypt_fdw/crypt_fdw--1.0.sql */

-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION crypt_fdw" to load this file. \quit

CREATE FUNCTION crypt_fdw_handler()
RETURNS fdw_handler
AS 'MODULE_PATHNAME'
LANGUAGE C STRICT;

CREATE FUNCTION crypt_fdw_validator(text[], oid)
RETURNS void
AS 'MODULE_PATHNAME'
LANGUAGE C STRICT;

CREATE FOREIGN DATA WRAPPER crypt_fdw
  HANDLER crypt_fdw_handler
  VALIDATOR crypt_fdw_validator;

-- create a table to save the keys for database and schame.
CREATE TABLE public.crypt_fdw_keys (
   objectId        Oid,
   key             text NOT NULL,
   primary key(objectId)
);
GRANT INSERT ON public.crypt_fdw_keys TO PUBLIC;

-- create the functions for add sensitive columns.
CREATE FUNCTION public.encrypt_column(text, text, text, 
							   text DEFAULT 'column')
RETURNS void
AS 'MODULE_PATHNAME', 'encrypt_column'
LANGUAGE C STRICT;

CREATE FUNCTION public.adjust_column(text, text, text)
RETURNS void
AS 'MODULE_PATHNAME', 'adjust_column'
LANGUAGE C STRICT;

-- other useful functions.

CREATE FUNCTION public.crypt_fdw_randomkey()
RETURNS text
AS 'MODULE_PATHNAME', 'GenerateKey'
LANGUAGE C VOLATILE;

-- Generate the database's and schema's keys.
INSERT INTO public.crypt_fdw_keys 
SELECT objs.oid, public.crypt_fdw_randomkey() 
FROM (SELECT oid FROM pg_database UNION 
	  SELECT oid FROM pg_namespace) AS objs;

-- Insert new database's or schema's keys.
CREATE FUNCTION crypt_fdw_ddl_command_end()
RETURNS event_trigger AS $$
declare
	my_record	record;
	my_cursor	cursor for SELECT objid AS oid, TG_TAG AS tag
							FROM pg_event_trigger_ddl_commands();
BEGIN
	FOR my_record IN my_cursor LOOP
		IF my_record.tag = 'CREATE DATABASE' OR
		   my_record.tag = 'CREATE SCHEMA' THEN
			INSERT INTO public.crypt_fdw_keys SELECT my_record.oid, public.crypt_fdw_randomkey() ON CONFLICT DO NOTHING;
		END IF;
	END LOOP;
END;
$$ LANGUAGE PLPGSQL STRICT;

CREATE EVENT TRIGGER crypt_fdw_ddl_command_end
ON ddl_command_end
EXECUTE PROCEDURE crypt_fdw_ddl_command_end();

