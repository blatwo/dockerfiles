--DO $$
--BEGIN
--   IF current_database() <> current_setting('hg.job_database') THEN
--      RAISE EXCEPTION 'can only create extension in database %',
--                      current_setting('hg.job_database')
--      USING DETAIL = 'Jobs must be scheduled from the database configured in '||
--                     'hg.job_database, since the hg_job background worker '||
--                     'reads job descriptions from this database.',
--            HINT = format('Add hg.job_database = ''%s'' in postgresql.conf '||
--                          'to use the current database.', current_database());
--   END IF;
--END;
--$$;

CREATE SCHEMA hgjob;
CREATE SEQUENCE hgjob.jobid_seq;

CREATE TABLE hgjob.job (
	jobid bigint primary key DEFAULT nextval('hgjob.jobid_seq'),
	jobenabled bool NOT NULL DEFAULT TRUE,
	jobwhat text NOT NULL,
	jobinterval text NULL DEFAULT NULL,
	jobnextrun timestamptz NULL DEFAULT current_timestamp,
	jobstartrun timestamptz NULL,
	joblastrun timestamptz NULL,
	jobuser text NOT NULL DEFAULT current_user,
	jobcount int NOT NULL DEFAULT 0
);

GRANT SELECT ON hgjob.job TO public;
ALTER TABLE hgjob.job ENABLE ROW LEVEL SECURITY;

CREATE TABLE hgjob.jobrunning (
        jobid bigint,
        jobstartrun timestamptz NULL,
        jobpid int4 NULL,
        jobfailcount int NOT NULL DEFAULT 0
);

GRANT SELECT ON hgjob.jobrunning TO public;
ALTER TABLE hgjob.jobrunning ENABLE ROW LEVEL SECURITY;

CREATE TABLE hgjob.job_tmp_zombies (
	jobpid int4
);

GRANT SELECT ON hgjob.jobrunning TO public;
ALTER TABLE hgjob.jobrunning ENABLE ROW LEVEL SECURITY;

-- job_start
CREATE OR REPLACE FUNCTION hgjob.job_start(
	IN jid bigint, 
	IN jnextrun timestamptz DEFAULT current_timestamp
) returns text AS 
$$
declare
        mysql text;
        myid integer;
	runsql text;
	runid integer;
BEGIN
	mysql:='select jobid from hgjob.job where jobid = '||jid||'';
	runsql:='select jobid from hgjob.job where jobid = '||jid||' AND jobid in (SELECT jobid FROM hgjob.jobrunning)';

        execute mysql into myid;
	execute runsql into runid;

        if myid is null then
                return 'job does not exit';
        elsif runid is not null then
		return 'job is running';
	elsif jnextrun < now() then
		return 'jobnextrun time setting error';
	else
		UPDATE hgjob.job SET jobenabled = true, jobnextrun = jnextrun WHERE jobid = jid;
		return 'job start success';
	end if;
END;
$$ 
LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION hgjob.job_start(jid bigint, jnextrun timestamptz) TO public;


-- job_stop
CREATE OR REPLACE FUNCTION hgjob.job_stop(
	IN jid bigint
) returns text AS 
$$
declare
        mysql text;
        myid integer;
	runsql text;
	runid integer;
BEGIN
	mysql:='select jobid from hgjob.job where jobid = '||jid||'';
	runsql:='select jobid from hgjob.job where jobid = '||jid||' AND jobid in (SELECT jobid FROM hgjob.jobrunning)';

        execute mysql into myid;
	execute runsql into runid;

        if myid is null then
                return 'job does not exit';
	elsif runid is not null then
                return 'job is running';
        else
		UPDATE hgjob.job SET jobenabled = false, jobnextrun = NULL WHERE jobid = jid;
		return 'job stop success';
	end if;
END;
$$ 
LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION hgjob.job_stop(jid bigint) TO public;


-- job_nextrun
CREATE OR REPLACE FUNCTION hgjob.job_nextrun(
	IN jid bigint, 
	IN jnextrun timestamptz --DEFAULT current_timestamp
) returns text AS 
$$
declare
        mysql text;
        myid integer;
BEGIN
	mysql:='select jobid from hgjob.job where jobid = '||jid||'';

        execute mysql into myid;

        if myid is null then
		return 'job does not exit';
	elsif jnextrun < now() then
		return 'jobnextrun time setting error';
	else
		UPDATE hgjob.job SET jobnextrun = jnextrun WHERE jobid = jid;	
		return 'jobnextrun change success';
	end if;
END;
$$ 
LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION hgjob.job_nextrun(jid bigint, jnextrun timestamptz) TO public;


-- job_delete
CREATE OR REPLACE FUNCTION hgjob.job_delete(
	IN jid bigint
) returns text AS 
$$
declare
	mysql	text;
	myid	integer;
	runsql	text;
	runid	integer;
BEGIN
	mysql:='select jobid from hgjob.job where jobid = '||jid||'';	
	runsql:='select jobid from hgjob.job where jobid = '||jid||' AND jobid in (SELECT jobid FROM hgjob.jobrunning)';

	execute mysql into myid;
	execute runsql into runid;

	if myid is null then
		return 'job does not exit';
	elsif runid is not null then
                return 'job is running';
	else
		DELETE FROM hgjob.job WHERE jobid = jid;
		return 'job delete success';
	end if;
END;
$$ 
LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION hgjob.job_delete(jid bigint) TO public;


CREATE FUNCTION hgjob.job_run(jid bigint)
RETURNS text 
AS '$libdir/hg_job', 'job_run'
LANGUAGE C STRICT;

CREATE FUNCTION hgjob.job_interval(jid bigint, jinterval text)
RETURNS text
AS '$libdir/hg_job', 'job_interval'
LANGUAGE C STRICT;

CREATE FUNCTION hgjob.job_create(jwhat text, jinterval text, jstartrun timestamptz)
RETURNS text
AS '$libdir/hg_job', 'job_create'
LANGUAGE C STRICT;

CREATE FUNCTION hgjob.job_create(jwhat text, jinterval text)
RETURNS text
AS '$libdir/hg_job', 'job_create'
LANGUAGE C STRICT;

CREATE FUNCTION hgjob.job_change(jid bigint, jwhat text, jinterval text, jnextrun timestamptz)
RETURNS text
AS '$libdir/hg_job', 'job_change'
LANGUAGE C STRICT;

CREATE FUNCTION hgjob.job_change(jid bigint, jwhat text, jinterval text)
RETURNS text 
AS '$libdir/hg_job', 'job_change'
LANGUAGE C STRICT;

CREATE FUNCTION hgjob.job_what(jid bigint, jwhat text)
RETURNS text
AS '$libdir/hg_job', 'job_what'
LANGUAGE C STRICT;

CREATE FUNCTION hgjob.job_launch()
RETURNS text
AS '$libdir/hg_job', 'job_launch'
LANGUAGE C STRICT;


