/* src/pl/plpgsql/src/plpgsql--1.0.sql */

/*
 * Currently, all the interesting stuff is done by CREATE LANGUAGE.
 * Later we will probably "dumb down" that command and put more of the
 * knowledge into this script.
 */

CREATE LANGUAGE plpgsql;

COMMENT ON LANGUAGE plpgsql IS 'PL/pgSQL procedural language';

/* Add by yanxuebiao at 2021/2/1 */
/* CREATE OR REPLACE FUNCTION connect_by_cycle_check(path anyarray, node anyelement, iscycle boolean)
RETURNS BOOLEAN
AS $$
BEGIN
	IF node = ANY(path) THEN
		IF iscycle = TRUE THEN
			RETURN FALSE;
		ELSE
			RAISE 'CONNECT BY loop in user data';
		END IF;
	END IF;

	RETURN TRUE;
END;$$ LANGUAGE PLPGSQL;*/

CREATE OR REPLACE FUNCTION connect_by_cycle_check(path anyarray, node anyelement, iscycle boolean)
RETURNS BOOLEAN
AS '$libdir/plpgsql','connect_by_cycle_check'
LANGUAGE C
STRICT IMMUTABLE;