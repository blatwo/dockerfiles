/* src/test/modules/worker_spi/worker_spi--1.0.sql */

