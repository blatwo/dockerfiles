/* src/test/modules/worker_spi/worker_spi--1.0.sql */

-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION worker_pg_pdr" to load this file. \quit

CREATE FUNCTION worker_spi_launch(pg_catalog.int4)
RETURNS pg_catalog.int4 STRICT
AS 'MODULE_PATHNAME'
LANGUAGE C;

CREATE OR REPLACE FUNCTION pg_catalog.pg_pdr_new_snap() 
RETURNS boolean 
AS 'MODULE_PATHNAME', 'pg_pdr_new_snap'
LANGUAGE C STRICT;

CREATE FUNCTION DBversion_for_pdr()
RETURNS TEXT
AS $$
BEGIN
     RETURN 'HighGo SEE V4.5.10';
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION Platform_for_pdr()
RETURNS TEXT
AS $$
DECLARE
     full_version TEXT;
     start_index INT;
     end_index INT;
     version_info TEXT;
BEGIN
     SELECT version() INTO full_version;
     start_index := POSITION(' on ' IN full_version);
     end_index := POSITION(',' IN full_version);

     IF start_index > 0 THEN
          version_info := SUBSTRING(full_version FROM start_index + 4 FOR end_index - (start_index + 4));
     ELSE
          version_info := full_version;
     END IF;

     RETURN version_info;
END;
$$ LANGUAGE plpgsql;

