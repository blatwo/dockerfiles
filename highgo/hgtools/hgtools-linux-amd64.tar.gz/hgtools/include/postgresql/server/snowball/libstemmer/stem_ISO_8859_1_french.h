#ifndef STEM_ISO_8859_1_FRENCH_H
#define STEM_ISO_8859_1_FRENCH_H


extern struct SN_env * french_ISO_8859_1_create_env(void);
extern void french_ISO_8859_1_close_env(struct SN_env * z);

extern int french_ISO_8859_1_stem(struct SN_env * z);


#endif  //stem_ISO_8859_1_french.h

