#ifndef STEM_UTF_8_SPANISH_H
#define STEM_UTF_8_SPANISH_H

extern struct SN_env * spanish_UTF_8_create_env(void);
extern void spanish_UTF_8_close_env(struct SN_env * z);

extern int spanish_UTF_8_stem(struct SN_env * z);


#endif  //stem_UTF_8_spanish.h

