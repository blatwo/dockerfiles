#ifndef STEM_UTF_8_GERMAN_H
#define STEM_UTF_8_GERMAN_H

extern struct SN_env * german_UTF_8_create_env(void);
extern void german_UTF_8_close_env(struct SN_env * z);

extern int german_UTF_8_stem(struct SN_env * z);


#endif  //stem_UTF_8_german.h

