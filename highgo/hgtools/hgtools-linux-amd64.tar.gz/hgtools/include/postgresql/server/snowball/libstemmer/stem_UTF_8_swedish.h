#ifndef STEM_UTF_8_SWEDISH_H
#define STEM_UTF_8_SWEDISH_H

extern struct SN_env * swedish_UTF_8_create_env(void);
extern void swedish_UTF_8_close_env(struct SN_env * z);

extern int swedish_UTF_8_stem(struct SN_env * z);


#endif  //stem_UTF_8_swedish.h

