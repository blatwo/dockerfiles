#ifndef STEM_ISO_8859_1_SPANISH_H
#define STEM_ISO_8859_1_SPANISH_H


extern struct SN_env * spanish_ISO_8859_1_create_env(void);
extern void spanish_ISO_8859_1_close_env(struct SN_env * z);

extern int spanish_ISO_8859_1_stem(struct SN_env * z);


#endif  //stem_ISO_8859_1_spanish.h

