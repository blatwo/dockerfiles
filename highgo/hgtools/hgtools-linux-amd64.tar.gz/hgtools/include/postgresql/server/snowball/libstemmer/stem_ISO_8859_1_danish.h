#ifndef STREM_ISO_8859_1__DANISH_H
#define STREM_ISO_8859_1__DANISH_H


extern struct SN_env * danish_ISO_8859_1_create_env(void);
extern void danish_ISO_8859_1_close_env(struct SN_env * z);

extern int danish_ISO_8859_1_stem(struct SN_env * z);



#endif