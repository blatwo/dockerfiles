#ifndef STEM_KOI8_R_RUSSIAN_H
#define STEM_KOI8_R_RUSSIAN_H

extern struct SN_env * russian_KOI8_R_create_env(void);
extern void russian_KOI8_R_close_env(struct SN_env * z);

extern int russian_KOI8_R_stem(struct SN_env * z);


#endif //stem_KOI8_R_russian.h

