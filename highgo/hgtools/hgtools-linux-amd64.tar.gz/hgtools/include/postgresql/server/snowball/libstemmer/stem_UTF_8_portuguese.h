#ifndef STEM_UTF_8_PORTUGUESE_H
#define STEM_UTF_8_PORTUGUESE_H


extern struct SN_env * portuguese_UTF_8_create_env(void);
extern void portuguese_UTF_8_close_env(struct SN_env * z);

extern int portuguese_UTF_8_stem(struct SN_env * z);


#endif  //stem_UTF_8_portuguese.h

