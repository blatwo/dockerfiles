/*-------------------------------------------------------------------------
 *
 * header.h
 *		Replacement header file for Snowball stemmer modules
 *
 * The Snowball stemmer modules do #include "header.h", and think they
 * are including snowball/libstemmer/header.h.  We adjust the CPPFLAGS
 * so that this file is found instead, and thereby we can modify the
 * headers they see.  The main point here is to ensure that pg_config.h
 * is included before any system headers such as <stdio.h>; without that,
 * we have portability issues on some platforms due to variation in
 * largefile options across different modules in the backend.
 *
 * NOTE: this file should not be included into any non-snowball sources!
 *
 * Portions Copyright (c) 1996-2019, PostgreSQL Global Development Group
 *
 * src/include/snowball/header.h
 *
 *-------------------------------------------------------------------------
 */
#ifndef SNOWBALL_HEADR_H
#define SNOWBALL_HEADR_H

#include "postgres.h"


#ifdef MAXINT
#undef MAXINT
#endif
#ifdef MININT
#undef MININT
#endif

 /* pgrminclude ignore */
#include "snowball/libstemmer/header.h"

/*
 * Redefine memory usage function, apply for postgresql memory context
 *
 */

#if 0
#if defined(_WIN32) && !defined(WIN32)
#define WIN32
#endif

#if !defined(WIN32) && !defined(__CYGWIN__) /* win32 includes further down */
#include "pg_config_os.h"		/* must be before any system header files */
#endif

#if _MSC_VER >= 1400 || defined(HAVE_CRTDEFS_H)
#define errcode __msvc_errcode
#include <crtdefs.h>
#undef errcode
#endif


#endif


#ifdef malloc
#undef malloc
#endif
#define malloc(a)		palloc(a)

/*
 *
 *   Redefine malloc to point to palloc0
 *
 */
#ifdef calloc
#undef calloc
#endif
#define calloc(a,b)		palloc0((a) * (b))

/*
 *
 *   Redefine malloc to point to repalloc
 *
 */
#ifdef realloc
#undef realloc
#endif
#define realloc(a,b)	repalloc(a,b)

/*
 *
 *   Redefine malloc to point to pfree
 *
 */
#ifdef free
#undef free
#endif
#define free(a)			pfree(a)

#endif							/* SNOWBALL_HEADR_H */
