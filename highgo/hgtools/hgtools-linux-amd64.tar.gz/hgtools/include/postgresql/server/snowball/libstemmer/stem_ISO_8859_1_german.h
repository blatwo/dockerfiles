#ifndef STEM_ISO_8859_1_GERMAN_H
#define STEM_ISO_8859_1_GERMAN_H


extern struct SN_env * german_ISO_8859_1_create_env(void);
extern void german_ISO_8859_1_close_env(struct SN_env * z);

extern int german_ISO_8859_1_stem(struct SN_env * z);


#endif  //stem_ISO_8859_1_german.h

