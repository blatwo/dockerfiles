#ifndef STEM_ISO_8859_1_FINNISH_H
#define STEM_ISO_8859_1_FINNISH_H



extern struct SN_env * finnish_ISO_8859_1_create_env(void);
extern void finnish_ISO_8859_1_close_env(struct SN_env * z);

extern int finnish_ISO_8859_1_stem(struct SN_env * z);


#endif //stem_ISO_8859_1_finnish.h

