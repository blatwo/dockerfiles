#ifndef STEM_UTF_8_NORWEGIAN_H
#define STEM_UTF_8_NORWEGIAN_H

extern struct SN_env * norwegian_UTF_8_create_env(void);
extern void norwegian_UTF_8_close_env(struct SN_env * z);

extern int norwegian_UTF_8_stem(struct SN_env * z);


#endif  //stem_UTF_8_norwegian.h

