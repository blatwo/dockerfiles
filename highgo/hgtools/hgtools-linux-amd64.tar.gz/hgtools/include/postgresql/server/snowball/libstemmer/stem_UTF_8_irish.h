#ifndef STEM_UTF_8_IRISH_H
#define STEM_UTF_8_IRISH_H

extern struct SN_env * irish_UTF_8_create_env(void);
extern void irish_UTF_8_close_env(struct SN_env * z);

extern int irish_UTF_8_stem(struct SN_env * z);

#endif //stem_UTF_8_irish.h