#ifndef STEM_ISO_8859_1_INDONESIAN_H
#define STEM_ISO_8859_1_INDONESIAN_H

extern struct SN_env * indonesian_ISO_8859_1_create_env(void);
extern void indonesian_ISO_8859_1_close_env(struct SN_env * z);

extern int indonesian_ISO_8859_1_stem(struct SN_env * z);


#endif //stem_ISO_8859_1_indonesian.h

