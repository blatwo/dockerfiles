#ifndef STREM_ISO_8859_1_DUTCH_H
#define STREM_ISO_8859_1_DUTCH_H


extern struct SN_env * dutch_ISO_8859_1_create_env(void);
extern void dutch_ISO_8859_1_close_env(struct SN_env * z);

extern int dutch_ISO_8859_1_stem(struct SN_env * z);

#endif //stem_iso_8859_1_dutch.h