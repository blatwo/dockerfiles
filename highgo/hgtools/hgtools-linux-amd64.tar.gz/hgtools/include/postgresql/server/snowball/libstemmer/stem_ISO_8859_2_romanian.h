#ifndef stem_ISO_8859_2_romanian_h
#define stem_ISO_8859_2_romanian_h

extern struct SN_env * romanian_ISO_8859_2_create_env(void);
extern void romanian_ISO_8859_2_close_env(struct SN_env * z);

extern int romanian_ISO_8859_2_stem(struct SN_env * z);


#endif  //stem_ISO_8859_2_romanian.h

