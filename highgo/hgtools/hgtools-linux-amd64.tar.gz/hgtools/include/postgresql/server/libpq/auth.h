/*-------------------------------------------------------------------------
 *
 * auth.h
 *	  Definitions for network authentication routines
 *
 *
 * Portions Copyright (c) 1996-2019, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 * Authored by shanchengkai@highgo.com,20191016.
 *
 * Portions Copyright (c) 2009-2019, HighGo Software Co.,Ltd. All rights reserved.

 * src/include/libpq/auth.h
 *
 *-------------------------------------------------------------------------
 */
#ifndef AUTH_H
#define AUTH_H

#include "libpq/libpq-be.h"

typedef enum
{
	ADD_WRONG_COUNT=0,
	CLEAR_WRONG_COUNT
} ACTION;
#define PASSWORD_ERROR_NUM 5

extern char *pg_krb_server_keyfile;
extern bool pg_krb_caseins_users;
extern char *pg_krb_realm;

extern void ClientAuthentication(Port *port);

extern uint64 hash_string(const char *str, int len);

extern void ChangeAuthCount(const char* user ,ACTION action );
/* Hook for plugins to get control in ClientAuthentication() */
typedef void (*ClientAuthentication_hook_type) (Port *, int);
extern PGDLLIMPORT ClientAuthentication_hook_type ClientAuthentication_hook;

#endif							/* AUTH_H */
