/*add by wxm*/
/* ------------------------------------------------ 
* 
* File: hgaudit.h
*
* Abstract: 
*	   安全审计模块的头文件，提供相关的结构定义和函数声明
*
* Authored by wangxiumin@highgo.com 20200218.
*
* Copyright:
* Copyright (c) 2009-2020, HighGo Software Co.,Ltd. 
* All rights reserved .   
*
* Identification:
*	   src/include/postmaster/hgaudit.h  
*-------------------------------------------------
*/	
#ifndef  H_HGAUDIT_H
#define  H_HGAUDIT_H
#include "libpq/libpq.h"
#include "datatype/timestamp.h"
#include "nodes/parsenodes.h"
#include "miscadmin.h"
#include "utils/relcache.h"


#define AUDIT_BLCKSZ 8192

/*
	审计语句类型对应的字符串
 */
#define	CREATE_ROLE_S	"CREATE ROLE"
#define	CREATE_DOMAIN_S	"CREATE DOMAIN"
#define	CREATE_PROCEDURE_S	"CREATE PROCEDURE"
#define	CREATE_INDEX_S	"CREATE INDEX"
#define	CREATE_SCHEMA_S	"CREATE SCHEMA"
#define	CREATE_SEQUENCE_S	"CREATE SEQUENCE"
#define	CREATE_TABLE_S	"CREATE TABLE"
#define	CREATE_TABLE_AS_S	"CREATE TABLE AS"
#define	CREATE_TRIGGER_S	"CREATE TRIGGER"
#define	CREATE_USER_S	"CREATE USER"
#define	CREATE_VIEW_S	"CREATE VIEW"
#define	CREATE_EXTENSION_S	"CREATE EXTENSION"
#define	CREATE_DATABASE_S	"CREATE DATABASE"
#define	ALTER_ROLE_S	"ALTER ROLE"
#define	ALTER_DOMAIN_S	"ALTER DOMAIN"
#define	ALTER_PROCEDURE_S	"ALTER PROCEDURE"
#define	ALTER_INDEX_S	"ALTER INDEX"
#define	ALTER_SYSTEM_S	"ALTER SYSTEM"
#define	ALTER_SCHEMA_S	"ALTER SCHEMA"
#define	ALTER_SEQUENCE_S	"ALTER SEQUENCE"
#define	ALTER_TABLE_S	"ALTER TABLE"
#define	ALTER_TRIGGER_S	"ALTER TRIGGER"
#define	ALTER_USER_S	"ALTER USER"
#define	ALTER_VIEW_S	"ALTER VIEW"
#define	ALTER_EXTENSION_S	"ALTER EXTENSION"
#define	ALTER_DATABASE_S	"ALTER DATABASE"
#define	DROP_DOMAIN_S	"DROP DOMAIN"
#define	DROP_PROCEDURE_S	"DROP PROCEDURE"
#define	DROP_ROLE_S	"DROP ROLE"
#define	DROP_INDEX_S	"DROP INDEX"
#define	DROP_SCHEMA_S	"DROP SCHEMA"
#define	DROP_SEQUENCE_S	"DROP SEQUENCE"
#define	DROP_TABLE_S	"DROP TABLE"
#define	DROP_TRIGGER_S	"DROP TRIGGER"
#define	DROP_USER_S	"DROP USER"
#define	DROP_VIEW_S	"DROP VIEW"
#define	DROP_DATABASE_S	"DROP DATABASE"
#define	DROP_EXTENSION_S	"DROP EXTENSION"
#define	SELECT_S	"SELECT"
#define	SELECT_INTO_S	"SELECT INTO"
#define	INSERT_S	"INSERT"
#define	UPDATE_S	"UPDATE"
#define	DELETE_S	"DELETE"
#define	GRANT_S	"GRANT"
#define	REVOKE_S	"REVOKE"
#define	COMMENT_S	"COMMENT"
#define	RESET_S	"RESET"
#define	SET_S	"SET"
#define	TRUNCATE_S	"TRUNCATE"
#define	COPY_TO_S	"COPY TO"
#define	COPY_FROM_S	"COPY FROM"
#define	REINDEX_S	"REINDEX"
#define INVALID_STMT_S "INVALID STMT"
#define LOCK_S	"LOCK"
#define CALL_S	"CALL"
#define AUDIT_S	"AUDIT"
#define NOAUDIT_S	"NOAUDIT"
#define START_S		"START"
#define STOP_S		"STOP"
#define	LOGIN_S		"LOGIN"
#define LOGOUT_S	"LOGOUT"
#define RELOAD_S	"RELOAD"
#define	IMPORT_S	"IMPORT"
#define EXPORT_S	"EXPORT"
#define CREATE_FUNCTION_S  "CREATE FUNCTION"
#define DROP_FUNCTION_S  "DROP FUNCTION"
#define ALTER_FUNCTION_S	"ALTER FUNCTION"
#define MANDATORY_AUDIT_ON_S "AUDIT ON"
#define MANDATORY_AUDIT_OFF_S "AUDIT OFF"
#define LOCK_ACCOUNT_S			"LOCK ACCOUNT"
#define SWITCHOVER_S			"SWITCH OVER"
/*
审计语句类型
*/
typedef enum AuditStmtType
{
	INVALID_STMT = '0',
	CREATE_ROLE,
	CREATE_DOMAIN,
	CREATE_PROCEDURE,
	CREATE_INDEX,
	CREATE_SCHEMA,
	CREATE_SEQUENCE,
	CREATE_TABLE,
	CREATE_TABLE_AS,
	CREATE_TRIGGER,
	CREATE_USER,
	CREATE_VIEW,
	CREATE_EXTENSION,
	CREATE_DATABASE,
	ALTER_ROLE,
	ALTER_DOMAIN,
	ALTER_PROCEDURE,
	ALTER_INDEX,
	ALTER_SYSTEM,
	ALTER_SCHEMA,
	ALTER_SEQUENCE,
	ALTER_TABLE,
	ALTER_TRIGGER,
	ALTER_USER,
	ALTER_VIEW,
	ALTER_EXTENSION,
	ALTER_DATABASE,
	DROP_DOMAIN,
	DROP_PROCEDURE,
	DROP_ROLE,
	DROP_INDEX,
	DROP_SCHEMA,
	DROP_SEQUENCE,
	DROP_TABLE,
	DROP_TRIGGER,
	DROP_USER,
	DROP_VIEW,
	DROP_DATABASE,
	DROP_EXTENSION,
	SELECT_T,
	SELECT_INTO,
	INSERT_T,
	UPDATE_T,
	DELETE_T,
	GRANT_T,
	REVOKE_T,
	COMMENT_T,
	RESET_T,
	SET_T,
	TRUNCATE_T,
	COPY_TO,
	COPY_FROM,
	REINDEX_T,
	LOCK_T,
	CALL_T,
	AUDIT_T,
	NOAUDIT_T,
	START_T,
	STOP_T,
	LOGIN_T,
	LOGOUT_T,
	RELOAD_T,
	IMPORT_T,
	EXPORT_T,
	CREATE_FUNCTION,
	DROP_FUNCTION,
	ALTER_FUNCTION,
	MANDATORY_AUDIT_ON_T,
	MANDATORY_AUDIT_OFF_T,
	LOCK_ACCCOUNT,
	SWITCHOVER,
	ALL_T
}AuditStmtType;

typedef struct ClientInfo
{
	char	appname[64];
	char 	port[NI_MAXSERV];
	char	mac[8];
	char	ip[1025];
	char	pg_dump_restore;	// 1 for pg_dump OK, 2 for pg_restore OK, 3for pg_dump failed,4 for pg_restore falid
}ClientInfo;

typedef struct ServerInfo
{
	char	mac[8];
	char	ip[1025];
	char 	port[NI_MAXSERV];
}ServerInfo;

/*
审计对象信息
*/

typedef struct ObjectInfo
{
	char* 			schema; 
	char* 			object; 
	char* 			attr;
	Oid				objectid;
	Oid				schemaid;
	AttrNumber		attnum;
	//ObjectType		objectType;
}ObjectInfo;
typedef enum AuditSwitch
{
	AUDIT_OFF = 0,		/* disabled */
	AUDIT_ON		/* enabled while server is running normally */
} AuditSwitch;

/*
审计类型
*/

typedef enum AuditType
{
	AUDIT_TYPE_STATEMENT = 1,
	AUDIT_TYPE_SYSYEM,
	AUDIT_TYPE_OBJECT,
	AUDIT_TYPE_MANDATORY
}AuditType;
#define AUDIT_TYPE_SYSYEM_S "system"
#define AUDIT_TYPE_STATEMENT_S "statement"
#define AUDIT_TYPE_OBJECT_S "object"
#define AUDIT_TYPE_MANDATORY_S "mandatory"


/*
系统审计事件
*/
typedef enum AuditSystemEvent
{
	SYSTEMAUDIT_START = 1,
	SYSTEMAUDIT_STOP,
	SYSTEMAUDIT_LOGIN,
	SYSTEMAUDIT_LOGOUT,
	SYSTEMAUDIT_IMPORT,
	SYSTEMAUDIT_EXPORT,
	SYSTEMAUDIT_LOCK_ACCCOUNT,
	SYSTEMAUDIT_SWITCHOVER,
	SYSTEMAUDIT_RELOAD,
	MANDATORY_AUDIT_ON,
	MANDATORY_AUDIT_OFF
}AuditSystemEvent;


/*
审计事件的权限级别
*/

typedef enum AuditPrivilege
{
	AUDIT_PRIVILEGE_SYSTEM,
	AUDIT_PRIVILEGE_DATABASE,
	AUDIT_PRIVILEGE_SCHEMAOBJECT,
	AUDIT_PRIVILEGE_INSTACE
}AuditPrivilege;

#define AUDIT_PRIVILEGE_SYSTEM_S "SYSTEM"
#define AUDIT_PRIVILEGE_DATABASE_S "DATABASE"
#define AUDIT_PRIVILEGE_SCHEMAOBJECT_S "SCHEMAOBJECT"
#define AUDIT_PRIVILEGE_INSTACE_S	"INSTACE"


#define SUCCESSFUL_S    "successful"
#define	NOT_SUCCESSFUL	"not successful"


#define AUDIT_OBJTYPE_TABLE_S	"table"
#define AUDIT_OBJTYPE_VIEW_S	"view"
#define AUDIT_OBJTYPE_COLUMN_S	"column"
#define AUDIT_OBJTYPE_SEQUENCE_S	"sequence"
#define AUDIT_OBJTYPE_FUNCTION_S	"function"
#define AUDIT_OBJTYPE_PROCEDURE_S	"procedure"

typedef enum AuditRiskLevel
{
	AUDIT_RISK_LEVEL0 = '0',
	AUDIT_RISK_LEVEL1 = '1',
	AUDIT_RISK_LEVEL2 = '2',
	AUDIT_RISK_LEVEL3 = '3',
	AUDIT_RISK_LEVEL4 = '4',
	AUDIT_RISK_LEVEL_OTHER
}AuditRiskLevel;

typedef struct AuditPageHeader
{
	int32  valid_bytes;
	int32  firstrecord;
	uint32  checksum;
}AuditPageHeader;


typedef struct AuditRecord
{
	int 		record_len;

	TimestampTz	log_time;
	AuditRiskLevel risklevel;
	AuditType     	audit_type;	 	 
	//Oid				confid;
	//NameData		rulename;
	AuditStmtType		stmt_type;  
	Oid			useroid;		
	Oid			database;		
	
	AuditPrivilege	privilege;	

	pid_t		pid;
	TimestampTz	session_start;	
	TimestampTz	operation_start;	
	ClientInfo	client_info;
	ServerInfo	server_info;
	TransactionId xid;
	int			affect_rows;
	int			return_rows;
	double		duration;
	AuditResult			result;

	ObjectType  objtype;
	int 		cmd_len;
	int			objectlen;
	int			schemalen;
	int			collen;
	char	    str[];
	/*	cmd 字符串;*/
}AuditRecord;


extern int64	  AuditDelay ;
extern int	  Nbuffers_Audit ;  //Nbuffers_Audit = AuditBufferSize/AUDIT_BLCKSZ

extern int    hg_audit ;
extern int	  hg_audit_logsize ;
extern char*	  hg_audit_alarm ;  
extern int    hg_audit_file_archive_mode ;
extern char  *hg_audit_file_archive_dest ;

extern char *hg_audit_alarm_email;
extern int	  hg_audit_full_mode;
extern int   hg_audit_keep_days;


extern Size AuditShmemSize(void);
extern void AuditShememInit(void);
extern void AuditWriterMain(void);
extern pid_t StartAuditWriter(void);

extern void sendAuditSwitched(void);
extern void sendAuditTempFile(void);

//extern char* getAuditDest(void);
extern void auditWriteToBuffer(AuditRecord* auditRecord);
extern uint32 auditchecksum(char *buf, uint32 nword);

extern void Register_pgaudit_hook(void);
extern void Register_pgaudit_ExecutorCheckPerms_hook(void);

extern void setup_audit_param(void);


//extern void InsertAuditStmtTuple(AuditStatementStmt *auditstmtInfo);
//extern void DeleteAuditStmtTuple(AuditStatementStmt *auditstmtInfo);

extern void AuditStmtProcess(AuditStatementStmt *auditstmtInfo);
extern void DeleteStmtAuditTupleByconfid(AuditStatementStmt *auditstmtInfo);
extern void DeleteObjAuditTupleByconfid(AuditStatementStmt *auditstmtInfo);

extern int AuditArch_start(void);
extern void new_ready_file(char *filepath);

extern bool needRollback(void);
extern void cleanUp_norollback(void);
extern void dealwithSystemEvent(AuditSystemEvent event,AuditResult result);
extern	void mandatoryAudit(bool start);
extern void dealwithSystemEventViaTemp(AuditSystemEvent event,AuditResult result);
extern void  getAuditRecordFromTempFile(void);
extern void DealWithDiskFull(void);

extern Node *Audit_change_whereClause(Node *clause);
extern void get_hg_t_audit_log(RangeVar   *rv);

typedef void (*pgaudit_Command_hook_type) (void);
extern PGDLLIMPORT pgaudit_Command_hook_type pgaudit_CommandStart_hook;
extern PGDLLIMPORT pgaudit_Command_hook_type pgaudit_CommandStop_hook;
extern PGDLLIMPORT pgaudit_Command_hook_type pgaudit_commited_hook;
extern PGDLLIMPORT pgaudit_Command_hook_type pgaudit_aborted_hook;

typedef void  (*pgaudit_Object_hook_type)(Oid oid,Relation rel);
extern PGDLLIMPORT pgaudit_Object_hook_type pgaudit_object_hook;



typedef void (*pgaudit_SaveConnectInfo_hook_type) (Port*);
extern PGDLLIMPORT pgaudit_SaveConnectInfo_hook_type pgaudit_SaveConnectInfo_hook;



#ifdef EXEC_BACKEND
extern void AuditArchiveMain(int argc, char *argv[]) pg_attribute_noreturn();
#endif

#endif
