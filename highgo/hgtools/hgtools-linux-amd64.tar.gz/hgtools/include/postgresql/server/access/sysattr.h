/*-------------------------------------------------------------------------
 *
 * sysattr.h
 *	  POSTGRES system attribute definitions.
 *
 *
 * Portions Copyright (c) 1996-2019, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 * Authored by sunchengxi@highgo.com，20200206.
 *
 * Portions Copyright (c) 2009-2020, HighGo Software Co.,Ltd. All rights reserved.
 *
 * src/include/access/sysattr.h
 *
 *-------------------------------------------------------------------------
 */
#ifndef SYSATTR_H
#define SYSATTR_H


/*
 * Attribute numbers for the system-defined attributes
 */
#define SelfItemPointerAttributeNumber			(-1)
#define MinTransactionIdAttributeNumber			(-2)
#define MinCommandIdAttributeNumber				(-3)
#define MaxTransactionIdAttributeNumber			(-4)
#define MaxCommandIdAttributeNumber				(-5)
#define TableOidAttributeNumber					(-6)
/*modified begin by sun chengxi at 20190206*/
/*add a new system attribute to store row-level security*/
#define SecurityLabelAttributeNumber			(-7)
#define FirstLowInvalidHeapAttributeNumber		(-8)
/*modified end by sun chengxi at 20190206*/

#endif							/* SYSATTR_H */
